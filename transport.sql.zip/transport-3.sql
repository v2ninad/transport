-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 10, 2011 at 01:03 AM
-- Server version: 5.1.44
-- PHP Version: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `transport`
--

-- --------------------------------------------------------

--
-- Table structure for table `accountgroups`
--

CREATE TABLE `accountgroups` (
  `AccountGroupId` int(11) NOT NULL AUTO_INCREMENT,
  `AccountGroupName` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`AccountGroupId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `accountgroups`
--


-- --------------------------------------------------------

--
-- Table structure for table `ackdetails`
--

CREATE TABLE `ackdetails` (
  `AcknowID` int(10) NOT NULL,
  `ConsignmentNo` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `ackdetails`
--

INSERT INTO `ackdetails` VALUES(61, 2);
INSERT INTO `ackdetails` VALUES(57, 2);
INSERT INTO `ackdetails` VALUES(52, 10);
INSERT INTO `ackdetails` VALUES(34, 4);
INSERT INTO `ackdetails` VALUES(59, 5);
INSERT INTO `ackdetails` VALUES(55, 6);
INSERT INTO `ackdetails` VALUES(58, 3);
INSERT INTO `ackdetails` VALUES(45, 1);
INSERT INTO `ackdetails` VALUES(53, 11);
INSERT INTO `ackdetails` VALUES(60, 12);
INSERT INTO `ackdetails` VALUES(56, 14);
INSERT INTO `ackdetails` VALUES(62, 5);
INSERT INTO `ackdetails` VALUES(63, 6);
INSERT INTO `ackdetails` VALUES(64, 10);

-- --------------------------------------------------------

--
-- Table structure for table `acks`
--

CREATE TABLE `acks` (
  `AcknowID` int(10) NOT NULL AUTO_INCREMENT,
  `BillingStationID` int(10) NOT NULL,
  `AcknowDate` date NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `AddedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `EditedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`AcknowID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=65 ;

--
-- Dumping data for table `acks`
--

INSERT INTO `acks` VALUES(34, 2, '2009-08-20', '', 'admin', 'admin+admin-2009-08-20 17:59:56+admin-2009-08-21 12:16:10+admin-2009-08-21 12:25:11+Admin-2009-09-30 12:37:22');
INSERT INTO `acks` VALUES(45, 2, '2009-07-11', 'hi', '', '+infosoft-2009-07-25 16:15:45+admin-2009-08-05 14:21:55+admin-2009-08-05 14:22:23+admin-2009-08-05 14:23:00+admin-2009-08-21 12:10:53+admin-2009-08-21 12:11:09+admin-2009-08-21 12:12:17+admin-2009-08-21 12:12:29+admin-2009-08-21 12:12:42+admin-2009-08-21 ');
INSERT INTO `acks` VALUES(46, 2, '2009-07-11', 'no', '', '');
INSERT INTO `acks` VALUES(52, 2, '2009-08-20', 'ok', 'admin', 'admin+admin-2009-08-21 12:27:18');
INSERT INTO `acks` VALUES(53, 1, '2009-08-20', '', 'admin', 'admin+admin-2009-08-21 12:24:18');
INSERT INTO `acks` VALUES(54, 1, '2009-08-20', '', 'admin', 'admin');
INSERT INTO `acks` VALUES(55, 1, '2009-08-20', '', 'admin', 'admin+admin-2009-08-21 11:46:35+admin-2009-08-21 11:47:15+admin-2009-08-21 12:25:21');
INSERT INTO `acks` VALUES(56, 1, '2009-08-20', '', 'admin', 'admin+admin-2009-08-21 12:25:35');
INSERT INTO `acks` VALUES(57, 2, '2009-08-20', '', 'admin', 'admin+admin-2009-08-20 18:00:09+admin-2009-08-21 11:44:14');
INSERT INTO `acks` VALUES(58, 2, '2009-08-20', '', 'admin', 'admin+admin-2009-08-21 11:43:29+admin-2009-08-21 12:00:05+admin-2009-08-21 12:25:45');
INSERT INTO `acks` VALUES(59, 2, '2009-08-21', '', 'admin', 'admin+admin-2009-08-21 11:20:09+admin-2009-08-21 11:24:20+admin-2009-08-21 11:24:35');
INSERT INTO `acks` VALUES(60, 1, '2009-08-21', 'ok', 'admin', 'admin+admin-2009-08-21 12:24:55');
INSERT INTO `acks` VALUES(61, 2, '2009-09-04', '', 'admin', 'admin');
INSERT INTO `acks` VALUES(62, 0, '2009-09-30', '', 'Admin', 'Admin');
INSERT INTO `acks` VALUES(63, 2, '2009-10-13', '', 'Admin', 'Admin');
INSERT INTO `acks` VALUES(64, 1, '2009-10-14', '', 'Admin', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `banks`
--

CREATE TABLE `banks` (
  `BankId` int(11) NOT NULL AUTO_INCREMENT,
  `BankName` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`BankId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `banks`
--

INSERT INTO `banks` VALUES(1, 'ICICI', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `billdetails`
--

CREATE TABLE `billdetails` (
  `BillNo` int(10) NOT NULL,
  `ConsignmentNo` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `billdetails`
--

INSERT INTO `billdetails` VALUES(23, 8);
INSERT INTO `billdetails` VALUES(23, 2);
INSERT INTO `billdetails` VALUES(22, 10);
INSERT INTO `billdetails` VALUES(24, 5);
INSERT INTO `billdetails` VALUES(24, 2);
INSERT INTO `billdetails` VALUES(28, 10);
INSERT INTO `billdetails` VALUES(26, 5);
INSERT INTO `billdetails` VALUES(25, 4);
INSERT INTO `billdetails` VALUES(27, 3);
INSERT INTO `billdetails` VALUES(29, 16);
INSERT INTO `billdetails` VALUES(30, 1);
INSERT INTO `billdetails` VALUES(31, 18);
INSERT INTO `billdetails` VALUES(38, 19);
INSERT INTO `billdetails` VALUES(33, 23);
INSERT INTO `billdetails` VALUES(34, 14);
INSERT INTO `billdetails` VALUES(35, 11);
INSERT INTO `billdetails` VALUES(37, 20);
INSERT INTO `billdetails` VALUES(36, 15);
INSERT INTO `billdetails` VALUES(32, 13);
INSERT INTO `billdetails` VALUES(32, 12);
INSERT INTO `billdetails` VALUES(39, 21);
INSERT INTO `billdetails` VALUES(40, 25);
INSERT INTO `billdetails` VALUES(41, 12);
INSERT INTO `billdetails` VALUES(42, 13);
INSERT INTO `billdetails` VALUES(43, 46);
INSERT INTO `billdetails` VALUES(43, 43);
INSERT INTO `billdetails` VALUES(43, 42);
INSERT INTO `billdetails` VALUES(43, 41);
INSERT INTO `billdetails` VALUES(43, 40);
INSERT INTO `billdetails` VALUES(43, 37);
INSERT INTO `billdetails` VALUES(43, 36);
INSERT INTO `billdetails` VALUES(43, 35);
INSERT INTO `billdetails` VALUES(43, 34);
INSERT INTO `billdetails` VALUES(43, 30);
INSERT INTO `billdetails` VALUES(43, 29);
INSERT INTO `billdetails` VALUES(43, 28);
INSERT INTO `billdetails` VALUES(43, 27);
INSERT INTO `billdetails` VALUES(43, 15);
INSERT INTO `billdetails` VALUES(43, 14);
INSERT INTO `billdetails` VALUES(43, 47);
INSERT INTO `billdetails` VALUES(43, 48);
INSERT INTO `billdetails` VALUES(43, 49);
INSERT INTO `billdetails` VALUES(43, 52);
INSERT INTO `billdetails` VALUES(43, 53);
INSERT INTO `billdetails` VALUES(43, 54);
INSERT INTO `billdetails` VALUES(44, 83);
INSERT INTO `billdetails` VALUES(45, 84);
INSERT INTO `billdetails` VALUES(46, 85);
INSERT INTO `billdetails` VALUES(47, 85);
INSERT INTO `billdetails` VALUES(48, 85);
INSERT INTO `billdetails` VALUES(49, 86);
INSERT INTO `billdetails` VALUES(50, 89);
INSERT INTO `billdetails` VALUES(51, 90);
INSERT INTO `billdetails` VALUES(52, 55);
INSERT INTO `billdetails` VALUES(53, 70);
INSERT INTO `billdetails` VALUES(54, 92);
INSERT INTO `billdetails` VALUES(55, 93);
INSERT INTO `billdetails` VALUES(56, 93);
INSERT INTO `billdetails` VALUES(57, 93);
INSERT INTO `billdetails` VALUES(58, 93);
INSERT INTO `billdetails` VALUES(59, 93);
INSERT INTO `billdetails` VALUES(60, 78);
INSERT INTO `billdetails` VALUES(61, 78);
INSERT INTO `billdetails` VALUES(62, 78);
INSERT INTO `billdetails` VALUES(63, 78);
INSERT INTO `billdetails` VALUES(64, 78);
INSERT INTO `billdetails` VALUES(65, 78);
INSERT INTO `billdetails` VALUES(66, 78);
INSERT INTO `billdetails` VALUES(67, 78);
INSERT INTO `billdetails` VALUES(68, 78);
INSERT INTO `billdetails` VALUES(69, 78);
INSERT INTO `billdetails` VALUES(70, 78);
INSERT INTO `billdetails` VALUES(71, 78);
INSERT INTO `billdetails` VALUES(72, 78);
INSERT INTO `billdetails` VALUES(73, 78);
INSERT INTO `billdetails` VALUES(74, 78);
INSERT INTO `billdetails` VALUES(75, 78);
INSERT INTO `billdetails` VALUES(76, 78);
INSERT INTO `billdetails` VALUES(77, 78);
INSERT INTO `billdetails` VALUES(78, 78);
INSERT INTO `billdetails` VALUES(79, 78);
INSERT INTO `billdetails` VALUES(80, 93);
INSERT INTO `billdetails` VALUES(81, 102);
INSERT INTO `billdetails` VALUES(82, 110);
INSERT INTO `billdetails` VALUES(83, 78);

-- --------------------------------------------------------

--
-- Table structure for table `billprints`
--

CREATE TABLE `billprints` (
  `BillNo` int(10) NOT NULL AUTO_INCREMENT,
  `ActualBillNo` int(10) NOT NULL,
  `Date` date NOT NULL,
  `CustomerID` int(10) DEFAULT NULL,
  `BillingStationID` int(10) NOT NULL,
  `CreditDay` int(3) NOT NULL,
  `STPaidBy` text COLLATE latin1_general_ci NOT NULL,
  `TaxID` int(2) NOT NULL,
  `TaxAmount1` decimal(10,2) NOT NULL,
  `TaxAmount2` decimal(10,2) NOT NULL,
  `TaxAmount3` decimal(10,2) NOT NULL,
  `Rounding` decimal(10,2) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `NetAmount` decimal(10,2) NOT NULL,
  `PrintCount` int(10) NOT NULL,
  `BillSubmitID` int(10) NOT NULL,
  `ReceiptNo` int(11) NOT NULL,
  `ReceiptDate` date NOT NULL,
  `AmtReceived` int(10) NOT NULL,
  `OnAccount` int(10) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Deduction` decimal(10,2) NOT NULL,
  `ReceivedOpeningBalance` int(10) NOT NULL,
  `LocalBillAmt` int(10) NOT NULL,
  `OnAccountAdjusted` int(10) NOT NULL,
  `Discount` int(10) NOT NULL,
  `TDS` decimal(10,2) NOT NULL,
  `NetReceived` int(10) NOT NULL,
  `CashCheque` text COLLATE latin1_general_ci NOT NULL,
  `ChequeNo` text COLLATE latin1_general_ci NOT NULL,
  `ChequeDate` date NOT NULL,
  `PartyBankID` text COLLATE latin1_general_ci NOT NULL,
  `AccountID` int(10) NOT NULL,
  `AccountGroupID` int(10) NOT NULL,
  `SelfBankID` int(10) NOT NULL,
  `BankTransactionID` int(10) NOT NULL,
  `ReceiptBillTrackID` int(10) NOT NULL,
  `ReceivedDate` date NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `BillTrackID` int(10) NOT NULL,
  `PaidReceiptNo` int(10) NOT NULL,
  `PaidReceiptDate` date NOT NULL,
  `AddedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `EditedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Status` int(3) NOT NULL,
  PRIMARY KEY (`BillNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=84 ;

--
-- Dumping data for table `billprints`
--

INSERT INTO `billprints` VALUES(52, 52, '2009-09-18', 6, 1, 3, 'None', 0, 124.05, 124.05, 124.05, -0.15, 940.00, 1312.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'tata', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `billprints` VALUES(54, 54, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(53, 53, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(55, 55, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(56, 56, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(57, 57, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(58, 58, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(59, 59, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(60, 60, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(61, 61, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(62, 62, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(63, 63, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(64, 64, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(65, 65, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(66, 66, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(67, 67, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(68, 68, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(69, 69, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(70, 70, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(71, 71, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(72, 72, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(73, 73, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(74, 74, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(75, 75, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(76, 76, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(77, 77, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(78, 78, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(79, 79, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(80, 80, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(81, 81, '2009-10-07', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 54.00, 54.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(82, 82, '2009-10-08', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 104.00, 104.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `billprints` VALUES(83, 83, '2009-10-08', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bills`
--

CREATE TABLE `bills` (
  `BillNo` int(10) NOT NULL AUTO_INCREMENT,
  `ActualBillNo` int(10) NOT NULL,
  `Date` date NOT NULL,
  `CustomerID` int(10) DEFAULT NULL,
  `BillingStationID` int(10) NOT NULL,
  `CreditDay` int(3) NOT NULL,
  `STPaidBy` text COLLATE latin1_general_ci NOT NULL,
  `TaxID` int(2) NOT NULL,
  `TaxAmount1` decimal(10,2) NOT NULL,
  `TaxAmount2` decimal(10,2) NOT NULL,
  `TaxAmount3` decimal(10,2) NOT NULL,
  `Rounding` decimal(10,2) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `NetAmount` decimal(10,2) NOT NULL,
  `PrintCount` int(10) NOT NULL,
  `BillSubmitID` int(10) NOT NULL,
  `ReceiptNo` int(11) NOT NULL,
  `ReceiptDate` date NOT NULL,
  `AmtReceived` int(10) NOT NULL,
  `OnAccount` int(10) NOT NULL,
  `Amount` decimal(10,2) NOT NULL,
  `Deduction` decimal(10,2) NOT NULL,
  `ReceivedOpeningBalance` int(10) NOT NULL,
  `LocalBillAmt` int(10) NOT NULL,
  `OnAccountAdjusted` int(10) NOT NULL,
  `Discount` int(10) NOT NULL,
  `TDS` decimal(10,2) NOT NULL,
  `NetReceived` int(10) NOT NULL,
  `CashCheque` text COLLATE latin1_general_ci NOT NULL,
  `ChequeNo` text COLLATE latin1_general_ci NOT NULL,
  `ChequeDate` date NOT NULL,
  `PartyBankID` text COLLATE latin1_general_ci NOT NULL,
  `AccountID` int(10) NOT NULL,
  `AccountGroupID` int(10) NOT NULL,
  `SelfBankID` int(10) NOT NULL,
  `BankTransactionID` int(10) NOT NULL,
  `ReceiptBillTrackID` int(10) NOT NULL,
  `ReceivedDate` date NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `BillTrackID` int(10) NOT NULL,
  `PaidReceiptNo` int(10) NOT NULL,
  `PaidReceiptDate` date NOT NULL,
  `AddedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `EditedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `Status` int(3) NOT NULL,
  PRIMARY KEY (`BillNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=87 ;

--
-- Dumping data for table `bills`
--

INSERT INTO `bills` VALUES(1, 22, '2009-07-13', 791, 1, 0, 'Consignee', 1, 38.80, 38.80, 38.80, -0.40, 776.00, 892.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 61, '2009-08-20', '', '+infosoft-2009-07-25 16:43:46+rajendra-2009-07-27 11:45:35+rajendra-2009-07-27 12:08:29+rajendra-2009-07-27 12:50:13+rajendra-2009-07-27 12:50:53+rajendra-2009-07-27 14:01:10+rajendra-2009-07-27 14:01:33+rajendra-2009-07-27 14:01:52+admin-2009-08-05 15:01', 0);
INSERT INTO `bills` VALUES(2, 23, '2009-07-13', 46, 2, 0, 'None', 2, 4.00, 8.00, 10.00, 0.00, 90.00, 112.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok fine', 0, 0, '0000-00-00', '', '+infosoft-2009-07-27 13:10:07', 0);
INSERT INTO `bills` VALUES(17, 25, '2009-08-17', 791, 1, 5, 'None', 0, 29.90, 29.90, 29.90, 0.30, 70.00, 160.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 63, '2009-10-14', 'ADMIN', 'ADMIN+a-2009-08-18 14:02:23+a-2009-08-18 14:02:44', 0);
INSERT INTO `bills` VALUES(26, 28, '2009-08-18', 791, 1, 0, 'Consignor', 1, 38.80, 38.80, 38.80, 0.00, 776.00, 892.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'good', 0, 64, '2009-10-14', 'ADMIN', 'ADMIN+ADMIN-2009-08-18 15:41:58', 0);
INSERT INTO `bills` VALUES(15, 24, '2009-08-17', 791, 2, 9, 'Consignee', 0, 36.00, 36.00, 36.00, 0.00, 720.00, 828.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 65, '2009-10-14', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(19, 26, '2009-08-17', 791, 2, 0, 'None', 1, 2.80, 2.80, 2.80, -0.40, 56.00, 64.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 60, '2009-08-17', 'ADMIN', 'ADMIN+admin-2009-08-24 13:29:07+admin-2009-08-24 13:30:09', 0);
INSERT INTO `bills` VALUES(20, 0, '0000-00-00', 791, 2, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 60, '2009-08-17', 0, -71, 56.00, 7.00, 7, 0, 7, 0, 7.00, 6, 'Cheque', 'POP88', '2009-08-17', '1', 0, 0, 0, 0, 0, '0000-00-00', 'OK', 0, 0, '0000-00-00', 'ADMIN', '', 0);
INSERT INTO `bills` VALUES(22, 27, '2009-08-17', 791, 1, 4, 'Consignor', 1, 8.35, 8.35, 8.35, -0.05, 104.00, 129.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+a-2009-08-18 13:54:14+a-2009-08-18 13:56:20+a-2009-08-18 14:00:47+ADMIN-2009-08-18 15:40:33', 0);
INSERT INTO `bills` VALUES(27, 0, '0000-00-00', 791, 2, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 61, '2009-08-20', 0, 0, 776.00, 0.00, 0, 0, 0, 0, 0.00, 0, 'select', '', '2009-08-20', '0', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', '', 0);
INSERT INTO `bills` VALUES(28, 29, '2009-08-21', 19, 1, 0, 'None', 1, 4.50, 4.50, 4.50, -0.50, 90.00, 103.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-08-21 10:17:15+admin-2009-08-21 10:17:35+admin-2009-08-24 13:29:36', 0);
INSERT INTO `bills` VALUES(29, 30, '2009-08-21', 2, 2, 0, 'None', 1, 5.25, 5.25, 5.25, 0.25, 80.00, 96.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 62, '2009-09-14', 'admin', 'admin+admin-2009-08-21 18:48:29+admin-2009-08-24 13:29:56+admin-2009-09-14 11:35:20', 0);
INSERT INTO `bills` VALUES(30, 31, '2009-08-21', 9, 2, 0, 'Consignor', 1, 2.80, 2.80, 2.80, -0.40, 56.00, 64.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(31, 32, '2009-08-21', 6, 2, 3, 'None', 0, 72.00, 72.00, 72.00, 0.00, 1440.00, 1656.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-08-21 17:42:32+admin-2009-08-21 17:51:16+admin-2009-08-21 17:51:43+admin-2009-08-21 17:57:40+admin-2009-08-21 17:58:23+admin-2009-08-24 13:27:43+admin-2009-08-24 13:32:35+ADMIN-2009-08-25 11:29:50+ADMIN-2009-08-25 11:30:40', 0);
INSERT INTO `bills` VALUES(32, 33, '2009-08-22', 6, 1, 3, 'None', 0, 4.50, 4.50, 4.50, -0.50, 90.00, 103.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-08-24 13:32:58+a-2009-08-24 13:34:23+ADMIN-2009-08-25 10:42:27', 0);
INSERT INTO `bills` VALUES(33, 34, '2009-08-22', 6, 2, 3, 'None', 0, 36.00, 36.00, 36.00, 0.00, 720.00, 828.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-08-24 13:33:05', 0);
INSERT INTO `bills` VALUES(34, 35, '2009-08-24', 6, 1, 3, 'None', 1, 39.60, 39.60, 39.60, 0.20, 792.00, 911.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'hi', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-08-24 11:39:32+admin-2009-08-24 11:49:29+admin-2009-08-24 13:31:37+a-2009-08-24 13:36:49', 0);
INSERT INTO `bills` VALUES(35, 36, '2009-08-25', 6, 0, 3, 'None', 0, 36.00, 36.00, 36.00, 0.00, 720.00, 828.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(36, 37, '2009-08-25', 791, 0, 0, 'None', 0, 2.10, 2.10, 2.10, -0.30, 42.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(37, 38, '2009-08-25', 6, 0, 3, 'None', 0, 27.65, 27.65, 27.65, 0.05, 553.00, 636.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(38, 39, '2009-08-25', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 38.00, 38.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(39, 40, '2009-08-25', 6, 0, 3, 'None', 0, 271.95, 271.95, 271.95, 0.15, 5439.00, 6255.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'ADMIN', 'ADMIN', 0);
INSERT INTO `bills` VALUES(40, 41, '2009-09-04', 6, 0, 3, 'None', 0, 36.00, 36.00, 36.00, 0.00, 720.00, 828.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(41, 42, '2009-09-04', 6, 2, 3, 'None', 0, 36.00, 36.00, 36.00, 0.00, 720.00, 828.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(42, 43, '2009-09-04', 6, 2, 3, 'None', 0, 756.00, 756.00, 756.00, 0.00, 15120.00, 17388.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', 'admin+admin-2009-09-04 17:45:46+admin-2009-09-04 17:49:55+admin-2009-09-04 17:53:31+admin-2009-09-09 11:21:30+admin-2009-09-09 11:23:31', 0);
INSERT INTO `bills` VALUES(43, 0, '0000-00-00', 2, 0, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 62, '2009-09-14', 0, 0, 80.00, 0.00, 0, 0, 0, 0, 0.00, 0, 'select', '', '2009-09-14', '0', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'admin', '', 0);
INSERT INTO `bills` VALUES(44, 44, '2009-09-18', 6, 2, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 50.00, 50.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(45, 45, '2009-09-18', 6, 1, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 50.00, 50.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(46, 46, '2009-09-18', 6, 1, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 50.00, 50.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(47, 47, '2009-09-18', 6, 1, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 50.00, 50.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(48, 48, '2009-09-18', 6, 1, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 50.00, 50.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(49, 49, '2009-09-18', 6, 1, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 122.00, 122.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(50, 50, '2009-09-18', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 33.00, 33.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(51, 51, '2009-09-18', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 68.00, 68.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'ok', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(52, 52, '2009-09-18', 6, 1, 3, 'None', 0, 124.05, 124.05, 124.05, -0.15, 940.00, 1312.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', 'tata', 0, 0, '0000-00-00', 'admin', 'admin', 0);
INSERT INTO `bills` VALUES(53, 53, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(54, 54, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(55, 55, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(56, 56, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(57, 57, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(58, 58, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(59, 59, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(60, 60, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(61, 61, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(62, 62, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(63, 63, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(64, 64, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(65, 65, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(66, 66, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(67, 67, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(68, 68, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(69, 69, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(70, 70, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(71, 71, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(72, 72, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(73, 73, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(74, 74, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(75, 75, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(76, 76, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(77, 77, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(78, 78, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(79, 79, '2009-10-06', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(80, 80, '2009-10-06', 791, 0, 0, 'None', 0, 0.00, 0.00, 0.00, 0.00, 48.00, 48.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(81, 81, '2009-10-07', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 54.00, 54.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(82, 82, '2009-10-08', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 104.00, 104.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(83, 83, '2009-10-08', 6, 0, 3, 'None', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 0, '0000-00-00', 0, 0, 0.00, 0.00, 0, 0, 0, 0, 0.00, 0, '', '', '0000-00-00', '', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', 'Admin', 0);
INSERT INTO `bills` VALUES(84, 0, '0000-00-00', 791, 2, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 63, '2009-10-14', 0, 0, 70.00, 0.00, 0, 0, 0, 0, 0.00, 0, 'select', '', '2009-10-14', '0', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', '', 0);
INSERT INTO `bills` VALUES(85, 0, '0000-00-00', 791, 0, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 64, '2009-10-14', 0, 0, 776.00, 0.00, 0, 0, 0, 0, 0.00, 0, 'select', '', '2009-10-14', '0', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', '', 0);
INSERT INTO `bills` VALUES(86, 0, '0000-00-00', 791, 0, 0, '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 0, 65, '2009-10-14', 0, 0, 720.00, 0.00, 0, 0, 0, 0, 0.00, 0, 'select', '', '2009-10-14', '0', 0, 0, 0, 0, 0, '0000-00-00', '', 0, 0, '0000-00-00', 'Admin', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bookingoffices`
--

CREATE TABLE `bookingoffices` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `concernperson` varchar(255) NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) NOT NULL DEFAULT '0',
  `address3` varchar(100) NOT NULL,
  `CityId` int(20) NOT NULL,
  `panno` varchar(50) NOT NULL,
  `phone` varchar(75) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `fax` varchar(50) NOT NULL,
  `email` varchar(75) NOT NULL,
  `remarks` varchar(255) NOT NULL,
  `Status` int(15) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `bookingoffices`
--

INSERT INTO `bookingoffices` VALUES(1, 'Pune', '', '', '', '', 1, '', '', '', '', '', '', 0);
INSERT INTO `bookingoffices` VALUES(2, 'Mumbai', '', '', '', '', 1, '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `CityId` int(11) NOT NULL AUTO_INCREMENT,
  `CityName` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`CityId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=210 ;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` VALUES(1, 'Pune', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(2, 'Mumbai', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(3, 'Midc ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(4, 'Kalamboli', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(5, 'Taloja', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(6, 'Kharadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(7, 'Pashan', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(8, 'Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(9, 'Shriwal ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(10, 'Sangli ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(11, 'Ogalewadi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(12, 'Kolhapur ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(13, 'Ichalkaranji', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(14, 'Shirol ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(15, 'Sanaswadi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(16, 'Rahatani Phata ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(17, 'Satara ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(18, 'Bhosari ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(19, 'Hadapser  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(20, 'Palus ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(21, 'Shiroli', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(22, 'Wadki ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(23, 'Gokul Shirgaon ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(24, 'Chikhli ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(25, 'Ashta ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(26, 'Hatakangle  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(27, 'Pirangut', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(28, 'Khed-shivapur ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(29, 'Yadrav ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(30, 'Maval ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(31, 'Wakadewadi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(32, 'Miraj ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(33, 'Kupwad ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(34, 'Karvir ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(35, 'Katraj ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(36, 'Alandi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(37, 'Jaysingpur ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(38, 'Pimpri ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(39, 'Vikramnagar ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(40, 'Mundhwa', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(41, 'Chakan ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(42, 'Loni Kalbhor', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(43, 'Shivaji Nagar ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(44, 'Uchgaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(45, 'Kirlskerwadi  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(46, 'Fursungi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(47, 'Madhav Nagar  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(48, 'Kasar Amboli ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(49, 'Dhayari ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(50, 'Tathwade ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(51, 'Kagal ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(52, 'Y.p.nagar ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(53, 'Taswade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(54, 'Kothroud ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(55, 'Kodoli', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(56, 'Top', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(57, 'Tahwade ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(58, 'Ambegaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(59, 'Shivane ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(60, 'Tung', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(61, 'Ranjangaon ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(62, 'Nigde', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(63, 'Sahakarnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(64, 'Karad ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(65, 'Watar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(66, 'Bamnoli', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(67, 'Shirwal', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(68, 'Rupinagar ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(69, 'Udyamnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(70, 'Ahmednagar 1 ', 'Infosoft', ' Admin 27-09-10 Admin 27-09-10', '0');
INSERT INTO `cities` VALUES(71, 'Mann ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(72, 'Urawade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(73, 'Pimpari  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(74, 'Sangali ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(75, 'Erandawna ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(76, 'Islampur ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(77, 'Madhavnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(78, 'Talawade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(79, 'Warje', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(80, 'Kondhwa ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(81, 'Ramtekdi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(82, 'Gandhinagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(83, 'Wagholi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(84, 'Pargaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(85, 'Warje Malwadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(86, 'Keshnand', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(87, 'Shindewadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(88, 'Shivare', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(89, 'Narhegaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(90, 'Gultekadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(91, 'Wathar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(92, 'Kasurdi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(93, 'Wing', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(94, 'Kirloskarwadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(95, 'Bhor ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(96, 'Undri ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(97, 'Kasarwadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(98, 'Mouze Bhare ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(99, 'Hinjawadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(100, 'Lonikand', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(101, 'Phursungi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(102, 'Ravet', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(103, 'Nanded Phata', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(104, 'Bhare', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(105, 'Somatane Phata', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(106, 'Sukhsagarnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(107, 'Dapodi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(108, 'Handewadi ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(109, 'Tasawade  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(110, 'Malkapur ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(111, 'Nagthane ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(112, 'Vadu Budruk', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(113, 'Chikhali ..Del', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(114, 'Rasta Peth', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(115, 'Koregaon Bhima ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(116, 'Rsnjangaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(117, 'Mangrayachiwadi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(118, 'Dhanore', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(119, ' Kupwad  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(120, 'Hadapsar ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(121, 'Tasgaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(122, 'Shirur', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(123, 'Satara Road', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(124, 'Nos ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(125, 'Talegaon Dabhade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(126, '`alndi ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(127, 'Maan', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(128, 'Nasik', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(129, 'Kuruli ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(130, '` ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(131, 'Yewlewadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(132, 'Sangli & Kolhapur', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(133, 'Mann', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(134, 'Khed', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(135, 'Akurdi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(136, 'Kondhwa (br.)', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(137, 'Gao', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(138, 'Sangil', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(139, 'Koplhapur', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(140, 'Walchandnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(141, 'Shikrapur', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(142, 'Bambhawade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(143, 'Kumbhoj', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(144, 'Nerli', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(145, 'Kasba Peth', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(146, 'Rui', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(147, 'Dattanagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(148, 'Tamgaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(149, 'Market Yard', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(150, 'Handewadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(151, 'Bhosari, Chinchwad, Chakan', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(152, 'Kalewadi- Bhosari- Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(153, 'Chikhali  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(154, 'Nigdi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(155, 'Hatakangale ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(156, 'Hatkanangale  ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(157, 'Bhosari- Chinchwad ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(158, 'Swargate', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(159, '` ..Del', 'Infosoft', '', '1');
INSERT INTO `cities` VALUES(160, 'Kothrud', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(161, 'Parvati', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(162, 'Paud', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(163, 'Wanowrie', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(164, 'Mundhwa - Wadki', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(165, 'Mangaon Wadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(166, 'Bhosari - Kalewadi - Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(167, 'Aundh', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(168, 'Tilak Road', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(169, 'Narayan Peth', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(170, 'Ambap', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(171, 'Shivaji Udyam Nagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(172, 'Toap', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(173, 'Mulshi ', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(174, 'Takawade', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(175, 'Warnanagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(176, 'Nana Peth', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(177, 'Satavnagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(178, 'Nagaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(179, 'Gorhe Kurad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(180, 'Ambegaon Bk', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(181, 'Wadgaon Mawal', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(182, 'Pune Camp', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(183, 'Kalewadi- Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(184, 'Goa', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(185, 'Kurkumbh', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(186, 'Wanowadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(187, 'Budhwar Peth', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(188, 'Anewadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(189, 'Karve Nagar', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(190, 'Bibvewadi', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(191, 'Bhosari - Bhosari - Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(192, 'Bhosari - Bhosari - Kalewadi - Chinchwad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(193, 'Majale', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(194, 'Devachi Urali', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(195, 'Masur', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(196, 'Chipri', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(197, 'Kini Gaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(198, 'Gangadham', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(199, 'Vadgaon Sheri', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(200, 'Peth Vadgaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(201, 'Mahalunge', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(202, 'Saswad', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(203, 'Nandedgaon', 'Infosoft', '', '0');
INSERT INTO `cities` VALUES(204, 'Kini Wathar', 'Infosoft', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `cleaners`
--

CREATE TABLE `cleaners` (
  `CleanerId` int(10) NOT NULL AUTO_INCREMENT,
  `CleanerName` text COLLATE latin1_general_ci NOT NULL,
  `CityId` int(10) NOT NULL,
  `Permanent_Address` longtext COLLATE latin1_general_ci NOT NULL,
  `Temporary_Address` longtext COLLATE latin1_general_ci NOT NULL,
  `CleanerPhone` text COLLATE latin1_general_ci NOT NULL,
  `JoinDate` date NOT NULL,
  `DOBirth` date NOT NULL,
  `BloodGroup` text COLLATE latin1_general_ci NOT NULL,
  `WagesPerMonth` decimal(10,2) NOT NULL,
  `AllowancePerDay` decimal(10,2) NOT NULL,
  `RelivedDate` date NOT NULL,
  `Delete` char(5) COLLATE latin1_general_ci NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `LicenceNumber` text COLLATE latin1_general_ci NOT NULL,
  `LicenceValidUpto` date NOT NULL,
  `DateOfIssue` date NOT NULL,
  `LicenceDescription` text COLLATE latin1_general_ci NOT NULL,
  `Status` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`CleanerId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `cleaners`
--


-- --------------------------------------------------------

--
-- Table structure for table `collectiondetails`
--

CREATE TABLE `collectiondetails` (
  `CollectionID` int(10) NOT NULL,
  `ConsignmentNo` int(10) NOT NULL,
  `AmountReceived` decimal(10,2) NOT NULL,
  `TDS` decimal(10,2) NOT NULL,
  `Deduction` decimal(10,2) NOT NULL,
  `ChequeNo` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `CheqDate` date NOT NULL,
  `BankName` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `collectiondetails`
--

INSERT INTO `collectiondetails` VALUES(2, 6, 20.00, 6.00, 19.00, '8978h', '2009-07-31', 'ICICI');
INSERT INTO `collectiondetails` VALUES(2, 5, 10.00, 5.00, 30.00, '', '0000-00-00', '');
INSERT INTO `collectiondetails` VALUES(1, 3, 78.00, 7.00, 19.00, '8798kjjh', '2009-08-05', 'ICICI');
INSERT INTO `collectiondetails` VALUES(3, 8, 78.00, 6.00, 72.00, '898', '0000-00-00', '1');
INSERT INTO `collectiondetails` VALUES(5, 22, 20.00, 9.00, 43.00, '', '2009-09-01', '');
INSERT INTO `collectiondetails` VALUES(4, 9, 700.00, 0.00, 76.00, '', '2009-08-31', '');
INSERT INTO `collectiondetails` VALUES(4, 7, 10.00, 0.00, 62.00, '', '2009-08-31', '');

-- --------------------------------------------------------

--
-- Table structure for table `collections`
--

CREATE TABLE `collections` (
  `CollectionID` int(10) NOT NULL AUTO_INCREMENT,
  `CollectionDate` date NOT NULL,
  `BillingStationID` int(10) NOT NULL,
  `StaffId` int(10) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `TotalTDS` decimal(10,2) NOT NULL,
  `TotalDeduction` decimal(10,2) NOT NULL,
  `TotalCashAmount` decimal(10,2) NOT NULL,
  `TotalChequeAmount` decimal(10,2) NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `AddedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `EditedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`CollectionID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=16 ;

--
-- Dumping data for table `collections`
--

INSERT INTO `collections` VALUES(1, '2009-07-14', 2, 0, 78.00, 7.00, 19.00, 0.00, 78.00, 'Collection', '', '+admin-2009-08-05 14:36:55+admin-2009-08-05 14:37:20+admin-2009-08-05 14:37:29+ADMIN-2009-08-17 13:24:37');
INSERT INTO `collections` VALUES(2, '2009-07-15', 1, 0, 30.00, 11.00, 49.00, 10.00, 20.00, 'second collection', '', '+infosoft-2009-07-25 16:28:03+infosoft-2009-07-31 17:44:16+infosoft-2009-07-31 17:53:31');
INSERT INTO `collections` VALUES(3, '2009-07-15', 1, 0, 78.00, 6.00, 72.00, 0.00, 0.00, 'Third collection', '', '');
INSERT INTO `collections` VALUES(4, '2009-08-17', 1, 0, 710.00, 0.00, 138.00, 710.00, 0.00, 'ok', 'ADMIN', '+admin-2009-08-31 14:25:35+admin-2009-08-31 14:26:24+admin-2009-08-31 14:37:42+admin-2009-08-31 14:37:57+admin-2009-08-31 14:38:53+admin-2009-08-31 16:18:04+admin-2009-08-31 16:19:02');
INSERT INTO `collections` VALUES(5, '2009-09-01', 1, 0, 20.00, 9.00, 43.00, 20.00, 0.00, 'ok', 'admin', '');
INSERT INTO `collections` VALUES(6, '2009-07-14', 2, 0, 78.00, 7.00, 19.00, 0.00, 78.00, 'Collection', '', '+admin-2009-08-05 14:36:55+admin-2009-08-05 14:37:20+admin-2009-08-05 14:37:29+ADMIN-2009-08-17 13:24:37');
INSERT INTO `collections` VALUES(7, '2009-07-15', 1, 0, 30.00, 11.00, 49.00, 10.00, 20.00, 'second collection', '', '+infosoft-2009-07-25 16:28:03+infosoft-2009-07-31 17:44:16+infosoft-2009-07-31 17:53:31');
INSERT INTO `collections` VALUES(8, '2009-07-15', 1, 0, 78.00, 6.00, 72.00, 0.00, 0.00, 'Third collection', '', '');
INSERT INTO `collections` VALUES(9, '2009-08-17', 1, 0, 710.00, 0.00, 138.00, 710.00, 0.00, 'ok', 'ADMIN', '+admin-2009-08-31 14:25:35+admin-2009-08-31 14:26:24+admin-2009-08-31 14:37:42+admin-2009-08-31 14:37:57+admin-2009-08-31 14:38:53+admin-2009-08-31 16:18:04+admin-2009-08-31 16:19:02');
INSERT INTO `collections` VALUES(10, '2009-09-01', 1, 0, 20.00, 9.00, 43.00, 20.00, 0.00, 'ok', 'admin', '');
INSERT INTO `collections` VALUES(11, '2009-07-14', 2, 0, 78.00, 7.00, 19.00, 0.00, 78.00, 'Collection', '', '+admin-2009-08-05 14:36:55+admin-2009-08-05 14:37:20+admin-2009-08-05 14:37:29+ADMIN-2009-08-17 13:24:37');
INSERT INTO `collections` VALUES(12, '2009-07-15', 1, 0, 30.00, 11.00, 49.00, 10.00, 20.00, 'second collection', '', '+infosoft-2009-07-25 16:28:03+infosoft-2009-07-31 17:44:16+infosoft-2009-07-31 17:53:31');
INSERT INTO `collections` VALUES(13, '2009-07-15', 1, 0, 78.00, 6.00, 72.00, 0.00, 0.00, 'Third collection', '', '');
INSERT INTO `collections` VALUES(14, '2009-08-17', 1, 0, 0.00, 0.00, 0.00, 710.00, 0.00, 'ok', 'ADMIN', '+admin-2009-08-31 14:25:35+admin-2009-08-31 14:26:24+admin-2009-08-31 14:37:42+admin-2009-08-31 14:37:57+admin-2009-08-31 14:38:53+admin-2009-08-31 16:18:04+admin-2009-08-31 16:19:02+Admin-2009-10-14 16:27:38');
INSERT INTO `collections` VALUES(15, '2009-09-01', 1, 0, 20.00, 9.00, 43.00, 20.00, 0.00, 'ok', 'admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `companysetups`
--

CREATE TABLE `companysetups` (
  `CompId` int(11) NOT NULL,
  `SoftwareName` varchar(255) NOT NULL,
  `SoftwareVersion` varchar(255) NOT NULL,
  `License1` varchar(255) NOT NULL,
  `License2` varchar(255) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `TopName` varchar(255) NOT NULL,
  `BottomName` varchar(255) NOT NULL,
  `CompanyName` varchar(255) NOT NULL,
  `CompanySlogan` varchar(255) NOT NULL,
  `Address1` varchar(255) NOT NULL,
  `Address2` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `CellNo` varchar(255) NOT NULL,
  `Url` varchar(255) NOT NULL,
  `SMSUserName` varchar(250) NOT NULL,
  `SMSPassword` varchar(250) NOT NULL,
  `SMSSenderAdd` varchar(250) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companysetups`
--

INSERT INTO `companysetups` VALUES(1, 'Dhayreshwar', '2009', 'Dhayreshwar', 'Dhayreshwar', 'Dhayreshwar', 'DHAYRESHWAR TRANSPORT CO.', 'For DHAYRESHWAR TRANSPORT CO.', 'DHAYRESHWAR TRANSPORT CO.', 'Drfh', 'Dfh', 'Hhhhhhhhhhhh', '234', '66666666666', 'http://www.dhayreshwartransportco.com', '20012127', 'h2tjzt', 'infosoft', 'd3456', '3432', '');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `UserName` varchar(25) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Address1` varchar(255) NOT NULL,
  `Address2` varchar(255) NOT NULL,
  `Address3` varchar(255) NOT NULL,
  `CityId` int(10) NOT NULL,
  `AddedBy` varchar(30) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Mobile` varchar(255) NOT NULL,
  `Fax` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `DOJ` date NOT NULL,
  `ConcernName1` varchar(255) NOT NULL,
  `ConcernMobile1` varchar(100) NOT NULL,
  `ConcernEmail1` varchar(100) NOT NULL,
  `ConcernName2` varchar(255) NOT NULL,
  `ConcernMobile2` varchar(100) NOT NULL,
  `ConcernEmail2` varchar(100) NOT NULL,
  `ConcernName3` varchar(255) NOT NULL,
  `ConcernMobile3` varchar(100) NOT NULL,
  `ConcernEmail3` varchar(100) NOT NULL,
  `VenderCode` varchar(100) NOT NULL,
  `OpeningBalance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `CreditDays` int(3) NOT NULL DEFAULT '0',
  `CreditLimit` bigint(20) NOT NULL DEFAULT '0',
  `LocalBillBalance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `OutStanding` decimal(10,2) NOT NULL DEFAULT '0.00',
  `OnAccount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `RecOpeningBalance` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Remark` longtext NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1001 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` VALUES(1, 'Labind Sales Corp.', '', '', 'T-19 Harivijay ', '226/27 Parvati ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(2, 'Teltech Instrumentation Pvt Ltd ..Deleted', 'rajendra', 'f81c2414e3f4685567201371a38aee4a', 'Kharadi,  ', 'Pune', '', 6, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 96.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(3, 'B. G. Bam ', '', '', '37/2, Prabhat Road, Lane 6', 'Pune-411004', '', 1, '', '', '', '9226125283', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(4, 'Pandit Automotive P. Ltd (tathwade)', '', '', 'Tathwade', '', 'Pune', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(5, 'Vinntech Enggs. P.ltd ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(6, 'Acme Foundry Flux Co.', '', '', '264, Hadapsar Ind. Estest, ', 'Hadapsar,', 'Pune-411013', 120, '', '', '', '9822348734', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 3, 0, 0.00, 52915.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(7, 'Foseco (i) Ltd  ..Deleted', '', '', 'Gat No.907/2/4,behind Kalpesh Weigh ', 'Bridge,', 'Sanaswadi, Tal. Shirur.', 1, '', '', '', '', '', 'www.afcil.com', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(8, 'Jsons Foundry P.ltd ', '', '', 'G-13, Midc, Kupwad Block,', 'Sangli.', '', 33, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(9, 'Sanjay Foundry P.ltd ', '', '', 'P.o. Gangadhar', '', '', 13, '', '', '2302441421', '', '', 'sanjayfounders@dataone.in', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 64.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(10, 'Omkar Foundries ', '', '', 'Plot No. J-1', 'Midc, Kupwad Block', '', 10, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(11, 'Intervalve (i) Ltd ', '', '', '212/2, Hadapsar,  ', 'Opp. Soli Poonawal Road,', 'Pune-411028', 120, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(12, 'Kolhapur Alloys ', '', '', 'R. S. No.603/2 Behind Kolhapur Steel ', 'Midc, Shiroli', '', 12, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(13, 'Yashwant Iron & Steel Works Ltd.', '', '', '1325/46- B ''e'', Ward', 'Shivaji Udyamnagar.', '', 12, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(14, 'Shree Ajay Engs. Works ', '', '', '', 'Bhosari ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(15, 'Paranjape Metal Shapers P.ltd ', '', '', '', '', 'Shirwal', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(16, 'Ksb Pumps Ltd  (pimpri) ', '', '', 'Pimpri ', '', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(17, 'Amigo Sales Corporation', '', '', 'Gangadhar Chambers, ', '314, Narayan Peth,', 'Pune-411030', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(18, 'V-smart Thermotech P. Ltd ', '', '', 'S.no.46/15&16 Narhe  ', 'Dhayari Road Tal.haveli', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(19, 'Amber Technologies ', '', '', '17/1 B-1 A-2 Kothrud Indus. Estase,', 'Pune-411029', '', 160, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 103.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(20, 'Arihant Cnc P.ltd ', '', '', '', 'Sanaswadi ', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(21, 'Ramson Poly Pack P.ltd ', '', '', 'Rahatani Phata ', '', 'Pune ', 16, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(22, 'Sanjeev Indus.  ..Deleted', '', '', 'Midc', 'Bhosari ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(23, 'Industrial Minerals & Refrocaties ', '', '', 'J-222, M I D C Bhosari ', 'Pune ', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 5749.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(24, 'El-o-matic (i)  Pvt. Ltd. ', '', '', 'Industrial Estate Hadapser ', 'Pune', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(25, 'Pravin Poly Plast ', '', '', '36, Mahatma Phule Peth,', 'Pune-411042', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(26, 'Ajay Metachem P.ltd (wadki) ..Deleted', '', '', 'Saswad Road, Wadki', 'Pune', '', 22, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(27, 'P. R. Enterprises ', '', '', '1st Floor Krishna Chember ', '8/4 Near Laxmi Narayan Theater ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(28, 'Vijayshree Alloys (pune) P.ltd ', '', '', 'Plot No.39 B U Bhandri Industrial Estate', 'Sansawadi ', 'Pune ', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 5909.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(29, 'S. D. Chemicals ', '', '', 'Pawar Wasri ', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(30, 'Ajay Syscon Pvt. Ltd ', '', '', 'Sr. No.147/1&2,', 'Shembekar Industrial Compound, Chinchwad', 'Pune-411019 ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(31, 'Viraj Engineers & Exports Pvt. Ltd ', '', '', 'Mouze Bhare, Pirangut', 'Pune', '', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(32, 'Enginetech Systems P. Ltd ', '', '', 'Plot No.10, Gat No. 281,', 'Kasar Amboli, Tal. Mulshi, ', 'Pune-412108', 48, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 46890.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(33, 'Royal Industrial Product', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(34, 'Mather & Platt Pumps Ltd (chinchwad)', '', '', 'Pune Mumbai Road', 'Chichwad', 'pune 411 019', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 130335.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(35, 'Tulip Casting P.ltd ', '', '', '', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(36, 'Kirlosker Oil Ltd ', '', '', '', '', 'Pune ', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(37, 'Afcil Industris Limited ', '', '', 'Gat No.907/2/4, Near Kalpesh Weight Brid', 'Sanaswadi, Tal - Shirur  Pune .', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 51915.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(38, 'Pioneer Coats ', '', '', 'Khed-shivapur ', '', 'Pune', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 715.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(39, 'Vedant Equip Sales & Services P.ltd. Kop', '', '', 'W-80 M I D C, Shiroli,', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(40, 'Kankoo Paints P.ltd ', '', '', '', '', 'Pune ', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(41, 'Suprahi Pattern Works ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(42, 'Vedant Equip Sales & Services P. Ltd (pune)', '', '', 'Chinchwad,', 'Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 5063.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(43, 'Ksb Pumps Ltd. (chinchwad)', '', '', 'Plot No. 28/21, D-2 Block', 'M I D C Chinchwad, Pune- 411018', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(44, 'Hindustan Marketing ', '', '', 'Shop No.4, Pratibha Towers,  ', '18- A Mumbai- Pune Road,', 'Wakadewadi Pune-411003', 31, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(45, 'House Of Forms ', '', '', '191, Kasba Peth, Mujumdar Lane,  ', 'Pune-411011', '', 145, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(46, 'Sayali Sales Co.op.', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 200.00, 0, 0, 0.00, 143.00, 100.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(47, 'R. P. Enterprises  ..Deleted', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(48, 'Shankar Enterprises ', '', '', 'S.no. 120/2 Santosh Nagar ', 'Katraj ', 'Pune ', 35, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(49, 'Rathi Transpower P.ltd ', '', '', 'Gut No.144/145 Village Dhanori ', 'Alandi Markal Road ', 'Pune ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 95187.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(50, 'Shreyas Sales ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(51, 'Thakur Shroff & Electric Company', '', '', '467 7 475, Budhwar Peth, ', 'Pune- 411002', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(52, 'Ramesh & Co.', '', '', '', 'Chinchwad ', 'Pune', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(53, 'A. S. Engineering ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(54, 'Emulsichem Lubricants', '', '', 'T-120, M I D C Bhosari,', 'Pune-411026 ', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 10175.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(55, 'Shimo Resins Pvt. Ltd. ', '', '', 'S-99, M I D C Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(56, 'Lube Tak ', '', '', '', '', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(57, 'Foseco India Ltd ', '', '', 'Sanaswadi, Tal. Shirur,', 'Pune-412208', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 10298.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(58, 'United Engineers ', '', '', '2131a E Vikram Nagar ', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(59, 'Sand Trading Company', '', '', 'Mehendale Agro (p) Ltd ', '126, Tathwade', 'Pune', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(60, 'Unity Bushes & Tools Company', '', '', '101, Rasta Peth , ', 'Pune ', '', 1, '', '', '26121890', '', '', 'bushtool@vsnl.net ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(61, 'Unique Enterprises ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(62, 'Ajay Metachem P.ltd  ..Deleted', '', '', '', 'Mundhwa ', 'Pune ', 40, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(63, 'Ajay Metachem P.ltd (mundhwa) ..Deleted', '', '', '72/76, Mundhwa,', 'Pune', '', 40, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(64, 'Maharani Paints Pvt. Ltd. ', '', '', 'Gat No. 627, Opp. Kishor Pumps,', 'Pune- Nasik Highway, Village Kuruli, ', 'Chakan,  Dist. Pune.', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(65, 'Pearl Coating ', '', '', 'Plot No 3 Sr No 70a/1/2a/1', 'Wanowale Ind Aria', 'Pune', 1, '', '', '26831244', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(66, 'Mrunal Enterprises ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(67, 'Tradewheel Sales Corp.', '', '', '811/12 Raviwar Peth , 3 Kalyan Chamber,', 'Pune-411002', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(68, 'K. P. Engineering ', '', '', '83, Shivaji Nager ', 'Pune-416122', '', 43, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 2340.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(69, 'Turnwell Engineers ', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(70, 'Quality Pressing Products ', '', '', '255/256, Shukrawar Peth,', 'Shinde Ali, Pune-411002', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(71, 'Mahesh Mfg.', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(72, 'Avdhoot Engineers ', '', '', 'M-59, Midc Satara ', '', '', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(73, 'Aroma Polymers ', '', '', 'Narhe ', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(74, 'Raviraj Marketing ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(75, 'Bhumi Enterprises ', '', '', 'Shukerwar Peth ', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(76, 'Sagar Enterprises ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(77, 'Khosla Engineering P.ltd ', '', '', 'Chinchwad,', 'Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 5409.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(78, 'Hitech Plast Limited', '', '', 'Plot No. 939/940, Sanaswadi,', 'Nagar Roag, Tal. Shirur, ', 'Dist. Pune-412208 ', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(79, 'Suyash Solutions P.ltd ', '', '', 'S.no.145, Pune- Sasad Rd.', 'Fursungi.', 'Pune ', 46, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(80, 'Unique  ..Deleted', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(81, 'Control Tech Instruments ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(82, 'Jayhind Refactory ', '', '', '', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(83, 'Mpm P. Ltd ', '', '', '', '', 'Pune ', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(84, 'Samir Industries ', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(85, 'Aarti Industries ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(86, 'Accsharp  ..Deleted', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(87, 'Creative Tools & Componets  ', '', '', 'Plot No. 19, Kasar- Amboli', 'Pune', '', 48, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(88, 'Tuff Coat Polymers P.ltd ', '', '', '', '', 'Pune ', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 115.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(89, 'Craft & Technik Industries ', '', '', '', '', 'Pune ', 49, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(90, 'Coupling Engineer Services ', '', '', '', '', 'Pune ', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(91, 'Basf Coatings (i) Pvt. Ltd. ', '', '', 'Sr. No.13, Opp. Raghunandan Mangal', 'Karyalay, Tathwade, ', 'Pune. ', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(92, 'Eloquent Engineering Works ', '', '', '', '', 'Pune', 19, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(93, 'Vat Polymers  ..Deleted', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(94, 'Ferro Liners ', '', '', 'S.no.152/32 Ganesh Nagar Dhayri Goan', 'Dhayri  ', 'Pune ', 49, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(95, 'Sangram Metal Works ', '', '', '', '', 'Pune ', 6, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(96, 'Nihar Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(97, 'Tradevision Engineering & Marketing ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(98, 'Versatile Engineering ', '', '', '', '', 'Pune ', 54, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(99, 'Hydra Care Point ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(100, 'Auram Aptec P.ltd ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(101, 'Saifee Stores ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(102, 'S. P. Technologies ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(103, 'Filtro Pumps ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(104, 'Hydrotech', '', '', 'Sr. No. 10 C D Wing, Ruturang Soc.', 'Aranyeshwar Corner, Parvati, ', 'Pune-411009', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(105, 'Gurudatta Enterprises ', '', '', 'Chikhali ', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(106, 'Kanad Enterprises ', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(107, 'Unique ', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(108, 'Excel Pack Solutions ', '', '', '', '', 'Pune ', 57, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(109, 'Pragati Paints & Allied Products ', '', '', '', '', 'Pune ', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(110, 'Arjay Printers ', '', '', 'M I D C Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(111, 'Smith International ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(112, 'Deepak Yogiom Engineers P.ltd ', '', '', 'Ambegaon Bk.', '', 'Pune ', 58, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(113, 'Lubricare P.ltd ', '', '', '', '', 'Pune ', 88, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 5100.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(114, 'Classic Automotive Indus. P.ltd ', '', '', 'Plot No,62 Block No,f-ii Midc Pimpri', 'Pune', '', 38, '', '', '020-66111823/24/66118479', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(115, 'Mahalaxmi Tool Room ', '', '', 'Midc, Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(116, 'Pandit Automotive P. Ltd (bhosari )', '', '', 'Midc Bhosari ', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(117, 'Bio Era Medical Systems ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(118, 'Navkar Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(119, 'Polymer House ', '', '', '', '', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(120, 'P. S. Enterprises ', '', '', '', '', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(121, 'Sharad Agencies ', '', '', '210, Paras Chambers, ', 'Swargate, Pune-411009', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(122, 'Monip Enterprises  ', '', '', '715,sadashiv Peth , Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(123, 'Purofil ', '', '', '42, Parvati Industrial Estate', 'Pune- Satara Road, Parvati ', 'Pune-411009', 161, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(124, 'Jayantilal & Co.', '', '', 'Shop No 1 City Trad Center Bohri Ali', '926,budhwar Peth', 'Pune ', 1, '', '', '202.24478616/32941410', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(125, 'Techmark Company ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(126, 'Energy Devices ', '', '', '39/6 Shri Moryakripa Co-op Ho. Soc', 'Karve Nagar , Pune', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(127, 'K. G. Banthia Bros ', '', '', 'Bhawani Peth, ', 'Pune.', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(128, 'Xpro India Limited', '', '', 'E-89  M. I. D. C. Ranjangaon,', 'Tal. Shirur, Dist :- Pune-412209', '', 61, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 46962.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(129, 'Varunsak Plastic Chemicals ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(130, 'K. B. Enterprises  ..Deleted', '', '', '', '', 'Pune ', 62, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(131, 'Sharang Corpo', '', '', '', '', 'Pune ', 49, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(132, 'Pandit Automotive Pvt Ltd (sahaker Nagar)', '', '', 'Sahakarnagar', '', 'Pune', 63, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(133, 'Swastik Battery ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(134, 'Creative Systems', '', '', 'Plot No 80, Secter No,1 Indrayan Nagar', 'Bhosari', 'Pune ', 18, '', '', '020-30626609', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(135, 'The Maharashtra  Agro ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(136, 'Deccan Mech & Chem. Pvt Ltd', '', '', 'T-91 Midc Bhosari', 'Pune-411026', 'P.o.no.4 G E N 0155', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(137, 'B. K. Chemicals ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(138, 'Dyglo ', '', '', 'S No 24 Belewadi', 'Pune', '', 1, '', '', '25654456.26', '', '', 'dyeglo@vsnl. com', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(139, 'Vanaz Engg Pvt Ltd ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(140, 'Global Marketing Company ', '', '', 'A/202,hans Sarower Market Yard', 'Pune411037', '', 1, '', '', '02024264492/722', '9822370395', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(141, 'Sai Lee  Surface ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(142, 'Datsons  Electronics  Pvt Ltd', '', '', 'Nanded Phata ', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(143, 'Unique Stamping ', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(144, 'Mahaveer Alloys', '', '', 'W-274,'' S'' Block, M I D C Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(145, 'Tarini Steel Co. Ltd ', '', '', 'Gat No. 399, Charoli Khurd,', 'Alandi- Wadgaon Road, Tal Khed ', 'Dist:- Pune ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(146, 'Kwality Surface Coating ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(147, 'S R Thermocote Packaging ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(148, 'Sai Fee Stores  ..Deleted', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(149, 'K P Engineering  ..Deleted', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(150, 'Teltech Instrumentation Pvt Ltd ..Deleted', '', '', 'Kharadi,', 'Pune', '', 6, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(151, 'Laxmi Hydro Pnumatic ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(152, 'K . B Enterpirses  ..Deleted', '', '', '', '', 'Pune ', 68, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(153, 'Energy System ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(154, 'Vishwas Engg Works ', '', '', 'Supreme Ind Estate .49/1.', 'Aranyeshwar Corner Pune Satara Road', 'Parvati', 1, '', '', '24220251', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(155, 'Unique Valve Pvt Ltd ', '', '', '41/3/2 Vadgaonsheri', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(156, 'Shripad Industries ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(157, 'Enoquel Engineering Works ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(158, 'Vats Polymers ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(159, 'Amego Sales  Corporation  ..Deleted', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(160, 'Moscot Industries ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(161, 'Bharat Surgical Co', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(162, 'Shreepad Industries ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(163, 'Saj Metals ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(164, 'Puja Fluid Sales Pvt Ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(165, 'Yogesh Pricission', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(166, 'Pradnya Chemicals ', '', '', 'Sr No.87, Jyotibanagar Talwade', 'Pune', '', 57, '', '', '', '9922448585', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(167, 'Aditya Enterprises ', '', '', 'C/o Dynamic Marketing Services,', 'Sr. No. 143, Tathwade,', 'Tal. Mulshi, Dist. Pune-411033', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(168, 'Virgo Engineers Ltd.( Mann)', '', '', '277, Raisoni Indus. Park. Phase (ii)', 'Village- Mann, Tal. Mulshi,', 'Hijawadi, Pune-411057', 127, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(169, 'Ashok Automotive Sales ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(170, 'Special Steel Stores', '', '', 'Bhosari M I D C ', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(171, 'Akaksha Pattern', '', '', '', 'Bhosari', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(172, 'Strapix Incorporation', '', '', '', '', 'Pune ', 57, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(173, 'Colourshine Chemicals ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(174, 'Nangesh Electric & Electronic', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(175, 'Saish Metaflow P.ltd ', '', '', '40/4 Plot No 20 Balaji Ind. Estate ', 'Vadgaon Sheri', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 2950.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(176, 'Chaitanya Indus. ', '', '', 'Urawade', '', 'Pune', 72, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(177, 'Bezel India ', '', '', 'Plot No.14 "sai Krupa" , Flat No9 Mahesh', 'Co-op,hsq.bibwewadi', 'Pune ', 1, '', '', '204215036', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(178, 'Realible Technicals ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(179, 'Vulkan Technologies P.ltd ', '', '', 'Sr. No. 539- B Kasaramboli,', 'Tal. Mulshi,', 'Pune ', 48, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(180, 'Klaus Union Engg. Pvt. Ltd ', '', '', 'Gat No. 1197, Near Ghotawade Phata,', 'Pirangut, Tal. Mulshi, ', 'Dist:- Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(181, 'Rieco Industries Ltd', '', '', 'Gat No. 144, Alandi Markal Road,', 'Dhanore, Devachi Alandi,', 'Pune- 412105 ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 16910.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(182, 'Velley Gauges & Tools ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(183, 'Virgo Valve  ..Deleted', '', '', '', '', 'Pune ', 71, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(184, 'Electromech Engineers ', '', '', '', '', 'Pune ', 73, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(185, 'Poona Tractor Center', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(186, 'V . K Engineering Works ', '', '', '', '', 'Pune ', 75, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(187, 'Vittal Agro Services ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(188, 'Raizan Steel Engineering Pvt Ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(189, 'Niroda Sales Corporation ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(190, 'Diamond Abrasive Products ', '', '', 'A-69/ T-204 Midc Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(191, 'Poton Enterprises', '', '', '', '', 'Pune ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(192, 'Thyssen Krupp Industries (i) P. Ltd', '', '', '', 'Pimpri ', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(193, 'Sneha Bearing Pvt. Ltd. ', '', '', 'Gat No. 178, Ganesh Nagar, ', 'Talawade Road, Talawade,', 'Tal. Haweli, Dist. Pune.', 78, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 2444.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(194, 'Techcalleny', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(195, 'Vedavati  Senitori Wearsh ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(196, 'Prince Glass', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(197, 'Compax Industrial System Pvt Ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(198, 'Demach Pvt Ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(199, 'Pathak Alloys Pvt Ltd ', '', '', '', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(200, 'Akshay Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(201, 'Hardik Founders & Engineers P.ltd ', '', '', 'Sr. No. 246/3/7, Hinjawadi, ', 'Pune-411057', '', 99, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 4259.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(202, 'Uma Enterprises ', '', '', '133/1 Mumbai Banglaore Hiway,', 'Opp. Vardhaman Petrol Pump,', 'Warje, Pune.', 79, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(203, 'Yasho Electro Works ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(204, 'Ganesh Fabrotech P.ltd ', '', '', '', '', 'Pune', 57, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(205, 'Ravi Technocraft ', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(206, 'Veekhay Metalliks P.ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(207, 'Metal Impregnations (i) P.ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(208, 'Poonam Designs ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(209, 'Thermax Ltd (b&h) Group', '', '', '', '', 'Chinchwad ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(210, 'Aroma Exports ', '', '', 'Narhe ', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(211, 'Parmount Engineering ', '', '', '', '', 'Pune ', 80, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(212, 'Mahalaxmi Casting Pvt. Ltd ', '', '', 'Gat No. 323 Plot No.2, Pirangut,', 'Tal. Mulshi,', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(213, 'Chintamani Enterprises ', '', '', '', '', 'Bhosari ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(214, 'Aakar Engineers ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(215, 'M Las Sales Corp.', '', '', '', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(216, 'Dattaraj Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(217, 'Kemisolv ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(218, 'Jain Corp. (india)', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(219, 'Procom Systems ', '', '', 'Pune ', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(220, 'Span Met Tech Enterprises ', '', '', 'Ramtekdi', '', 'Pune', 81, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(221, 'Sagar Steels & Np Enterprises ', '', '', 'Vitthalwadi & Gultekdi ', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(222, 'Anish Trading Co.', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(223, 'Vijayesh Instruments Pvt. Ltd. ', '', '', '11, Manik Baug, Vadgaon Bk.', 'Sinhgad Rd. Pune-411051', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(224, 'Bhogilal Chandlal Shah', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(225, 'Shruti Enterprises', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(226, 'Inox Air Product ', '', '', '', 'Bhosari', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(227, 'Hoganas India Ltd (wagholi)', '', '', 'Milkat No. 3286, Nagar Road,', 'Katewadi Village, Wagholi, Tal. Haweli', 'Dist:- Pune', 83, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(228, 'Dusane Garment', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(229, 'Mather & Platt Pumps Ltd.(kolhapur)', '', '', 'E- 25 Midc , ', 'Gokul Shirgaon, ', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(230, 'Western Precicast Pvt. Ltd.,', '', '', 'Gat. No.170 Midc', 'Kupwad,', 'Sangli', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(231, 'Pnp Techno ', '', '', '', '', 'Ichalkaranji', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(232, 'Shree Pomani Metal & Alloys ', '', '', 'Midc Kupwad, ', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(233, 'Vijay Engineering Works', '', '', '', 'Jaysingpur', 'Kolhapur', 37, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(234, 'Dynamic Engineers', '', '', 'Pargaon,', '', 'Kolhapur', 84, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(235, 'Manoj Industries', '', '', 'Midc Shiroli,', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(236, 'Navjeevan Machine Tools Pvt. Ltd', '', '', 'Midc Kupwad,', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(237, 'Bespask Engineers Pvt. Ltd.,', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(238, 'Krupa Metal Industries', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(239, 'Netmech Foundry Pvt. Ltd', '', '', 'Shri Laxmi Co-op Indus. Estatre.,', 'Hatkanangale,', 'Kolhapur', 155, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(240, 'New Dilip Industries', '', '', 'Midc Kupwad,', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(241, 'S R Engineers', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(242, 'Gnat Foundry Pvt. Ltd', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(243, 'Yash Engineers', '', '', 'Midc Gokul Shirgaon,', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(244, 'Dattaraj Industris', '', '', 'Industrial Estate,', 'Ichalkaranji', 'Kolhapur', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(245, 'Sps Engineers', '', '', 'Industrial Estate,', 'Ichalkaranji,', 'Kolhapur', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(246, 'Shah Precicast Pvt. Ltd.,', '', '', 'E-35 Midc Kupwad,', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(247, 'Arrow Metalliks', '', '', 'Midc Kagal,', 'Tal. Hatkanangale,', 'Kolhapur', 51, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(248, 'Rohini Metal Industries', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(249, 'Thermochem Process Pvt Ltd', '', '', 'Midc Gokul Shirgaon,', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(250, 'Dudhane Fasteners ', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(251, 'Pratap Enterprises', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(252, 'Suyog Engineers', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(253, 'Dhaval Engg Works', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(254, 'Arnimech Products Pvt. Ltd', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(255, 'Akshay Metals', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(256, 'Shri Datta Founders & Engineers', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(257, 'Vijeta Switchgear ', '', '', 'Kupwad', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(258, 'General Machine Tools', '', '', 'Yadrav, Ichalkarnji', 'Kolhapur', '', 29, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(259, 'Prabha Industries', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(260, 'Modern Industries', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(261, 'Shri Venkateshwara Metalliks Pvt Ltd', '', '', 'Wathar', 'Kolhapur', '', 91, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(262, 'Trinitas Engineering & Foundry', '', '', 'Midc Kagal', '', '', 51, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(263, 'Fie Sperotech', '', '', 'Hatkanangale', 'Kolhapur', '', 155, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(264, 'Suyash Castings Pvt Ltd', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(265, 'Advance Engg', '', '', 'Midc Gokul Shirgaon ', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(266, 'Pragati Foundry ', '', '', 'Hatkanangale ', 'Kolhapur', '', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(267, 'Arjay Alloys', '', '', 'Midc Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(268, 'Parikh Mettaliks', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(269, 'Kirloskar Brothers Ltd.', '', '', 'P.o. Kirloskarwadi,', 'Sangli', '', 94, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(270, 'Chitradeep Industries ', '', '', 'Midc Shiroli ', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(271, 'Kagal Bearings P.ltd ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(272, 'Snsp Engineering P. Ltd ', '', '', 'Midc, Gokul Shirgaon ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(273, 'Mihir Auto Components ', '', '', 'Midc Shiroli', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(274, 'Forune Marketing ', '', '', 'Midc, Shiroli', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(275, 'S. B. Arwade & Co.', '', '', '', '', 'Kolhapur ', 69, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(276, 'Menon Metalliks P.ltd ', '', '', 'Midc Shiroli ', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(277, 'Shri Ramprasad Enggs. ', '', '', '', '', 'Kolhapur ', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(278, 'Shri Gajraj Indsutries ', '', '', '', '', 'Kolhapur ', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(279, 'Bashko Engg P.ltd ', '', '', 'Midc Kupwad', '', 'Sangli ', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(280, 'Anand Metal Industries ', '', '', 'Palus ', '', 'Sangli ', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(281, 'Mayur Engg. Work', '', '', 'Sangli', '', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(282, 'Sagar Metal', '', '', 'Gokul Shirgaon,', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(283, 'Aakar Engineers P. Ltd', '', '', 'Kolhapur', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(284, 'Arwade Enterprises', '', '', 'Kolhapur', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(285, 'Ceraflux India Pvt. Ltd', '', '', 'Midc Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(286, 'Jayashree Electron Pvt Ltd', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(287, 'Rohan Enterprises', '', '', 'S.no.121,wadmukhwadi,charoli,', 'Dighi-alandi Road', 'Pune4110105', 36, '', '', '(020)25139114,27185016', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(288, 'Accusharp ', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(289, 'Trade En Tolls', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(290, 'B. K. Steels ', '', '', 'Alandi ', '', 'Pune ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(291, 'K. B. Enterpirses ', '', '', '2076, Ganesh Colony, Rupeenagar,', 'Talawade, Pune-412114', '', 78, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(292, 'Savitri Automation ', '', '', 'Plot No,37/2 D-2,midc ', 'Chinchawad', 'Chinchwad Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(293, 'United Filters ', '', '', 'Sr. No. 164, United House,', 'Near Shrinath Wearhousing, Fursungi,', 'Pune -412308', 46, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(294, 'Concentric Pumps (i) Pvt Ltd', '', '', 'Lonikanad', '', 'Pune ', 100, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(295, 'Quality Engg Co.', '', '', 'Phursungi', 'Pune', '', 101, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(296, 'Hoganas India Ltd (ahamednagar)', '', '', 'Ahamenagar', '', '', 70, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(297, 'Deep Darshan Engineers', '', '', 'Bhosari ', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(298, 'Goyal Foundry', '', '', 'Chinchwad', '', 'Pune', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(299, 'K. C. Toolroom', '', '', 'Bhosari', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(300, 'Avanti Cable Pvt. Ltd', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 1190.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(301, 'Hitex ', '', '', 'Ravet', '', 'Pune ', 102, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(302, 'Varm Press-e-gen', '', '', 'Nanded Phata', 'Pune', '', 103, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(303, 'Unpa Engg', '', '', 'Kasurdi', 'Pune', '', 92, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(304, 'Craft & Technik Industries  ..Deleted', '', '', 'Pune', '', '', 1, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(305, 'Arihant Metals', '', '', 'Gokul Shigaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(306, 'Raj Steel & Tube ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(307, 'Modern Enterprises ', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(308, 'Giriraj Trading Co.', '', '', 'Sukhsagar Nagar,', 'Pune', '', 106, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(309, 'J. N. Marshall', '', '', 'Kasarwadi, Pune', '', '', 97, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(310, 'Roopa Engg.', '', '', '', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(311, 'Shalaka Indus.', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(312, 'Praveen Indus.', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(313, 'Delta Indus.', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(314, 'R. S. Indus.', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(315, 'Patil Engg', '', '', '', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(316, 'Shri Akshay Indus', '', '', '', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(317, 'Shree Samarth', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(318, 'Shreeji Sales', '', '', '', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(319, 'Parikh Udyog', '', '', 'Gokul Shirgaon', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(320, 'Vally Gauges', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(321, 'Thorat Industries ', '', '', '', 'Kirloskarwadi ', 'Sangli ', 94, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(322, 'Ashok Engineers ', '', '', 'Y.p.pawar Nagar ', '', 'Kolhapur ', 52, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(323, 'Microtech ', '', '', 'Midc Gokul Shirgaon ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(324, 'Allied Products ', '', '', 'Midc, Gokul Shirgaon  ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(325, 'Karan Industries ', '', '', '', 'Midc, Gokul Shirgaon ', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(326, 'Manasi Pressing Pvt. Ltd ', '', '', 'Gat No. 177,171,172, Alandi- Markal Rd, ', 'Village Dhanore, Alandi, ', 'Tal. Khed, Dist:- Pune', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(327, 'The Mahareshtra Argo Industries', '', '', 'Plot No. 52-2- D, M I D C, Chinchwad, ', 'Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(328, 'Precitech Indus. ', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(329, 'Sarda Enterprises ', '', '', 'X-6, General Block, Opp. Philips India, ', 'M I D C Bhosari,', 'Pune- 411026 ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(330, 'Vega Techno Systems P. Ltd ', '', '', 'Pimpri ', 'Pune', '', 73, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(331, 'Unision Clamping Devices ', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(332, 'P. H. Gandhi ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(333, 'Asian Engineers Sales Crpo.', '', '', 'Chakan ', '', 'Pune ', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(334, 'Deputy Engineers ', '', '', 'Dapodi ', 'Pune', 'Pune', 107, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(335, 'Pratibha Argo & Co.', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(336, 'Anshubham Industries ', '', '', '', '', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(337, 'Self  ..Deleted', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(338, 'Karad Enterprises ', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(339, 'M. V. Gandhi & Co.', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(340, 'Unity Gaugs & Tool', '', '', 'Bhosari ', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(341, 'K. M. Pattern ', '', '', '', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(342, 'M. P. Enterprises ', '', '', '', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(343, 'Meror Auto Componants Pvt Ltd ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(344, 'Maswt Industries ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(345, 'Oswal Sales ', '', '', '', 'Handewadi ', 'Pune ', 108, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(346, 'Auram App Tech P.ltd ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(347, 'Chaney & Company ', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(348, 'Vision Sales & Services ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(349, 'Linkwell Engineers ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(350, 'S N R Electronocs ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(351, 'E S Memon ', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(352, 'Pratham Enterprises ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(353, 'Ashirwad Industries Products ', '', '', '254, Shukrawar Peth, ', 'Pune-411002', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(354, 'Jay Bee Hardware ', '', '', 'Pimpri ', '', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(355, 'Shree Systems', '', '', '', 'Sinhagad Road ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(356, 'Opil Industries ', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(357, 'M. M. Enterprises ', '', '', 'Sr. No. 81/2, Opp. Agrawal Godown,', 'Shivane Industrial Estate,', 'Tal. Haweli, Dist. Pune-411023', 59, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 4390.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(358, 'Nayar ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(359, 'Miloni Industries Distributers ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(360, 'Aask Precision Engginering ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(361, 'Shree Engineering ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(362, 'Noble Agencies ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(363, 'Shreeyash Industries ', '', '', '', 'Bhosari ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(364, 'Shaliwatan Traders  ..Deleted', '', '', '', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(365, 'Shaliwahan Traders ', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(366, 'Gokul Traders ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(367, 'S. R.date & Associates ', '', '', '', '', 'Pune ', 22, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(368, 'Sidharth Leather Work', '', '', '', '', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(369, 'Manmohan Ind', '', '', '123 New Timber Market', '', 'Pune ', 80, '', '', '26445275', '9822038514', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(370, 'Z F Stearing Gear ', '', '', 'Vadu Budruk ', '', 'Pune ', 112, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(371, 'Swapnil Stamping Ind ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(372, 'Industrial Linkars ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(373, 'Gurukrupa Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(374, 'Samarth Metal Industries ', '', '', 'Hissa No. 370, Nimbalkar Nagar,', 'Tathwade, Pune-411033', '', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(375, 'Dattaatray Enterprises', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(376, 'Transpower Equipment ', '', '', 'Sr. No. 54, Plot No.63,  ', 'Swami Vivekanand Co-op I. E., Satavnagar', 'Handewadi Road, Hadapsar, Pune-411028', 177, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(377, 'Shalimar Machine Tools', '', '', 'Kasarwadi ', '', 'Pune ', 97, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(378, 'Panchsheel Corporation ', '', '', 'Chinchwad', '', 'Pune', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(379, 'Fontasey Enggs Export ', '', '', '', '', 'Pune', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(380, 'Menon Bearing Ltd ', '', '', 'Midc, Gokul Shirgaon ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(381, 'Bharat Auto ', '', '', '', 'Hatakangle ', 'Kolhapur', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(382, 'Quality Casting ', '', '', 'Midc Shiroli ', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(383, 'Marvelous Metal P. Ltd ', '', '', 'Midc Gokul Shirgaon', '', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(384, 'Aaryavaibhav Enterprises ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(385, 'Trinity Die Forge Ltd ', '', '', 'Midc, Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(386, 'Paranjape Autocast P. Ltd (15/16)', '', '', 'J 15/16 Midc', 'Pune', 'Pune', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(387, 'Kotibhaskar ', '', '', '', 'Midc, Satara', 'Satara', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(388, 'V. S. Industries', '', '', '', 'Gokul Shirgaon', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(389, 'Gajaraj Engg', '', '', '', '', 'Hatkanangale', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(390, 'Sushila Precicast Pvt. Ltd', '', '', 'Midc Kupwad,', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(391, 'Ujwal Engineering', '', '', 'Shiroli', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(392, 'Profound Enterprises', '', '', 'Ichalkaranji', '', '', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(393, 'Enpro Enter', '', '', 'Shiroli', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(394, 'M. R. Indus', '', '', 'Palus', 'Sangli', '', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(395, 'Yash Metallics', '', '', 'Shiroli', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(396, 'Maharashtra Schooter', '', '', '', '', 'Satara', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(397, 'Samarth Industries', '', '', 'Plot No.454, Sector No.2, Indrayaninagar', 'Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(398, 'Genius Rubber Indus', '', '', 'Chikhali', 'Pune', '', 113, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(399, 'Trimurti Engineering', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(400, 'D & H Scherom Electrodes', '', '', 'Rasta Peth', 'Pune', '', 114, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(401, 'Mech Engineering Services ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(402, 'Gayatri Chemical ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(403, 'Rayson Steel Industries ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(404, 'Melco Steel Industries ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(405, 'Hitech Engineers ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(406, 'Balaji Thermocol Industries ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(407, 'Chemeall Pai', '', '', 'Koregaon Bhima ', '', 'Pune', 115, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(408, 'Watter Pack Solution ', '', '', '', '', 'Pune ', 116, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(409, 'Heatex', '', '', '', 'Pimpri', 'Pune', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(410, 'Jai Kali Mata Engineering ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(411, 'Fluto Holder & Handels ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(412, 'Bharat Center Works ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(413, 'Chitanya Enterprises', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(414, 'Lawkim Limited ', '', '', '', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(415, 'Jawad Tools Center ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(416, 'Venus Enterprises ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(417, 'India Ceramic', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(418, 'Megatech ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(419, 'Shri Swaminarayan Industries ', '', '', 'Bhosari ', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(420, 'Sukumar Shankar Patil ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(421, 'Ganesh Pattern ', '', '', '', '', 'Pune', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(422, 'Nandkumar Othari ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(423, 'Jayhind Enterprises ', '', '', '', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(424, 'Bombay Dying ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(425, 'Calderys India Pvt Ltd ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(426, 'Teltech Instrumentation Pvt Ltd', '', '', '28/4-b Kharadi Off Nagar Road', '', 'Pune ', 6, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(427, 'Rahul Bagi', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(428, 'Ruchi Pisto Chem', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(429, 'Mulbeel', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(430, 'Aver Engineering ', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(431, 'Amir Steel ', '', '', '', '', 'Pune', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(432, 'Bhavani Iron Indus. P.ltd ', '', '', '', '', 'Kolhapur', 69, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(433, 'A. M. Joshi ', '', '', 'Midc, Shiroli ', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(434, 'Ravi Enterprises ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(435, 'Shri Ramprasad Enggs.  ..Deleted', '', '', '', '', 'Kolhapur ', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(436, 'J. N. Sales', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(437, 'Max Plastic Processing', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(438, 'Realible Industries Products ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(439, 'Kayson Steel Industries ', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(440, 'Ghatge Patil Indus', '', '', 'Uchgaon', 'Kolhapur', '', 44, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(441, 'Kgp Foundry', '', '', 'Shiroli', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(442, 'Monark Steel', '', '', '', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(443, 'Barvepco Cast Alloys', '', '', 'Palus', 'Sangli', '', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(444, 'Maroo Enggg', '', '', 'Kupwad', 'Sangli', '', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(445, 'Bhaba Engg', '', '', 'Sangli', '', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(446, 'Pioneer Engg', '', '', '', '', 'Pune', 73, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(447, 'Kankriya Indus.', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(448, 'Sunita Indus', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(449, 'Mahalaxmi Pumps', '', '', 'Palus', 'Sangli', '', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(450, 'Hsk Traders ', '', '', '', 'Chakan ', 'Pune', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(451, 'Master Metals ', '', '', 'Midc, Gokul Shirgaon ', '', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(452, 'Auto Parts', '', '', '', '', '', 37, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(453, 'Consolidated Hoist P. Ltd', '', '', 'Gultekadi', 'Pune', '', 90, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(454, 'G. B. Iron & Steels ', '', '', 'Palus', 'Sangli', '', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(455, 'Santosh Pattern', '', '', 'Satara Road,', 'Satara', '', 123, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(456, 'Metal Temple P Ltd', '', '', 'Yadrav', 'Ichalkaranji', 'Kolhapur', 29, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(457, 'Duggal Brothers ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(458, 'Karveer Engg', '', '', '', '', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(459, 'Shree Siddharaj Indus', '', '', '', '', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(460, 'Vikram Engineers', '', '', '', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(461, 'Bravepco Cast Alloy P.ltd ', '', '', 'Palus ', '', 'Sangli ', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(462, 'Sound Casting P.ltd ', '', '', 'Midc Kagal ', '', 'Kolhapur ', 51, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(463, 'Prathamesh Modified', '', '', '', 'Top ', '', 56, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(464, 'Sheetal Chemicals ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(465, 'S. R. Engineers ', '', '', '', 'Midc Gokul Shirgaon ', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(466, 'Prathmesh Udyog ', '', '', '', 'Top ', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(467, 'Vivek Ghatge ', '', '', '', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(468, 'Bajaj Auto Ltd ', '', '', 'Chakan ', '', 'Pune ', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(469, 'Hrithik Tools P.ltd ', '', '', '', 'Midc Bhosari ', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(470, 'Super Traders ', '', '', '', 'Midc, Bhosari ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(471, 'Kedarnath Indus. ', '', '', 'Midc, Gokulshirgaon ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(472, 'Sujit Enterprises ', '', '', '', 'Chikhali ', 'Pune ', 113, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(473, 'Om Ganesh Engginering ', '', '', '', 'Kolhapur ', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(474, 'Ashapura Casting P.ltd ', '', '', '', 'Midc, Shiroli ', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(475, 'Airochem Enggs.', '', '', '', 'Midc Shiroli ', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(476, 'Kanaria Indus. ', '', '', '', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(477, 'Jugali Iron & Steel P.ltd ', '', '', '', 'Miraj ', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(478, 'A K ..Deleted', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(479, 'Ravideep Enggs. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(480, 'Siddhivinayak Foundry & Enggs. ', '', '', 'Midc Gokul Shirgaon ', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(481, 'Paramount Micronix ', '', '', 'Midc, Gokul Shirgaon ', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(482, 'Pradeep Sweets P.ltd ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(483, 'Micro Matic Mahcin Tools P.ltd ', '', '', '', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(484, 'Rocket Enggs. ', '', '', '', 'Midc Shiroli ', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(485, 'S. K. Cast Alloys ', '', '', '', '', 'Palus ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(486, 'Precision Development Indus ', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(487, 'Ktr Coupling', '', '', 'Chinchwad', 'Pune', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(488, 'Raj - Mangal Enggs. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(489, 'Litel Infrared Sys. P.ltd ', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(490, 'Palus Enginnring', '', '', '', '', 'Sagali', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(491, 'Kalapi Enggs. Works ', '', '', '', '', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(492, 'S. J. Iron & Steels P.ltd ', '', '', 'Midc Shiroli', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(493, 'Talegoonkar Profile ', '', '', '', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(494, 'Menon & Menon Ltd ', '', '', 'Vikramnagar ', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(495, 'Laxmi Sheel Indus. ', '', '', '', 'Midc Gokulshirgaon ', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(496, 'Pannalal & Sons ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(497, 'Rex Ployextraction ', '', '', '', '', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(498, 'Prime Co. Op.', '', '', '', '', 'Jaysingpur ', 37, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(499, 'Parishram Enterprises', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(500, 'Bervapco Cast Alloys  ..Deleted', '', '', '', '', 'Palus ', 74, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(501, 'Thorat Enterprises ', '', '', '', '', 'Sangli ', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(502, 'Evergreen Traders ', '', '', '', 'Dapodi ', 'Pune', 107, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(503, 'Madhavnagar Steels & Alloys ', '', '', '', '', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(504, 'Suyog Enterprises ', '', '', '', 'Kolhapur', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(505, 'Tata Motars Limited', '', '', '', 'Bhosari ', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(506, 'S.r .engineerig', '', '', '', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(507, 'Fie Sperotech ..Deleted', '', '', '', 'Kolhapur', '', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(508, 'Urvashi Enterprises', '', '', '', '', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(509, 'Mascarenhas Ent & Mft Co', '', '', 'Kolhapur', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(510, 'R. D.industries  ', '', '', '', '', 'Satara', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(511, 'Trimurti Filters & Gauges ', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(512, 'Abhijeet Casting ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(513, 'Gajendra Spares ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(514, 'Shri Ram Swithgears ', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(515, 'Recicoat Indus. ', '', '', '', 'Chikhali ', 'Pune', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(516, 'Nichrome (i) Ltd', '', '', '', '', 'Pune ', 93, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(517, 'Ichalkaranji Metally ', '', '', 'Ichalkaranji ', '', 'Pune ', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(518, 'A. K. Enterpries', '', '', 'Midc Gokul Shirgam', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(519, 'Kerbkonus Fasteners Pvt Ltd', '', '', 'Midc Gokul Shirgaon', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(520, 'Shri Gurukrupa Enggineering', '', '', 'Chinchwad', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(521, 'Well-site Interonation', '', '', '(1) Pvt Ltd ', 'Midc Pimperi ', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(522, 'Nipurna Engg P Ltd', '', '', 'Midc Shiroli ', 'Kolhapur', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(523, 'Jamadar Fabricators', '', '', 'Katraj', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(524, 'Aps Heat Treaters', '', '', 'Pirangut', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(525, 'Tuskar Trading P.ltd ', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(526, 'Mohan Industries ', '', '', '', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(527, 'Gemini Consotium', '', '', '', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(528, 'S.k.cast Alloys ..Deleted', '', '', 'Plaus', '', 'Sangli', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(529, 'The Karson', '', '', 'Kolhapur', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(530, 'S.k.p.engg', '', '', '', '', 'Sangli', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(531, 'Arnimech Heavy Engg.', '', '', 'Mine Shiroli', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(532, 'Siddharth Engg. Cop.', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(533, 'Fine Cut Tech. Pvt .ltd', '', '', 'Kasurdi', '', '', 92, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(534, 'Shree Ramprasad', '', '', '', 'Bhosari ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(535, 'Success Automation', '', '', '', 'Chikhali ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(536, 'R.p.enterpries ..Deleted', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(537, 'Budhwar Peth Bhori Ali ..Deleted', '', '', 'Pune', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(538, 'Giridhar Nagar', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(539, 'Pamesh & Co.', '', '', '', '', 'Chinchwad', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(540, 'M & K  Industries', '', '', 'Midc ', 'Kagal', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(541, 'Shree Kedar Metal Foundry', '', '', 'Palus', '', '', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(542, 'M. P. M. P Ltd ..Deleted', '', '', 'Sanaswadi', '', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(543, 'Utkarsh Fabri. P.ltd', '', '', 'Kupwad', '', 'Sangli', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(544, 'Micro Enggs. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(545, 'Balanncing Instrument ', '', '', '', '', 'Miraj ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(546, 'Bharat Forge Ltd ', '', '', '72/76,  Mundhwa', 'Pune-411001', '', 40, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(547, 'Kolhapur Industries', '', '', 'B 53 Shiroli', 'Midc, Shiroli', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(548, 'Rotadyne Tools Pvt Ltd', '', '', 'Miraj', '', 'Miraj', 32, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(549, 'Js  ..Deleted', '', '', '', '', '', 132, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(550, 'Mogara Cosmic P.ltd', '', '', '', 'Bhosari ', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(551, 'Isha Engineers & Fab.', '', '', '', 'Pimpri ', 'Pune ', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(552, 'Sahil Engineers', '', '', 'Kolhapur', 'Kolhapur', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(553, 'Mate Chembers', '', '', 'Gultekadi ', 'Pune', 'Pune 411 019', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(554, 'Sanes', '', '', 'Sr. No. 131, Pirangut, Tal Mulshi', 'Dist. Pune-412108', 'Ph. No. 32305297', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(555, 'Sangram Metal Processes', '', '', 'Kolhapur', '', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(556, 'Hydro Pnumatic Power', '', '', '', '', 'Bhosari', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(557, 'Chougule Enggs. ', '', '', '', 'Shiroli', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(558, 'Taskar Trading P.ltd ', '', '', '', 'Khed ', 'Pune ', 134, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(559, 'Agp ', '', '', 'Kolhapur ', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(560, 'Roho System ', '', '', '', 'Pune', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(561, 'Shimco Steel Industries', '', '', 'Plot No.167 T Block, M. I. D. C. Bhosari', 'Pune- 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(562, 'Arfa Udyog ', '', '', 'L42, Midc Kodali ', 'Satara ', 'Satara ', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(563, 'Shree Ganesh Metal Works ', '', '', '', 'Sangli ', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(564, 'Laxmi Alloys', '', '', 'Shiroli', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(565, 'D.b.& Sons', '', '', 'Kolhapur', '', '', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(566, 'S. M. Foundry ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(567, 'Maruti Product', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(568, 'Dran Engineers Pvt Ltd', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(569, 'Jay Industries', '', '', 'Kolhapur', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(570, 'Samir Casting Pvt Ltd', '', '', 'Kolhapur', '', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(571, 'Clean Fast Corporation', '', '', 'Kolhapur', 'Kolhapur', 'Kolhapur', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(572, 'Ace Engineers ', '', '', '', 'Pune', 'Bhosari ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(573, 'Robotech Systems ', '', '', '', 'Pune', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(574, 'Shree Gajanan Metals Indus.', '', '', '', 'Arjunagar ', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(575, 'Awanti Cables P.ltd  ..Deleted', '', '', '', 'Bhosari ', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(576, 'Sawant Steel & Alloy', '', '', 'Sangli', '', 'Palus', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(577, 'Malati Foundry P.ltd ', '', '', '', '', 'Kolhapur ', 26, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(578, 'Shri Ram Enterprises', '', '', '', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(579, 'Rayson Sandchem Pvt Ltd', '', '', 'Shiroli', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(580, 'United Casting', '', '', 'Vikramnagar ', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(581, 'Shalini Udyog ', '', '', '', 'Midc Shiroli ', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(582, 'Virgo Valve & Controls ..Deleted', '', '', 'Hinjewadi Pune', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(583, 'Rax Polyextrusion Ltd', '', '', 'Unit Ii ', 'Kupwad ', 'Sangli ', 33, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(584, 'Magna Casting ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(585, 'Vijayendra Indus. ', '', '', '', 'Shiroli ', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(586, 'Unique Enggs. ', '', '', '', '', 'Palus', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(587, 'S. S. Pattern Works', '', '', '', '', 'Pune', 54, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(588, 'Sweet Home ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(589, 'Suzlon Generators P.ltd ', '', '', '', '', '', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(590, 'Mnk Indus. ', '', '', '', 'Kagal', 'Kolhapur', 51, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(591, 'Thorat Valves Pvt Ltd', '', '', '', '', 'Sangli ', 94, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(592, 'Balaji Packing Industries', '', '', 'Kolhapur', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(593, 'Industrial Ventures', '', '', 'Alandi', '', 'Pune ', 36, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(594, 'Involute Technologies', '', '', '', '', 'Alandi ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(595, 'Mahalaxmi Minerals ', '', '', '', 'Midc, Gokul Shirgaon ', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(596, 'Matoshri Indus', '', '', '', 'Palus', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(597, 'Ajinkya Indus.', '', '', '', 'Palus ', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(598, 'Sanwant Steel & Alloys ', '', '', '', 'Palus ', 'Sangli ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(599, 'Shree Balaji', '', '', 'Kolhapur', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(600, 'Ideal Wadan', '', '', '', '', 'Palus', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(601, 'Barvelovs Metal Pvt Ltd', '', '', 'Gokul Shirgaon', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(602, 'Magna Industries', '', '', 'Hatkanangale', 'Kolhapur', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(603, 'Delaval P.ltd ', '', '', '', '', 'Karad', 64, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(604, 'Aav-em Ele. P.ltd ', '', '', '', '', 'Pune', 83, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(605, 'S. N. Marketing ', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(606, 'Atlas Capco', '', '', '', '', 'Pune', 100, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(607, 'Mihir Enterpries', '', '', 'Midc Shiroli', 'Kolhapur', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(608, 'Ateq System Analyics', '', '', 'Wagholi', '', 'Pune', 83, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(609, 'Sanjeev Industries. ', '', '', 'M I D C, Bhosari ', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(610, 'Genuine Enterprises ', '', '', '', 'Kolhapur', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(611, 'Dev Metalliks', '', '', '', 'Kolhapur', '', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(612, 'Paranjape Auto Cast Pvt Ltd', '', '', '', 'Bhosari', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(613, 'Cromton Greaves Ltd. ( Ahmednagar)', '', '', 'A-6/2, M. I. D. C.', 'Ahmednagar - 414111', '', 70, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(614, 'The Globe Ele. Indus. ', '', '', '', 'Hadapsar ', 'Pune', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(615, 'Laxmi Pumps ', '', '', '', 'Kolhapur ', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(616, 'Abhijeet Indus. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(617, 'Ravat Fab.', '', '', '', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(618, 'S.b.reshellers  Pvt Ltd', '', '', 'Midc, Shiroli', 'Kolhapur', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(619, 'Intergrated Metwork Products ', '', '', 'S. No 143/2/2/4', 'Tathwade ', 'Pune', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(620, 'Dish Indus.', '', '', '', '', 'Shiroli ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(621, 'Jaihind Enterprises', '', '', '', 'Bhosari ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(622, 'Anand Enterpries', '', '', '134 Nanapeth', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(623, 'Spin - N- Cast (unit - Ii)', '', '', 'Kasar Amboli', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(624, 'Raut .v.y.', '', '', 'Bhosari', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(625, 'Premier Ltd', '', '', 'Chaka', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(626, 'S.jaykumar Offset Pvt L:td', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(627, 'Shree Craners', '', '', 'S.no-37-2narhe Ambegoan Road, ', 'Pune', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(628, 'Bhogilal Chotalal Shah', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(629, 'Laxmi Engineering Works', '', '', 'Miraj', 'Sangli', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(630, 'Valve Power', '', '', 'Shiroli', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(631, 'R. N. Inuds ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(632, 'Deesha Engg. Works', '', '', 'Bhosari', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(633, 'Anita Enterpries', '', '', 'Pune', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(634, 'Shree Industries', '', '', 'Midc Gokul Shirgaon', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(635, 'Shri Swami Samarth', '', '', 'Midc Shiroli', '', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(636, 'Jayhind Automotion Pvt Ltd', '', '', '', 'Bhosari ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(637, 'Axis Engineering Works', '', '', 'Midc Shiroli', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(638, 'S.s.industries', '', '', 'Ichalkaranji', '', 'Ichalkaranji', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(639, 'Ranue India Pvt Ltd', '', '', 'Chinchwad', '', 'Pune ', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(640, 'Asmita Patterns ', '', '', '', '', 'Gondhale Nagar ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(641, 'Walchandnagar ', '', '', '', '', 'Satara', 17, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(642, 'Tushar Trading P. Ltd ', '', '', '', '', 'Pune ', 92, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(643, 'Intech Auto- Stores & Com.pvt Ltd', '', '', 'Urawade', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(644, 'Global Engineering', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(645, 'Venkateshwara Metalliks', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(646, 'Ukuipment Designs', '', '', '', 'Hadapsar ', 'Pune', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(647, 'Morya Allu- Cast Alloys', '', '', 'Palus', 'Palus', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(648, 'Cormton Greaves', '', '', 'Ahamad Nagar', '', '', 70, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(649, 'S. D. Indus. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(650, 'Omkar Industries ', '', '', 'Plot No. 122, Sec. No.10,pcndta  ', 'Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(651, 'Shri Ram Foundry', '', '', 'Ashta', '', '', 25, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(652, 'Kiran Global Chems. Ltd', '', '', 'Yadrav', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(653, 'Kalpataru Industries', '', '', '49, Sangamnagar, Pune- Satara Road,', 'Bibwewadi, Pune- 411009', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(654, 'Sansui Electronics', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(655, 'S.k.cast Alloys', '', '', 'Palus', '', 'Sangli', 138, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(656, 'Mahalaxmi Industries', '', '', 'Gokulshirgaon', 'Midc,kolhapur', '', 139, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(657, 'Elecon Enterpries', '', '', 'Pune', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(658, 'V.k.gupte & Sons', '', '', '', 'Pune', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(659, 'Vardhan Works Pvt Ltd', '', '', 'Karve Road,pune', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(660, 'Purva Metals', '', '', 'Miraj', '', '', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(661, 'Rgp Enterpries', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(662, 'Kaneri Enterpries', '', '', 'Midc Shiroli', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(663, 'Nutan Engineers & Fabri.', '', '', 'Midc Gokulshirgaon', 'Kolhapur', 'Kolhapur', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(664, 'Hari Oum Foundry ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(665, 'Krishna Valley Argo (i) Ltd ', '', '', '', '', 'Khed-shivapur ', 28, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(666, 'Kusum Casting P.ltd ', '', '', '', '', 'Shiroli ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(667, 'Mhalsakant Enterprises', '', '', '', 'Bhosari ', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(668, 'Shree Akshay Indus. ', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(669, 'Metals ', '', '', '', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(670, 'Ksp Foundry Services ', '', '', '', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(671, 'Tulsi Foundry P. Ltd ', '', '', '', '', 'Kupwad ', 10, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(672, 'Gainmax Ferrocast P. Ltd ', '', '', '', '', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(673, 'Shree Gajanan Enggs. ', '', '', '', 'Pune', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(674, 'Trinity Auto Components Ltd', '', '', ' Gat No.1419/2 Shikrapur', 'Shikrapur', 'Pune ', 141, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 11751.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(675, 'Veena Industries Ltd.', '', '', 'Nanekarwadi Chakan ', 'Chakan', ' Dist.pune ', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(676, 'Sanjeev Industries & Arjay Printers', '', '', 'Midc', 'Bhosari ', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(677, 'United Enviro Systems', '', '', 'S.no.164 Phursunghi ', 'Pune4120308`', '', 46, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(678, 'Shree Enterprises', '', '', 'S.no.38 Keshav Nagar', 'Mundhwa', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(679, 'Rajendra Steel', '', '', '71,raviwar Peth', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(680, 'Uniti Bushes $ Tools Co', '', '', '101 Rasta Peth', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(681, 'Jawad Tools Centre', '', '', '988. Raviwar Peth', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(682, 'Ultra Precision Spindles Pvt.ltd.', '', '', 'S.no.166 Nanded Phata ', 'Pune411041', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(683, 'Pulse Services', '', '', '591 Sai Ganesh Buldg', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(684, 'Paramount Engineering', '', '', 'Plot No 114 . Tiny Co-op Ind Estate', 'Kondhwa ( Bk), Pune-411048', '', 136, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(685, 'Mahle Filter Systems (i) Ltd', '', '', 'Gat No 410/411 Mauje Urawade', 'Pirangut', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(686, 'D S Enterprises', '', '', 'Laxminagar Pimpri', 'Pune', '', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(687, 'House Of Forms ', '', '', '191,kasba Peth', 'Pune', 'Pune ', 145, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(688, 'Unison Valve Pvt Ltd', '', '', '41/3/2 Vadgaon Sheri ', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(689, 'Ajay Metachem Sud -chemie Pvt. Ltd( Mundhwa) ', '', '', 'Sr. No. 72/76  Mundhwa,', 'Pune-411036', '', 40, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 43181.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(690, 'Ajay Metachem Sud Chemie Pvt Ltd (wadki)', '', '', 'Gat No.1211,1212 &1230 Part,', 'Off. Pune Saswad Road, Wadki ', 'Pune-412308', 22, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 9350.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(691, 'Harshanjali Instruments', '', '', '', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(692, 'Avdhut Enterprises ', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(693, 'Raj Deep Distributors Pvt. Ltd', '', '', 'Shukrawar Peth ', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(694, 'Noble Industries', '', '', 'Dattanagar Katraj,', 'Pune-411046', '', 147, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(695, 'Vital Agro Services', '', '', 'Shop No. 1/3, Sumeet Plaza,', 'Market Yard, Pune-411037', '', 149, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(696, 'S. M. Rolling, Involute, Emdet Engg.,', '', '', 'Chinchwad, Bhosari, Chakan,', 'Pune', '', 151, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(697, 'Balance & Care', '', '', 'Yamunanagar, Nigdi', 'Pune-411044', '', 154, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(698, 'Arjay Alloys, Paranjape Metals, K. B. Enter. ', '', '', 'Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(699, 'Arjay Alloys, Paranjape Metals.', '', '', 'Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(700, 'Poly Engineers', '', '', 'Sr. No. 124/1, Shirke Nagar,  ', 'Mundhwa,  Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(701, 'Manoj Steel Industries', '', '', 'Dattanagar, Katraj, ', 'Pune-411046', '', 147, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(702, 'Mascot Industries', '', '', 'Sr. No. 136/2 A, Shed No. 4, Dalwi Wadi,', 'Nanded Phata, Dhayari,', 'Pune-411041.', 1, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(703, 'Jai Hind Automotion Pvt. Ltd.', '', '', 'Plot No. A-7 Block, [ C-4-5-12-(18) ]', 'M. I. D. C. Bhosari, Pune-411026 ', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 685.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(704, 'Pragu Tools Pvt Ltd ', '', '', 'W-47, T- Block ', 'Midc Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(705, 'Om Sai Enterprises', '', '', 'Shed No 4 Narhe Ambegaon Road', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(706, 'Alpha Dies & Pattern (i) Pvt. Ltd', '', '', 'T- 143, Opp. Pefco Foundry, ', 'M. I. D. C. Bhosari, Punu-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(707, 'Accusharp, A. S. Engg., J. Bajaja Tools', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(708, 'Aarti Valley Micromatic Gajanan Sanjeev.', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(709, 'Colour N Finishes', '', '', 'Plot No 48 Flat No 1a Bibwewadi', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(710, 'Process Equipments', '', '', 'C-33 & 34, M. I.  D. C. Taswade, ', 'Karad, Satara.', '', 53, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(711, 'Shakti Industries', '', '', 'J-528 M I D C, Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(712, 'Galaxy Machines', '', '', 'Gat No. 1567, Shelar Vasti,', 'Chikhali, Pune-412114', '', 153, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(713, 'Ramesh & Co., Accusharp.', '', '', 'Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(714, 'Arjay Printers, A. S. Engg., Accusharp', '', '', 'Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(715, 'Doshi Sales Corporation', '', '', 'Sanaswadi, ', 'Pune.', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(716, 'Standerd Automobiles', '', '', '557,nana Peth Pune411002', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(717, 'Lexon Winders ', '', '', '251 Gorhe Bk. Donje Phata ', 'Sinhagad Road,', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(718, 'Superfine', '', '', 'Sr No-68/a Shewalewadi Phata ', 'Near Octroi Naka', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(719, 'R. P. Enterprises  ', '', '', 'Flat No 07 Building No B-19', 'Giridhar Nagar, Warje Malwadi ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(720, 'Poona Tractor Center  ', '', '', '27, Sumeet Plaza Oop Hotel Darpan ', 'Market Yard ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(721, 'Avitosh Enterprises ', '', '', 'Gala No-1 Paras Phase 111 Ind Estate ', 'Midc Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(722, 'Wadilal Narottamdas & Sons', '', '', '231,raviwar Peth', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(723, 'Self', '', '', '', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(724, 'Mahesh Mfg & Supplying Co.', '', '', '378,shukrwar Peth', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(725, 'Varunsak Plastic  Paints & Chemicale Pvt.ltd.', '', '', '157/2 & 303/2 Mauje Ambervet Tal. Mulshi', 'Pirngut', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(726, 'Sharang Corportion', '', '', '106,laxmi Plaza Kasarwadi', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(727, 'Elomatic (india) Pvt.ltd. ..Deleted', '', '', '296/a/1/5 St.patrick''s Town, ', 'Hadapser', 'Pune', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(728, 'Afcil  Industries Ltd  ..Deleted', '', '', 'Gat No.907/2/4. Sanswadi', 'Sanaswadi, Tal - Shirur  Pune .', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(729, 'Agsa Springs', '', '', 'X-14 M. I. D. C. Bhosari', 'Pune - 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(730, 'Paranjape Metal Shapers P.ltd ( Bhosari)', '', '', 'T-141 Midc Bhosari', '', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(731, 'Shri Gajanan Engg', '', '', 'S''block Plot No Sp109 Bhosari', 'Bhosari', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(732, 'Virgo Valve & Controls Ltd', '', '', '277, Hinjawadi Phase-2, ', 'Mann ( Mulshi), Pune.', '', 133, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(733, 'Arjay Printers, B. J. Perfect Works', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(734, 'Shridhar Rubber Product', '', '', '54/31, M I D C Chinchwad,', 'Pune', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(735, 'Quality Auto Components Pvt. Ltd', '', '', 'Sect. No.10, Plot No. 266, Pcndta,', 'Indus. Estate. Bhosari,', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(736, 'Reliabel Technical Services', '', '', 'B-8, Ratan Park ', 'Hadapsar', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(737, 'K. B. Enterpirses & Sanjeev Industries', '', '', '', 'Talawade & Bhosari, Pune-', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(738, 'Ramco Automatics', '', '', 'S No,7 Vijay Colony Ganeshnagar Akurdi', 'Akurdi', 'Pune', 135, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(739, 'Singh & Sons', '', '', 'Plot No.319 Sector No.10,p.c.n.t.d.a. ', 'Bhosari', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(740, 'Kriya Fasteners', '', '', 'Gat No.813 Pawar Wasti Kudalwadi ', 'Chikhali', 'Pune', 153, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(741, 'Laxmi Oil Mills', '', '', 'Sr.no.37 Kondhwa Bk   ', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(742, 'Pioneer Ispat Pvt.ltd.', '', '', 'W-210 Midc Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(743, 'Neha Engineering Solution', '', '', 'C/o Bright Engineers,', 'M I D C Bhosari, Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(744, 'Shah Nathaji Maniklal Jain', '', '', '1, Guruwar Peth, ', 'Pune- 411042', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(745, 'S. S Enterprises', '', '', 'W-211, M I D C Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(746, 'Sahyadri Automotive ', '', '', 'Near P. D. C. C. Bank', 'Market Yard, Pune', '', 149, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(747, 'Anil Sahebrao Washilkar', '', '', 'Punu', 'Ph. No.9623459246', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(748, 'Tech Sales & Services', '', '', 'K-9, Kothari Ware Housing,', 'Near Memko Weight Bridge, Ubale Nagar,', 'Waghali, Pune.', 83, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 6105.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(749, 'Shri Ram Foundery', '', '', 'Shiroli', '', 'Kolhpaur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(750, 'Delta Small Tools And Engineering', '', '', '31, Indus. Estate Gultekadi', 'Pune-411037', '', 90, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(751, 'The Vijay Engineering Works ', '', '', '1325/1a (9) Shivaji Udyamnagar', 'Kolhapur', '', 69, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(752, 'Ziebentek Engg. Pvt. Ltd.', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(753, 'Span Met Tech Enterprises  ', '', '', '109/111 Sub Plot No 6 Hadapsar ', 'Ramtekadi', 'Pune', 81, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(754, 'Vanaz Engg Pvt Ltd  ', '', '', '85/1 Paud ', '', 'Pune ', 162, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(755, 'Saifee Stores  ', '', '', 'Saifee House 910 Synagougue Street ', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(756, 'Sunsui  Process  Systems', '', '', 'Plot No-585 B-9 Kumar Ashiyana ', 'Sinhagad Road ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(757, 'Hi -tech International ', '', '', 'Plot No -29 Gat No-281/1', 'A/p Kasar Amboli  Pirangut ', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 2475.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(758, 'Darshana Industries Pvt. Ltd.', '', '', '63,hadapsar Industial Estate ', 'Hadapsar Pune', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(759, 'S.m.enterprises', '', '', '441 Shakar Nagar No,1 ', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(760, 'Caravan Engineers', '', '', '38, Gultekdi Indus. Estate,', 'Pune-411037', '', 90, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(761, 'Punch $ Pack Enterprises', '', '', 'S No 23/1/1 Dhayari', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(762, 'Reliable Industrial Products', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(763, 'Kshirsagar Metals', '', '', '67-a Vithalwadi Sinhagad Road', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(764, 'Virgo Engineers Ltd.( Bhosari)', '', '', 'J-525/160, Midc, Bhosari,', 'Pune- 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(765, 'Kishor Pressing', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(766, 'Imperial Enterprises', '', '', 'W-113, M I D C Bhosari ', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(767, 'Tecsprings', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(768, 'Disha Instruments', '', '', 'Pume', '3259308', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(769, 'Manas Engineering', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(770, 'Infinity Engineering Company', '', '', 'Pune', 'Ph. No. 27170556', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(771, 'Suyog Fabricators', '', '', 'Sr. No. 37/1/3, Narhe Industrial Estate,', 'Narhe Road, Pune- 411041', '', 89, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(772, 'Sai Industries', '', '', 'W-225, M I D C, Bhosari.', 'Pune- 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(773, 'A. V. P. Enterprises', '', '', 'T-181-1-1/ B, M I D C Bhosari', 'Pune- 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(774, 'Sanjeev Industries, Diamond, Shree Ram.', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(775, 'Imtiyaz Gavandi', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(776, 'Fabindia Overseas Private Limited', '', '', 'Aundh, Pune', '', '', 167, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(777, 'Anuvintech Pumps & Systems', '', '', 'Sr. No. 120, Santosh Nagar,', 'Katraj, Pune-411046', '', 35, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(778, 'Pandit Automotive Pvt. Ltd( Tilak Road) ', '', '', 'Ashok House, Tilak Road,', 'Pune-411002', '', 168, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(779, 'Thermolite Packaging (i) Pvt. Ltd', '', '', 'Plot No. 5, Gat No. 906, Sanaswadi,', 'Tal. Shirur, Dist:- Pune', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(780, 'Alpha Enggs ', '', '', '', 'Miraj ', 'Sangli ', 32, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(781, 'Avmount ( India) ', '', '', '14 & 15, Sr. No. 37 Kondhwa- Pisoli Road', 'Pune-411028', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(782, 'Shree Hans Enterprises', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(783, 'Kumbhojkar Plastic Moulders ', '', '', '129, Narayan Peth, ', 'Pune-411030', '', 169, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(784, 'Pragati Enterprises', '', '', 'Sr. No. 31/4/2, Ambegaon Br.,', 'Pune-411046', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(785, 'Excel Engineers & Contractors', '', '', 'J-296, M I D C, Bhosari,', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(786, 'Thermax Ltd ( Babcock & Wilcox)', '', '', 'D- 1, M I D C Chinchwad,', 'Pune', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(787, 'People Packagings', '', '', '105/106, Ramtekadi Industrial Estate,', 'Hadapsar, Pune', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(788, 'S. M. Enterprises', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(789, 'Aira Automations', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(790, 'Quali Surge Surgicals Pvt. Ltd.', '', '', '201, Ashoka Arch, 28/29, Market Yard,', 'Pune- 411037', '', 149, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(791, 'A K Agencies', '', '', 'T Block Telco Road', 'Bhosari, Pune- 411026', '', 1, '', '', '', '9763449614', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 2579.00, 44.00, 32.00, '', '0');
INSERT INTO `customers` VALUES(792, 'N. P. Enterprises', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(793, 'Deepak Enterprises', '', '', '364, Raviwar Peth,', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(794, 'Vector Enterprises', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(795, 'B. J. Perfeat Works', '', '', '', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(796, 'Victor Enterprises ', '', '', '', '', 'Kolhapur', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(797, 'Om Pattern & Engineers', '', '', 'Gat No. 766, Pawar Wasti, Kudalwadi ', 'Chikhali, Pune-412114', '', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(798, 'I T W India Limited', '', '', 'Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(799, 'Globe Trading Co. ', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(800, 'Om B- Tech Engineers', '', '', '10, Plot No. 94/4, P C N D T A, Bhosari,', 'Pune- 411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(801, 'Atharva Enterprises', '', '', 'Sector 7, Plot No. 236, P C N D T ', 'M I D C Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(802, 'Faster Hydrollics', '', '', 'Bhsari. Pune -411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(803, 'Ambik Harmonic Filters', '', '', 'Sr. No. 13, Near Krishnai Aqua ', 'Village Nanded, Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(804, 'Hi -tech Corporation', '', '', 'Opp. C.t.r. Company, Nagar Road, Kharadi', 'Pune- 411014', '', 6, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(805, 'Saket Enterprises', '', '', 'Shop No. 5, Mihir Aprtment, Bhairobanala', 'Hadapsar Road, Pune-411013', 'Tel. 26820373', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(806, 'Aashay Enterprises', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(807, 'Rajdeep Industrial Products  Pvt Ltd ', '', '', 'Survey No 143 Sinhagad Road , ', 'Rajdeep Hights Wadgaon Dhayari ', 'Pune ', 49, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(808, 'Everest Agencies', '', '', '244 Raviwar Peth', 'Pune', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(809, 'K.s . Multi - Parts ', '', '', 'C-19 Ff, Parvati Industrial Premises  ', 'Co-op Society  T-204 Midc Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(810, 'Avp Enterprises ', '', '', 'T-181-1b Midc ', 'Bhosari ', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(811, 'Span Pressing Works Pvt Ltd ', '', '', 'Block S Plot No. S- 182 ', 'Bhosari Industrial Area ', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(812, 'Parda Machine Tools', '', '', '550/ B Nana Peth Pune- 411002', '', '', 176, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(813, 'Govind Dattatray Joshi', '', '', 'Padmavati, Pune', '9822002612', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(814, 'G. M. Engineers', '', '', 'Gala No. 29, Parmar Indus. Complex,', 'Chinchwad, Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(815, 'Kirti Alloys', '', '', 'J-514, Telco Road, M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(816, 'Trg International', '', '', 'Office No 301 Dsk Classique', 'Karve Road', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(817, 'Sharad Engineering', '', '', 'Sr. No. 231/28, Kale Padel,', 'Hadapsar, Pune-411028', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(818, 'Akshay Energycon Services', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(819, 'Sansera Engineering Pvt. Ltd.', '', '', 'B-18 M I D C Chakan,', 'Pune-410501', '', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(820, 'Sachin Enterprises', '', '', 'Pune', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(821, 'Pro - Cast', '', '', 'A-5, Vasundhara Apartment, ', 'Bharati Viddhyapeeth, Katraj, ', 'Pune-411046', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(822, 'K.b., Valley, Shri Gajanan, Sanjeev', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(823, 'Fine Cut, Sanjeev', '', '', 'Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(824, 'The Indian Electric Co.', '', '', '201, Village Gorhe Kurad, ', 'Pune- Panshet Road, Tal. Haweli, ', 'Dist. Pune-411025', 179, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(825, 'Akshay Indus', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(826, 'Pavan Indus.', '', '', '', '', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(827, 'Shree Rubbur', '', '', '', 'Kolhapur', '', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(828, 'Eagle Seals & Systems India Ltd.', '', '', '212/2, Hadpasar, Pune-411028', '', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(829, 'B. M. Enterprises', '', '', '806. Bhawani Peth', 'Pune- 411042', 'Tel. 26455033', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(830, 'Mohan Enterprises', '', '', '16, Gulmohar Regal Homes Co-op Hsg. Soc.', 'Wanawadi, Pune- 411040', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(831, 'Rishap Industries Pvt. Ltd.', '', '', 'P No. 33, D-2 Block, M I D C Chinchwad', 'Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(832, 'Tuskar Tradind, Diamond ', '', '', 'Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(833, 'Super Traders, Arjay Printers', '', '', 'M I D C Bhosari, Pune-411026', '', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(834, 'Powercon Equipment', '', '', 'Gat. No. 189, Near Jyotiba Mangal Karyal', 'Jyotibanagar, Talwade,', 'Pune-412114', 78, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(835, 'Tuskar Tradind, Arjay Printers', '', '', 'M I D C Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(836, 'Mack Power Equipment', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(837, 'Aarti Indus., Shri Gajanan Engineering', '', '', 'M. I. D. C. Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(838, 'Priya Engineering', '', '', '19/2 Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(839, 'Audhut Enterprises', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(840, 'Shende Sales Corporation', '', '', '470, Sadashiv Peth, ', 'Pune-411030', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(841, 'Francois Compressors India Pvt. Ltd.', '', '', 'Sr. No. 01, Ambegaon Br.,', 'Tal. Haweli, Dist. Pune-411046', '', 180, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(842, 'Hamirani Metals Pvt. Ltd.', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(843, 'Appolo Forge & Machining', '', '', 'Gat No. 229, Chakan- Talegaon Road,', 'Kharabwadi, Chakan, Pune-410501', '', 41, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(844, 'Transducers 5 Devices', '', '', 'Bibvewadi', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(845, 'Sky Lub System', '', '', 'A2, Dhankawade Patil Township, ', 'Sr. No. 22, Dhanakawadi, Pune-411043', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(846, 'Flora Agro', '', '', 'Sr. No. 1069, A/p Wadgaon Mawal,', 'Tal. Mawal, Dist. Pune-412106', '', 181, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(847, 'Suyog Engineers ( Bhosari)', '', '', 'B-5, General Black, M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(848, 'Waghmare Shoe Co. ', '', '', 'F-ii, Block Sec. No.7, Plot No. 1&2,', 'M I D C Pimpri, Pune-411018', '', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(849, 'A R G Enterprises', '', '', 'B-1, Manimangal Society, Kasarwadi,', 'Pune-411034', '', 97, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(850, 'Ajp Enterprises ', '', '', '', '', 'Shiroli ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(851, 'Radhika Techno.', '', '', '', '', 'Ichalkaranji', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(852, 'Themes Furnishings & Lines', '', '', 'T-141, Mahatma Gandhi Road, ', 'Pune-411001', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(853, 'Samrat Industries', '', '', '114/1/7 General Block, M. I. D. C.', 'Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(854, 'Thoro Packaging Industries', '', '', '3, First Floor, Wing-2, Thakkar House,', '2418, East Street, Pune Camp-411001', '', 182, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(855, 'Faith Machine Tools', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(856, 'Palko Mold Mech', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(857, 'Konark Associates', '', '', 'Pune', ' ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(858, 'Suwaco Hydro Chem', '', '', 'Bibewadi', ' ', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(859, 'Innoech Auto (i) Pvt.ltd.', '', '', 'Plot No,5 Gat No87 Jyotiba Nagar Talawad', 'Pune', '', 78, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(860, 'Jishan Steel Traders', '', '', 'Jiya Manzil Talwade Road Triveninagar', 'Pune', '', 78, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(861, 'A.s.engineering.', '', '', 'Sai Industrial Estate,gala No.6 Landewad', 'Bhosari', 'Pune', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(862, 'Pragati Graphics', '', '', 'Pune', 'Mo. No. 9766694939', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(863, 'Opel India', '', '', 'Pune.', '9422319232', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(864, 'Randack Fastneners (i) P. Ltd ', '', '', '', 'Pirangut', 'Pune ', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(865, 'Cromton Greaves Ltd.( Goa)', '', '', 'S14 & S15, Colvale Industrial Estate,', 'Colvale Mapusa, Bardez, Goa-403513', '', 184, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(866, 'Sandish Marketing', '', '', '15a/2 Nanded Gaon ', 'Sinhagad Road', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(867, 'Sands Traaaadig Co', '', '', '', '126, Tathwade', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(868, 'Gunwant Enterprises', '', '', '', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(869, 'K. B. Enter, Aarati Indus., Shri Gajanan Engg.', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(870, 'A.s. Engg., M Las Sales Corp.', '', '', 'M. I. D. C. Bhosari ,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(871, 'Deluxe Sales Corporation ', '', '', '677, Landewadi, Behind Panjab National-', 'Bank, Bhosari, Pune-411039', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(872, 'Thermotech Engineering', '', '', 'F-2 Block, 22/1, M. I. D. C. Pimpri,', 'Pune-411018', '', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(873, 'Matrix Engineers ', '', '', 'Sect. No. 10 Plot No. 182, P C N D T A', 'Indus. Area Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(874, 'A.s Engg., Arjay Printers', '', '', 'M I D C Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(875, 'S. P. Techno., Cotmac Pvt. Ltd.', '', '', 'M I D C Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(876, 'Deccan Paints & Chemicals ', '', '', 'Sr. No. 52/2, Mundhwa Road, ', 'Vadgaon Sheri Pune-411014', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(877, 'M. K. Industries', '', '', '14/2, Anand Industrial Estate, ', 'Anand Nagar, Gulve Wasti, Bhosari,', 'Pune-411026', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(878, 'The Indian Smelting & Refining Co. Ltd.', '', '', 'Gat No. 201, Sanaswadi, Tal. Shirur,', 'Dist. Pune-412208', '', 15, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(879, 'Aarti Indus., Shri Gajanan, S. P. Techno.', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(880, 'Heat Weld', '', '', 'M I D C, Chinchwad,', 'Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(881, 'Puja Enterprises', '', '', '411/1, Mumbai Pune Road, ( Kasarwadi)', 'Opp. Alfa Laval, Dapodi, Pune-411012', '', 97, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(882, 'Smith, Diamond Abrassive ', '', '', 'M I D C Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(883, 'Aarati, S. P. Techno., Sanjeev. ', '', '', 'M I D C Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(884, 'Intervalve India Ltd. ', '', '', 'C/o Avkash Holdings Pvt. Ltd.', '212/2, Hadapsar,', 'Pune-411028', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(885, 'Mahalaxmi Enterprises', '', '', 'F-8, Surya Prakash Apartment, ', 'Market Yard, Pune- 411037', '', 149, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(886, 'Sarj Technologies', '', '', '', '', 'Karad', 64, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(887, 'Mahalaxmi Dyes & Chemicals Ltd.', '', '', 'D-6/1, M. I. D. C. Kurkumbh, ', 'Tal. Daund, Dist. Pune-413802', '', 185, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(888, 'Venus Traders', '', '', '31 Budhawar Peth, Nr Appa Balawant Chowk', 'Pune-411002', '', 187, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(889, 'Delval Flow Controls ( P) Ltd.', '', '', 'Gat No. 625/1/2, Kuruli, Tal Khed,', 'Pune- Nasik Hiway, Dist. Pune-410501', '', 129, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(890, 'Samkalin Prakashan', '', '', '474, Sadashiv Peth,', 'Pune-411030', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(891, 'Aarti Indus., Shri Gajanan, Faser Hydrolics.', '', '', 'M. I. D. C. Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(892, 'Reliable Chemicals', '', '', '543, Sadashiv Peth,', 'Pune-411030', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(893, 'D. V. Tools', '', '', 'Midc Palus', '', 'Sangli ', 20, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(895, 'Grauer & Weil (i) Ltd', '', '', 'Village Dhanore, Tal. Khed,', 'Dist. Pune', '', 118, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 520.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(896, 'Om Engineers', '', '', 'Prabhat Road', 'Pune- 411026', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(897, 'Venti - Pack Filters', '', '', 'Sr. No. 33, Karve Nagar, ', 'Pune-411052', '', 189, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(898, 'Sumasons Sai Enterprises', '', '', '', '', 'Kolhapur ', 12, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(899, 'Girish Enterprises', '', '', 'Sr. No. 624 / 2 B. Pokale,', 'Bibvewadi, Pune-411037', '', 190, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(900, 'Paranjape Metals, S.p. Tech., Aarati', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(901, 'Zenith Engineers ', '', '', 'Block D-iii, Plot No. 29, ', 'M. I. D. C. Chinchwad, Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(902, 'The Supreme Industries Limited', '', '', '7th, Godown, Sr. No. 69, Tathwade,', 'Tal. Mulshi, Dist. Pune-411033', '', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(903, 'Vikram Vilas Mane', '', '', 'Pune', '9822307498', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(904, 'Unique & P. R. Enter.', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(905, 'Cronimet India Metals Pvt. Ltd.', '', '', 'Bhadale Warehousing, Sr. No.158, Devachi', 'Urali, Uraligaon Road, Pune-412308', '', 194, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(906, 'Consultech Combines Pvt. Ltd.', '', '', 'Plot No. J-432 M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(907, 'Aarati, Ramesh & Co., B. J. Perfect', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(908, 'Dyeglo', '', '', '820/7,shri Krishna Kunj,bhandarkar  Road', 'Pune41004', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(909, 'Premier Seals ( India) Pvt. Ltd.', '', '', 'C/ O Shakti Indus. ', 'J-528, M. I. D. C. Bhosari, Pune.', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(910, 'Shri Gajanan , Aarati Indis.', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(911, 'V- Pla Products', '', '', 'Sr. No. 13/1, Shed No. 7, Ingale Colony,', 'Opp. Rohan Coplex, Shivane, Pune-411023', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(912, 'Ratna Gears Pvt.ltd.', '', '', '108,swamivivekanand Ind.estate', 'Off.handewadi Road Hadapser', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(913, 'Shepa Forge Pvt. Ltd.', '', '', 'Gat No. 138, Alandi- Markal Road,', 'Dhanore, Tal. Khed, Dist. Pune-412105', '', 118, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(914, 'A. S. Engg. & Smith International', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(915, 'Aakar, Smith Inter., Aarati Indus.', '', '', 'M. I. D. C. Bhosari, ', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(916, 'Perfect Enterprises', '', '', 'Pune', '', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(917, 'S.s.enterprises', '', '', 'S.no.20,gat No2 Vijaynagar Kate Vasti', 'Dighi Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(918, 'Bharat Plastic Mfg.co.', '', '', 'A-173 H-block Midc Pimpari', '', 'Pune', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(919, 'Injo Technical Services', '', '', 'C/o Test Inspection & Services P.ltd.', 'Chikhali', 'Pune ', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(920, 'Pavan Industries.', '', '', 'Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(921, 'Jay Kalimata Engineering', '', '', 'Ganesh Nagar,dhavade Vasti,bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(922, 'K. B. Enter, Aarati Indus.,b J Perfect Works', '', '', 'Talwade,bhosari,chinchwad', 'Pune-', '', 151, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(923, 'Smith International & Ramson Polypack P,ltd.', '', '', 'Bhosari', '', 'Pune ', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(924, 'Mak Enterprises', '', '', 'C/o.aryan Electical', 'Tathwade', 'Pune', 50, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(925, 'Multi Colour Packaging', '', '', '70/547 Maharashinagar Near Sant Namdev ', 'School Pune 37', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(926, 'Omega Indus. ', '', '', '', '', 'Ichalkaranji', 13, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(927, 'Satyajeet Machanisms', '', '', '', '', 'Kolhapur ', 23, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(928, 'Mak Glit Chem (i) Pvt Ltd', '', '', 'Gat No 126, 127 Plot No 1 Pirangut ', 'Dist- Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(929, 'Shrikrishna Engineering Works ', '', '', '12 Kothrud Industrial Estate ,', 'Pune ', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(930, 'System Engineering', '', '', 'Kondhwa', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(931, 'Bharati Printing Press', '', '', 'Erandwane, ', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(932, 'Shree Ramswitchgears', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(933, 'M. A. Borkar Engineers & Fabricators', '', '', 'Ganesh Nagar, Dhavade Wasti,', 'Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(934, 'Polymark Industries', '', '', 'S No 10 Sinhgad Road', '', 'Pune ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(935, 'Kishor Pumps Pvt. Ltd.', '', '', 'T-176, M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 680.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(936, 'Nitali Plastic Industries', '', '', 'Pimpri, ', 'Pune', '', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(937, 'Y. A. Traders', '', '', '446, Mumbai- Pune Road,', 'Kasarwadi, Pune-411034', '', 97, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(938, 'Star Mech Controls (i) Pvt. Ltd.', '', '', 'Sr. No.54, Plot No. 110, Handewadi Road,', 'Swami Vivekanand Co-op Indus. Estate, ', 'Hadapsar, Pune-411028', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(939, 'Kontec Medical Systems', '', '', 'Pune', 'Mo. No. 9373312667', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(940, 'Force Motors Ltd.', '', '', 'Akurdi', 'Pune', '', 135, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(941, 'S. P. Techno., Shri Gajanan., Hydro', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(942, 'Sanjeev Industries & Rohan Enter.', '', '', 'M. I. D. C. Bhosari.', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(943, 'Plastic Products', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(944, 'Mohini Enterprises Pvt. Ltd.', '', '', 'Vishwachaya Indus. Estate, Sr. No. 322,', 'Plot No. 02, Pirangut, Pune-412108.', '', 27, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(945, 'Sahayog Nirmitee', '', '', 'A-32, Pavana Indus. Premises,', 'T-204, M. I. D. C. Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(946, 'Tool Max ', '', '', 'Mauli, 738, Budhwar Peth,', 'Ganesh Road, Phadke Haud, Pune-411002', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(947, 'Kirloskar Pneumatic Co. Ltd.', '', '', 'C/o Ars Engineering Pvt. Ltd.', 'Hadapsar, Pune.', '', 120, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(948, 'Ssp Pattern Works', '', '', 'S.no.120/ B, Shop No.22, Datir Patil Est', 'Mohannagar, Chinchwad, Pune-411019', '', 8, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(949, 'Vijay Agency', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(950, 'S. P. Techno., K. B. Enter., Gajanan, Ramesh. ', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(951, 'Rohan Enter., M Las, A. S. Engg.', '', '', 'M. I. D. C.  Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(952, 'A-1 Furniture', '', '', 'Ashoka, Market Yard,', 'Gultekdi, Pune-411037', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(953, 'Standard Gasket & Allied Indus.', '', '', 'Pune', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(954, 'Darlesha Metal Corporation', '', '', 'Market Yard, Pune-411037', '', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(955, 'R G P Enterprises', '', '', 'Vandan 40/2, Erandvane, Near Paud Phata,', 'Kothrud, Pune-411038', '', 54, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(956, 'Unique Corporate', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(957, 'Aakareng., Valley, S. P. Techn., Gajanan Engg ', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(958, 'Valley Gauges & Kishor Pressing', '', '', 'M. I. D. C. Bhosari,', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(959, 'Shree Packaging', '', '', 'Sadashiv Peth', 'Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(960, 'Raviraj Enterprises', '', '', 'J-75 "s"block Midc Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(961, 'S.a. Enterprises', '', '', 'J-514,j-block Midc Bhosari', 'Pune', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(962, 'Swastik Stamping Pvt. Ltd.', '', '', 'Gat No. 343, Chakan Talegaon Road,', 'Mahaliunge Village, Pune-410501', '', 201, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(963, 'Girisons Distributors & Fabrics', '', '', '64 Poona Bombay Road ', 'Near Shivaji Nagar', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(964, 'Kirloskar Pneumatic Co Ltd', '', '', 'Saswad', ' Pune', '', 202, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(965, 'Technova', '', '', 'Shed No 2 $ 3 Nanded Gaon', ' Pune', ' ', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(966, 'Mutta Steelage Pvt. Ltd.', '', '', 'Ridhi Apart. No.7,10th Khetwadi Back Rd.', 'Mumbai-400004', '', 24, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(967, 'Con Air Tools', '', '', 'Sr. 10/9 Karanjkar Industrial Estate,', 'Nandedgaon, Sinnhgad Road, Pune.', '', 203, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(968, 'Pallavi Industries', '', '', 'X-2, General Block, Opp. Philips India,', 'M. I. D. C. Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(969, 'Sovereign Rubber Auto Parts Pvt. Ltd.', '', '', 'Sec. No. 7 Plot No.127, P C N D T A ', 'Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(970, 'Kaniri Enterprises', '', '', '', 'Shiroli ', 'Kolhapur ', 21, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(971, 'Universal Engi ', '', '', '', '', 'Pune', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(972, 'Superfine Flux', '', '', '', 'Near Octroi Naka', 'Pune', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(973, 'Prakash Patil', '', '', 'Pune', 'Mo. No. 9881231424', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(974, 'Pogasha Agencies', '', '', '260.raviwar Peth', ' Pune', '', 1, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(975, 'Forbess Marshall Pvt. Ltd.', '', '', 'M. I. D. C. Pimpri, Pune-411018', '', '', 38, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(976, 'Ramesh, Aarati, Gajanan, Accusharp, B. J.', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(977, 'Rohan, A. S., Shree Ram', '', '', 'M. I. D. C. Bhosari', 'Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(978, 'Shirodkar Preci Comp Pvt. Ltd.', '', '', 'Plot No. 71/1 A/11, B G Block,', 'M I D C Bhosari, Pune-411026', '', 18, '', '', '', '', '', ' ', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(979, 'Mather & Platt Pumps Ltd (chinchwad)nm', '', '', '', '', '', 205, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(980, 'Rajendra', 'Rajendra', 'f81c2414e3f4685567201371a38aee4a', '', '', '', 1, 'admin 05-08-09', '', '', '', '', '', '2009-08-05', 'R', '5765765', 'raj@gmail.com', '', '', '', '', '', '', '', 0.00, 3, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(981, 'U', 'I', '865c0c0b4ab0e063e5caa3387c1a8741', '', '', '', 2, 'admin 05-08-09', '', '', '', 'i', '', '2009-08-05', 'I', '9', '', '', '', '', '', '', '', 'I', 9.00, 9, 0, 9.00, 9.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(984, 'Ww', '', '', '', '', '', 207, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(985, 'Raj', 'Raj', '65a1223dae83b8092c4edba0823a793c', '', '', '', 0, '', '', '', '', '', '', '2009-09-15', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(986, 'Acme Foundry Flux Co.h', '', '', '264, Hadapsar Ind. Estest, ', 'Hadapsar,', 'Pune-411013', 120, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');
INSERT INTO `customers` VALUES(1000, '', '', '', '', '', '', 120, '', '', '', '', '', '', '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0.00, 0, 0, 0.00, 0.00, 0.00, 0.00, '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `descriptions`
--

CREATE TABLE `descriptions` (
  `DescId` int(11) NOT NULL AUTO_INCREMENT,
  `Desc` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`DescId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `descriptions`
--

INSERT INTO `descriptions` VALUES(1, 'Bags', 'abc', 'abc', '0');
INSERT INTO `descriptions` VALUES(2, 'Bandle', 'abc', 'abc', '0');
INSERT INTO `descriptions` VALUES(3, 'Bar', 'abc', 'abc', '0');
INSERT INTO `descriptions` VALUES(4, 'Barrel', 'abc', 'abc', '0');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `DriverId` int(10) NOT NULL AUTO_INCREMENT,
  `DriverName` text COLLATE latin1_general_ci NOT NULL,
  `CityId` int(10) NOT NULL,
  `Permanent_Address` longtext COLLATE latin1_general_ci NOT NULL,
  `Temporary_Address` longtext COLLATE latin1_general_ci NOT NULL,
  `DriverPhone` text COLLATE latin1_general_ci NOT NULL,
  `JoinDate` date NOT NULL,
  `DOBirth` date NOT NULL,
  `BloodGroup` text COLLATE latin1_general_ci NOT NULL,
  `WagesPerMonth` decimal(10,2) NOT NULL,
  `AllowancePerDay` decimal(10,2) NOT NULL,
  `RelivedDate` date NOT NULL,
  `Delete` char(5) COLLATE latin1_general_ci NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `LicenceNumber` text COLLATE latin1_general_ci NOT NULL,
  `LicenceValidUpto` date NOT NULL,
  `DateOfIssue` date NOT NULL,
  `LicenceDescription` text COLLATE latin1_general_ci NOT NULL,
  `Status` enum('0','1') COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`DriverId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` VALUES(1, 'sanjay', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', 'MO999', '0000-00-00', '0000-00-00', '', '');
INSERT INTO `drivers` VALUES(2, '', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', '', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(3, 'sundip', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', '', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(4, 'bunty', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', 'MV678', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(5, 'vikram', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', 'nm 7878', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(6, 'me', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', '89', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(7, 'i', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', '98', '0000-00-00', '0000-00-00', '', '0');
INSERT INTO `drivers` VALUES(8, 'raj', 0, '', '', '', '0000-00-00', '0000-00-00', '', 0.00, 0.00, '0000-00-00', '', '', '890', '0000-00-00', '0000-00-00', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

CREATE TABLE `feedbacks` (
  `fm_id` int(11) DEFAULT NULL,
  `fm_email` varchar(50) DEFAULT NULL,
  `fm_subject` varchar(50) DEFAULT NULL,
  `fm_text` varchar(200) DEFAULT '',
  `fm_member` varchar(50) DEFAULT NULL,
  `fm_name` varchar(50) DEFAULT NULL,
  `fm_publish` char(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedbacks`
--

INSERT INTO `feedbacks` VALUES(1, 'desai.ninad@gmail.com', 'Product', 'Really an amazing product with proven results...', '23', 'Ninad Desai', 'y');
INSERT INTO `feedbacks` VALUES(2, 'ninad@yahoo.com', 'Plan', 'Really a very powerful binary plan with option of generation income', '12', 'Shreyas Ghare.', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `itemdescriptions`
--

CREATE TABLE `itemdescriptions` (
  `ItemDescriptionId` int(11) NOT NULL AUTO_INCREMENT,
  `ItemDescriptionName` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`ItemDescriptionId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `itemdescriptions`
--

INSERT INTO `itemdescriptions` VALUES(1, 'Bag ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(2, 'Box', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(3, 'Can ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(4, 'Nos', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(5, 'Tray ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(6, 'Wooden Case', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(7, 'Drum', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(8, 'Bar ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(9, 'Carboy', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(10, 'Bundle ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(11, 'Wooden Box ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(12, 'Pattern', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(13, 'Tin ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(14, 'Wooden Frame ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(15, 'Wooden Pallet ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(16, 'Brl ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(17, 'Package ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(18, 'Set ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(19, 'Bkt', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(20, 'Sheet', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(21, 'Bandle', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(22, 'Pallet', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(23, 'Battery', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(24, 'Cylender', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(25, 'Empty Tank', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(26, 'Set Pattern', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(27, 'Loose', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(28, 'Frame', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(29, 'Plate ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(30, 'Housing ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(31, 'Pipe ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(32, 'Drill', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(33, 'Big Wooden Box', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(34, 'Door', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(35, 'Window', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(36, 'Both', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(37, 'Wooden Pattern', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(38, 'Big Corboy', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(39, 'Big Box', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(40, 'Corboy', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(41, 'Barrel', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(42, 'Boxes', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(43, 'Bags', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(44, 'Cans', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(45, 'Bucket', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(46, 'Tins', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(47, 'C/box', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(48, 'Boxs ..Del', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(49, 'Bras Formar', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(50, 'Durms', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(51, 'Nog ..Del', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(52, 'Tank I B C', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(53, 'W/ Box ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(54, 'Big Bandal', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(55, 'Pcb', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(56, 'Pkt ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(57, 'Drums', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(58, 'Barrels', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(59, 'Buckets', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(60, 'Bandles', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(61, 'Packet', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(62, 'Carboys', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(63, 'Big Bandles', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(64, 'W/ Boxes', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(65, 'Cnas', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(66, 'Bax', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(67, 'Nops', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(68, 'Mn', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(69, 'M. S. Box', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(70, 'Drams', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(71, 'Ibc', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(72, 'Ibc Plastic Dram', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(73, 'Boxes (trays)', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(74, 'Casting ', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(75, 'Wooden Pattern Set', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(76, 'Bottel', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(77, 'Os', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(78, 'Mnu', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(79, '7', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(80, '8', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(81, '6', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(82, '3', '', '', '0');
INSERT INTO `itemdescriptions` VALUES(83, '77', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `lrdetails`
--

CREATE TABLE `lrdetails` (
  `SrNo` int(2) NOT NULL,
  `ConsigmentNo` int(10) NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Description` text COLLATE latin1_general_ci NOT NULL,
  `DetailDesc` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `LoadType` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `MinWeight` decimal(10,2) NOT NULL,
  `Weight` decimal(10,2) NOT NULL,
  `Rate` decimal(10,2) NOT NULL,
  `RatePer` text COLLATE latin1_general_ci NOT NULL,
  `DetailsFreight` decimal(10,2) NOT NULL,
  `DetailsHamali` decimal(10,2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `lrdetails`
--

INSERT INTO `lrdetails` VALUES(1, 1, 7, 'Frame', 'T', '', 7.00, 7.00, 7.00, 'Kg', 49.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 2, 80, 'Mnu', '8', '', 80.00, 80.00, 8.00, 'Kg', 640.00, 80.00);
INSERT INTO `lrdetails` VALUES(1, 3, 8, 'Bag ', 'Hj', '', 8.00, 8.00, 8.00, 'Kg', 64.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 4, 8, 'Bag ', 'Ok', '', 7.00, 6.00, 6.00, 'Kg', 42.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 5, 7, 'Bag ', '7', '', 7.00, 7.00, 7.00, 'Kg', 49.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 7, 8, 'Box', 'Ok', '', 8.00, 8.00, 8.00, 'Kg', 64.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 9, 7, 'Drum', 'r', '', 7.00, 7.00, 7.00, 'Kg', 49.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 10, 7, 'Bag ', 'j', '', 7.00, 7.00, 7.00, 'Kg', 49.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 11, 8, 'Bag ', 'l', '', 8.00, 8.00, 8.00, 'Kg', 64.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 31, 0, 'Bag ', 'K', '', 9.00, 9.00, 9.00, 'Kg', 81.00, 9.00);
INSERT INTO `lrdetails` VALUES(1, 32, 6, 'Bag ', '6', '', 6.00, 6.00, 6.00, 'Kg', 36.00, 6.00);
INSERT INTO `lrdetails` VALUES(1, 54, 7, 'Bag ', '', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 56, 0, 'Wooden Box ', '7', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 57, 7, 'Bag ', 'Ui', '', 7.00, 7.00, 0.00, 'Fixed', 0.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 51, 20, 'Drum', '5', '', 2.00, 2.00, 2.00, 'Fixed', 2.00, 2.00);
INSERT INTO `lrdetails` VALUES(1, 58, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(11, 55, 80, 'Cans', '9', '', 8.00, 7.00, 7.00, 'Kg', 56.00, 6.00);
INSERT INTO `lrdetails` VALUES(10, 55, 20, 'Cylender', '5', '', 2.00, 2.00, 2.00, 'Kg', 4.00, 2.00);
INSERT INTO `lrdetails` VALUES(9, 55, 30, 'Carboy', '2', '', 3.00, 2.00, 2.00, 'Kg', 6.00, 2.00);
INSERT INTO `lrdetails` VALUES(8, 55, 70, 'Battery', '6', '', 8.00, 8.00, 8.00, 'Kg', 64.00, 6.00);
INSERT INTO `lrdetails` VALUES(7, 55, 30, 'Bundle ', 'tt', '', 2.00, 2.00, 2.00, 'Kg', 4.00, 2.00);
INSERT INTO `lrdetails` VALUES(6, 55, 60, 'Drums', '5', '', 5.00, 3.00, 3.00, 'Kg', 15.00, 3.00);
INSERT INTO `lrdetails` VALUES(5, 55, 20, 'Drill', '3', '', 2.00, 2.00, 3.00, 'Kg', 6.00, 3.00);
INSERT INTO `lrdetails` VALUES(4, 55, 40, 'Bar ', '6', '', 3.00, 3.00, 3.00, 'Kg', 9.00, 3.00);
INSERT INTO `lrdetails` VALUES(3, 55, 40, 'Door', '3', '', 3.00, 4.00, 2.00, 'Kg', 8.00, 3.00);
INSERT INTO `lrdetails` VALUES(2, 55, 20, 'Bag ', 'w', '', 3.00, 3.00, 3.00, 'Fixed', 3.00, 3.00);
INSERT INTO `lrdetails` VALUES(1, 55, 6, 'Drum', '6', '', 6.00, 6.00, 6.00, 'Fixed', 6.00, 6.00);
INSERT INTO `lrdetails` VALUES(1, 59, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 60, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 61, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 62, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 63, 4, 'Box', '2', '', 4.00, 4.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 64, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 65, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(3, 40, 80, 'Bkt', 'no', '', 8.00, 8.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(2, 40, 80, 'Box', 'hi', '', 8.00, 8.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 40, 8, 'Bag ', 'ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 66, 8, 'Bag ', 'L', '', 8.00, 6.00, 6.00, 'Fixed', 6.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 67, 8, 'Bag ', 'L', '', 8.00, 6.00, 6.00, 'Fixed', 6.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 68, 7, 'Bag ', 'Ok', '', 8.00, 9.00, 6.00, 'Fixed', 6.00, 6.00);
INSERT INTO `lrdetails` VALUES(1, 69, 8, 'Bag ', 'Ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 70, 7, 'Bag ', 'Bags Of 8 Brinjals', '', 10.00, 15.00, 7.00, 'Fixed', 7.00, 5.00);
INSERT INTO `lrdetails` VALUES(1, 71, 6, 'Bag ', 'Y', '', 7.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 72, 7, 'Bag ', 'U', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 73, 7, 'Housing ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 74, 8, 'Bundle ', 'Bloack Of7 Box', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 75, 7, 'Bottel', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 75, 0, '7', '', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 76, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 76, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(3, 76, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(4, 76, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(5, 76, 7, '7', '77', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(6, 76, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(7, 76, 0, '7', '7', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 77, 7, 'Bag ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 77, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(3, 77, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(4, 77, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(5, 77, 7, '7', '77', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(6, 77, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(7, 77, 0, '7', '7', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 78, 8, 'Bag ', 'Ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 79, 8, 'Bag ', 'Ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 80, 8, 'Bandle', 'OK', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 81, 8, 'Brl ', 'Io', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(2, 81, 0, '8', '', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 82, 8, 'Brl ', 'Io', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(2, 82, 0, '8', '', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 83, 7, 'Bandle', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 84, 7, 'Bandle', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 85, 7, 'Bandle', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 86, 6, 'Bag ', 'Ol', '', 6.00, 6.00, 6.00, 'Fixed', 6.00, 6.00);
INSERT INTO `lrdetails` VALUES(2, 86, 6, '6', '6', '', 6.00, 6.00, 6.00, 'Fixed', 6.00, 6.00);
INSERT INTO `lrdetails` VALUES(1, 87, 8, 'Brl ', 'Io', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(2, 87, 0, '8', '', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 88, 8, 'Bandle', 'OK', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 89, 7, 'Drum', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 89, 0, '7', 'Ik', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 90, 8, 'Drum', 'Ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(2, 90, 8, 'Set ', 'Ok', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 91, 8, 'Brl ', 'Io', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(2, 91, 0, '8', '', '', 0.00, 0.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 95, 8, 'Bag ', '8', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 96, 7, 'Bag ', 'Iu', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 97, 7, 'Bag ', 'Jhk', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 97, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 98, 7, 'Bag ', 'Jhk', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 98, 7, '7', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 99, 7, 'Bag ', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 100, 7, 'Bag ', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 101, 7, 'Box', '7', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 102, 9, 'Bag ', '9', '', 9.00, 9.00, 9.00, 'Fixed', 9.00, 9.00);
INSERT INTO `lrdetails` VALUES(1, 103, 3, 'Bag ', '3', '', 3.00, 3.00, 3.00, 'Fixed', 3.00, 3.00);
INSERT INTO `lrdetails` VALUES(2, 103, 3, '3', '3', '', 3.00, 3.00, 3.00, 'Fixed', 3.00, 3.00);
INSERT INTO `lrdetails` VALUES(1, 104, 6, 'Bag ', '67', '', 6.00, 6.00, 6.00, 'Fixed', 6.00, 6.00);
INSERT INTO `lrdetails` VALUES(1, 105, 7, 'Bag ', 'B', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 106, 7, 'Bag ', 'Y', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(1, 107, 8, 'Box', '89', '', 8.00, 8.00, 8.00, 'Fixed', 8.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 108, 7, 'Bag ', 'Casting', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 7.00);
INSERT INTO `lrdetails` VALUES(2, 108, 7, '77', '7', '', 7.00, 7.00, 0.00, 'Fixed', 0.00, 0.00);
INSERT INTO `lrdetails` VALUES(1, 109, 7, 'Bundle ', 'Ok', '', 7.00, 7.00, 7.00, 'Fixed', 7.00, 77.00);
INSERT INTO `lrdetails` VALUES(1, 110, 8, 'Bag ', 'K', '', 8.00, 8.00, 8.00, 'Kg', 64.00, 8.00);
INSERT INTO `lrdetails` VALUES(1, 111, 1, 'Bag ', 'Ok', '', 10.00, 9.00, 8.00, 'Fixed', 8.00, 8.00);

-- --------------------------------------------------------

--
-- Table structure for table `lrprints`
--

CREATE TABLE `lrprints` (
  `ConsignmentNo` int(10) NOT NULL AUTO_INCREMENT,
  `LrNo` int(10) NOT NULL,
  `Date` date DEFAULT NULL,
  `DONo` int(10) DEFAULT NULL,
  `OCNo` int(5) DEFAULT NULL,
  `BookingOfficeId` int(5) NOT NULL,
  `BillingStationId` int(5) NOT NULL,
  `consignerId` int(5) NOT NULL,
  `consigneeId` int(5) NOT NULL,
  `fromcity` int(5) NOT NULL,
  `tocity` int(5) NOT NULL,
  `DeliveryCityId` int(10) NOT NULL,
  `CustomerId` int(5) NOT NULL,
  `DeliveryAtId` int(5) NOT NULL,
  `RoadPermitNo` text COLLATE latin1_general_ci NOT NULL,
  `Remarks` longtext COLLATE latin1_general_ci NOT NULL,
  `PaymentType` text COLLATE latin1_general_ci NOT NULL,
  `AdvanceAmt` decimal(10,2) NOT NULL,
  `VehicleNo` text COLLATE latin1_general_ci NOT NULL,
  `FreightAmt` decimal(10,2) DEFAULT NULL,
  `Hamali` decimal(10,2) NOT NULL,
  `DDAmt` decimal(10,2) NOT NULL,
  `STAmt` decimal(10,2) NOT NULL,
  `LengthAmt` decimal(10,2) NOT NULL,
  `OctroiAmt` decimal(10,2) NOT NULL,
  `OtherAmt` decimal(10,2) NOT NULL,
  `InvoiceNo` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `InvoiceAmount` decimal(10,2) NOT NULL,
  `OctroiReceiptNo` text COLLATE latin1_general_ci NOT NULL,
  `TripExpence` int(10) NOT NULL,
  `DeliveryType` text COLLATE latin1_general_ci NOT NULL,
  `STPaidBy` text COLLATE latin1_general_ci NOT NULL,
  `TaxId` int(5) NOT NULL,
  `TaxAmount1` decimal(10,2) NOT NULL,
  `TaxAmount2` decimal(10,2) NOT NULL,
  `TaxAmount3` decimal(10,2) NOT NULL,
  `Rounding` decimal(10,2) NOT NULL,
  `MinChargesDiff` decimal(10,2) NOT NULL,
  `LrNetTotal` decimal(10,2) NOT NULL,
  `NetTotal` decimal(10,2) NOT NULL,
  `MemoNo` int(10) NOT NULL,
  `MemoDate` date NOT NULL,
  `TransporterName` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `LocalTransportCh` int(5) NOT NULL,
  `AcknowId` int(5) NOT NULL,
  `BillNo` int(5) NOT NULL,
  `OctroiBillNo` int(5) NOT NULL,
  `DeliveryId` int(5) NOT NULL,
  `DetentionDay` decimal(10,2) NOT NULL,
  `DetentionAmount` decimal(10,2) NOT NULL,
  `ProjectId` int(5) NOT NULL,
  `VehicleTypeId` int(5) NOT NULL,
  `CollectionId` int(5) NOT NULL,
  `CollectionDate` datetime DEFAULT NULL,
  `MemoRequire` varchar(2) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ConsignmentNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `lrprints`
--

INSERT INTO `lrprints` VALUES(111, 111, '2009-10-28', NULL, NULL, 1, 1, 6, 2, 120, 6, 21, 0, 35, '', '8', 'Paid', 0.00, 'MH 12CH 9499', 8.00, 8.00, 9.00, 8.00, 5.00, 8.00, 9.00, '9898', 89.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 47.00, 111.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `lrs`
--

CREATE TABLE `lrs` (
  `ConsignmentNo` int(10) NOT NULL AUTO_INCREMENT,
  `LrNo` int(10) NOT NULL,
  `Date` date DEFAULT NULL,
  `DONo` int(10) DEFAULT NULL,
  `OCNo` int(5) DEFAULT NULL,
  `BookingOfficeId` int(5) NOT NULL,
  `BillingStationId` int(5) NOT NULL,
  `consignerId` int(5) NOT NULL,
  `consigneeId` int(5) NOT NULL,
  `fromcity` int(5) NOT NULL,
  `tocity` int(5) NOT NULL,
  `DeliveryCityId` int(10) NOT NULL,
  `CustomerId` int(5) NOT NULL,
  `DeliveryAtId` int(5) NOT NULL,
  `RoadPermitNo` text COLLATE latin1_general_ci NOT NULL,
  `Remarks` longtext COLLATE latin1_general_ci NOT NULL,
  `PaymentType` text COLLATE latin1_general_ci NOT NULL,
  `AdvanceAmt` decimal(10,2) NOT NULL,
  `VehicleNo` text COLLATE latin1_general_ci NOT NULL,
  `FreightAmt` decimal(10,2) DEFAULT NULL,
  `Hamali` decimal(10,2) NOT NULL,
  `DDAmt` decimal(10,2) NOT NULL,
  `STAmt` decimal(10,2) NOT NULL,
  `LengthAmt` decimal(10,2) NOT NULL,
  `OctroiAmt` decimal(10,2) NOT NULL,
  `OtherAmt` decimal(10,2) NOT NULL,
  `InvoiceNo` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `InvoiceAmount` decimal(10,2) NOT NULL,
  `OctroiReceiptNo` text COLLATE latin1_general_ci NOT NULL,
  `TripExpence` int(10) NOT NULL,
  `DeliveryType` text COLLATE latin1_general_ci NOT NULL,
  `STPaidBy` text COLLATE latin1_general_ci NOT NULL,
  `TaxId` int(5) NOT NULL,
  `TaxAmount1` decimal(10,2) NOT NULL,
  `TaxAmount2` decimal(10,2) NOT NULL,
  `TaxAmount3` decimal(10,2) NOT NULL,
  `Rounding` decimal(10,2) NOT NULL,
  `MinChargesDiff` decimal(10,2) NOT NULL,
  `LrNetTotal` decimal(10,2) NOT NULL,
  `NetTotal` decimal(10,2) NOT NULL,
  `MemoNo` int(10) NOT NULL,
  `MemoDate` date NOT NULL,
  `TransporterName` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `LocalTransportCh` int(5) NOT NULL,
  `AcknowId` int(5) NOT NULL,
  `BillNo` int(5) NOT NULL,
  `OctroiBillNo` int(5) NOT NULL,
  `DeliveryId` int(5) NOT NULL,
  `DetentionDay` decimal(10,2) NOT NULL,
  `DetentionAmount` decimal(10,2) NOT NULL,
  `ProjectId` int(5) NOT NULL,
  `VehicleTypeId` int(5) NOT NULL,
  `CollectionId` int(5) NOT NULL,
  `CollectionDate` datetime DEFAULT NULL,
  `MemoRequire` varchar(2) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ConsignmentNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=112 ;

--
-- Dumping data for table `lrs`
--

INSERT INTO `lrs` VALUES(1, 1, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 45, '2009-07-18', '', 0, 45, 30, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(2, 2, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 52, '2009-08-17', '', 0, 61, 24, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(3, 3, '2009-08-05', NULL, NULL, 2, 1, 791, 6, 1, 120, 24, 0, 9, '', 'This Is First Entry', 'To Pay', 0.00, '', 64.00, 8.00, 8.00, 8.00, 8.00, 7.00, 8.00, 'u8', 7.00, '7.00', 0, 'Door', 'Transportor', 1, 8.35, 8.35, 8.35, -0.05, 7.00, 104.00, 192.00, 50, '2009-08-12', '', 0, 0, 27, 0, 0, 7.00, 9.00, 0, 0, 1, '2009-07-14 00:00:00', '');
INSERT INTO `lrs` VALUES(4, 4, '2009-08-10', NULL, NULL, 1, 2, 791, 7, 1, 1, 6, 0, 2, '', 'Ok', 'TBB', 0.00, 'MH 12 CH 9498', 42.00, 0.00, 9.00, 6.00, 5.00, 8.00, 8.00, '67', 89.00, '9.00', 0, 'Office', 'Consignee', 1, 29.90, 29.90, 29.90, 0.30, 0.00, 70.00, 688.00, 53, '2009-08-17', '', 0, 34, 25, 0, 0, 6.00, 88.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(5, 5, '2009-08-10', NULL, NULL, 2, 1, 6, 6, 120, 120, 13, 0, 9, '', '', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 0.00, 0.00, 0.00, 0.00, 0.00, '45', 0.00, '0.00', 0, 'Door', '', 1, 2.80, 2.80, 2.80, -0.40, 0.00, 56.00, 64.00, 53, '2009-08-17', '', 0, 62, 26, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(6, 6, '0000-00-00', NULL, NULL, 2, 1, 982, 982, 206, 206, 206, 0, 982, '', '', 'TBB', 0.00, '', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 51, '2009-08-17', '', 0, 63, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(7, 7, '2009-08-12', NULL, NULL, 2, 1, 17, 81, 1, 8, 160, 0, 19, '', 'Ok', 'To Pay', 0.00, 'MH 12CH 9499', 64.00, 8.00, 0.00, 0.00, 0.00, 7.00, 0.00, '78', 87.00, '0.00', 0, 'Office', 'Consignor', 1, 26.70, 26.70, 26.70, -0.10, 0.00, 72.00, 614.00, 53, '2009-08-17', '', 0, 0, 0, 0, 0, 7.00, 66.00, 0, 0, 4, '2009-08-17 00:00:00', '');
INSERT INTO `lrs` VALUES(8, 8, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 45, '2009-07-18', '', 0, 45, 0, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(9, 9, '2009-08-01', NULL, NULL, 2, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'To Pay', 0.00, '', 689.00, 87.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 38.80, 38.80, 38.80, -0.40, 0.00, 776.00, 892.00, 53, '2009-08-17', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 4, '2009-08-17 00:00:00', '');
INSERT INTO `lrs` VALUES(10, 10, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 689.00, 87.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 38.80, 38.80, 38.80, -0.40, 0.00, 776.00, 892.00, 53, '2009-08-17', '', 0, 64, 28, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(11, 11, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 704.00, 88.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 39.60, 39.60, 39.60, 0.20, 0.00, 792.00, 911.00, 53, '2009-08-17', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(12, 12, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 58, '2009-08-28', '', 0, 0, 41, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(13, 13, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 59, '2009-08-28', '', 0, 0, 42, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(14, 14, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 55, '2009-08-17', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(15, 15, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 54, '2009-08-17', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(16, 16, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 60, '2009-08-28', '', 0, 45, 0, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(17, 17, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 61, '2009-08-28', '', 0, 0, 24, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(18, 18, '2009-08-05', NULL, NULL, 2, 1, 791, 6, 1, 120, 24, 0, 9, '', 'This Is First Entry', 'TBB', 0.00, '', 64.00, 8.00, 8.00, 8.00, 8.00, 7.00, 8.00, 'u8', 7.00, '7.00', 0, 'Door', 'Transportor', 1, 8.35, 8.35, 8.35, -0.05, 7.00, 104.00, 192.00, 62, '2009-08-28', '', 0, 0, 27, 0, 0, 7.00, 9.00, 0, 0, 1, '2009-07-14 00:00:00', '');
INSERT INTO `lrs` VALUES(19, 19, '2009-08-10', NULL, NULL, 1, 2, 791, 7, 1, 1, 6, 0, 2, '', 'Ok', 'TBB', 0.00, 'MH 12 CH 9498', 42.00, 0.00, 9.00, 6.00, 5.00, 8.00, 8.00, '67', 89.00, '9.00', 0, 'Office', 'Consignee', 1, 29.90, 29.90, 29.90, 0.30, 0.00, 70.00, 688.00, 63, '2009-08-28', '', 0, 0, 25, 0, 0, 6.00, 88.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(20, 20, '2009-08-10', NULL, NULL, 2, 1, 6, 6, 120, 120, 13, 0, 9, '', '', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 0.00, 0.00, 0.00, 0.00, 0.00, '45', 0.00, '0.00', 0, 'Door', '', 1, 2.80, 2.80, 2.80, -0.40, 0.00, 56.00, 64.00, 64, '2009-08-28', '', 0, 0, 26, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(21, 21, '0000-00-00', NULL, NULL, 2, 1, 982, 982, 206, 206, 206, 0, 982, '', '', 'TBB', 0.00, '', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(22, 22, '2009-08-12', NULL, NULL, 2, 1, 17, 81, 1, 8, 160, 0, 19, '', 'Ok', 'To Pay', 0.00, 'MH 12CH 9499', 64.00, 8.00, 0.00, 0.00, 0.00, 7.00, 0.00, '78', 87.00, '0.00', 0, 'Office', 'Consignor', 1, 26.70, 26.70, 26.70, -0.10, 0.00, 72.00, 614.00, 65, '2009-08-28', '', 0, 0, 0, 0, 0, 7.00, 66.00, 0, 0, 5, '2009-09-01 00:00:00', '');
INSERT INTO `lrs` VALUES(23, 23, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 66, '2009-08-28', '', 0, 45, 0, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(24, 24, '2009-08-01', NULL, NULL, 2, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'To Pay', 0.00, '', 689.00, 87.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 38.80, 38.80, 38.80, -0.40, 0.00, 776.00, 892.00, 67, '2009-08-28', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 14, '2009-08-17 00:00:00', '');
INSERT INTO `lrs` VALUES(25, 25, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 689.00, 87.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 38.80, 38.80, 38.80, -0.40, 0.00, 776.00, 892.00, 68, '2009-08-28', '', 0, 0, 28, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(26, 26, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 704.00, 88.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 39.60, 39.60, 39.60, 0.20, 0.00, 792.00, 911.00, 69, '2009-08-28', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(27, 27, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 70, '2009-08-28', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(28, 28, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 71, '2009-08-28', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(29, 29, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 72, '2009-08-28', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(30, 30, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 73, '2009-08-28', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(31, 31, '2009-08-28', NULL, NULL, 2, 1, 5, 7, 1, 1, 206, 0, 983, '', '', 'TBB', 0.00, 'MH 12CH 9499', 81.00, 9.00, 0.00, 0.00, 0.00, 0.00, 0.00, '8', 0.00, '0.00', 0, 'Door', '', 1, 4.50, 4.50, 4.50, -0.50, 0.00, 90.00, 103.00, 74, '2009-08-29', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(32, 32, '2009-08-29', NULL, NULL, 2, 1, 6, 58, 120, 12, 206, 0, 983, '', 'updated by rajendra', 'To Pay', 0.00, 'MH 12CH 9499', 36.00, 6.00, 0.00, 0.00, 0.00, 0.00, 0.00, '89', 0.00, '0.00', 0, 'Door', '', 1, 2.10, 2.10, 2.10, -0.30, 0.00, 42.00, 48.00, 75, '2009-09-04', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(33, 33, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 704.00, 88.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 39.60, 39.60, 39.60, 0.20, 0.00, 792.00, 911.00, 76, '2009-09-04', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(34, 34, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 45, '2009-07-18', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(35, 35, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 45, '2009-07-18', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(36, 36, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 99, '2009-09-11', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(37, 37, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 100, '2009-09-11', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(38, 38, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 101, '2009-09-15', '', 0, 45, 0, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(39, 39, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 704.00, 88.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 39.60, 39.60, 39.60, 0.20, 0.00, 792.00, 911.00, 102, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(40, 40, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', 'ok', 'TBB', 0.00, 'MH 12 CH 9498', 648.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, '785,456,4568,5468,4568,45680,4568,456890,54763374634,546,456,4564,45645', 5.00, '0.00', 0, 'Door', '', 1, 36.40, 36.40, 36.40, -0.20, 0.00, 728.00, 837.00, 70, '2009-08-28', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(41, 41, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 103, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(42, 42, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 104, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(43, 43, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 105, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(45, 45, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 704.00, 88.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 39.60, 39.60, 39.60, 0.20, 0.00, 792.00, 911.00, 106, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(46, 46, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 123, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(47, 47, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 125, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(48, 48, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 135, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(49, 49, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 139, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(50, 50, '2009-08-01', NULL, NULL, 12, 12, 81, 128, 8, 61, 58, 0, 112, '', 'This Is First Entry', 'TBB', 0.00, 'MH 12CH 9499', 49.00, 7.00, 6.00, 6.00, 6.00, 3.00, 6.00, 'a1', 7.00, '6.00', 0, 'Office', 'Consignee', 5, 5.25, 5.25, 5.25, 0.25, 6.00, 80.00, 121.00, 136, '2009-09-25', '', 0, 45, 0, 0, 0, 5.00, 5.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(51, 51, '2009-08-01', NULL, NULL, 1, 1, 791, 3, 1, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 706.00, 90.00, 2.00, 2.00, 2.00, 0.00, 2.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 40.20, 40.20, 40.20, 0.40, 0.00, 804.00, 925.00, 137, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(52, 52, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 138, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(53, 53, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 640.00, 80.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 140, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(54, 54, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', '', 'TBB', 0.00, '', 647.00, 87.00, 0.00, 0.00, 0.00, 0.00, 0.00, 'w2', 0.00, '0.00', 0, 'Door', '', 1, 36.00, 36.00, 36.00, 0.00, 0.00, 720.00, 828.00, 141, '2009-09-25', '', 0, 0, 43, 0, 0, 0.00, 0.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(55, 55, '2009-08-01', NULL, NULL, 1, 1, 6, 3, 120, 1, 205, 0, 979, '', 'check print', 'TBB', 0.00, 'MH 42 B 3116', 821.00, 119.00, 0.00, 0.00, 0.00, 3.00, 0.00, 'w2', 0.00, '2.00', 0, 'Door', 'Consignor', 1, 124.05, 124.05, 124.05, -0.15, 2.00, 940.00, 2853.00, 148, '2009-09-25', '', 0, 0, 52, 0, 0, 67.00, 23.00, 0, 0, 0, '0000-00-00 00:00:00', '');
INSERT INTO `lrs` VALUES(56, 56, '2009-09-02', NULL, NULL, 1, 1, 2, 230, 6, 33, 207, 0, 984, '', '', 'TBB', 0.00, '', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '3', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 151, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(57, 57, '2009-09-15', NULL, NULL, 1, 2, 985, 985, 208, 208, 208, 0, 983, '', '', 'TBB', 0.00, 'MH 12CH 9499', 0.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '89', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 35.00, 84.00, 152, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(58, 58, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 155, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(59, 59, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 228, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(60, 60, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 231, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(61, 61, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 232, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(62, 62, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 233, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(63, 63, '2009-09-15', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', '', 'TBB', 0.00, '', 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '76', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 235, '2009-10-12', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(64, 64, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 235, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(65, 65, '2009-09-15', NULL, NULL, 1, 1, 86, 478, 18, 12, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '454', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 235, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(66, 66, '2009-09-15', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 6.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '90', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 6.00, 6.00, 235, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(67, 67, '2009-09-15', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 6.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '90', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 6.00, 6.00, 235, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(68, 68, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 6.00, 6.00, 7.00, 7.00, 7.00, 7.00, 7.00, '8900', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 40.00, 89.00, 241, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(69, 69, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 0.00, 7.00, 7.00, 7.00, 7.00, 7.00, '8789897', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 36.00, 85.00, 243, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(70, 70, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 6, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 5.00, 10.00, 2.00, 13.00, 6.00, 11.00, '677,788,87798,998,8', 800.00, '6.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 48.00, 60.00, 244, '2009-09-25', '', 0, 0, 53, 0, 0, 2.00, 6.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(71, 71, '2009-09-17', NULL, NULL, 1, 2, 6, 13, 120, 1, 1, 0, 3, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 7.00, 7.00, 7.00, 7.00, 7.00, '8', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 44.00, 93.00, 249, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(72, 72, '2009-09-17', NULL, NULL, 2, 1, 6, 13, 120, 1, 209, 0, 13, '', '', 'To Pay', 0.00, 'MH 12CH 9499', 7.00, 7.00, 7.00, 7.00, 7.00, 0.00, 7.00, '9', 7.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 42.00, 91.00, 250, '2009-09-25', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(73, 73, '2009-09-18', NULL, NULL, 2, 1, 986, 44, 120, 31, 208, 0, 983, '', 'Ok', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 0.00, 0.00, 0.00, 8.00, 0.00, '89', 89.00, '8.00', 0, 'Office', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 14.00, 14.00, 217, '2009-09-25', '', 0, 0, 0, 0, 0, 8.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(74, 74, '2009-09-18', NULL, NULL, 1, 1, 17, 60, 1, 208, 208, 0, 983, '', '', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 8.00, 88.00, 8.00, 8.00, 8.00, '9', 8.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 128.00, 192.00, 218, '2009-09-25', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(75, 75, '2009-09-18', NULL, NULL, 1, 1, 6, 791, 120, 1, 23, 0, 243, '', '8', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 0.00, 0.00, 0.00, 88.00, 0.00, '909', 8.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 14.00, 78.00, 219, '2009-09-25', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(76, 76, '2009-09-18', NULL, NULL, 2, 1, 6, 58, 120, 12, 31, 0, 44, '', 'Ook', 'TBB', 0.00, 'MH 12CH 9499', 42.00, 42.00, 0.00, 88.00, 8.00, 8.00, 0.00, '90', 8.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 180.00, 244.00, 220, '2009-09-25', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(77, 77, '2009-09-18', NULL, NULL, 2, 1, 6, 58, 120, 12, 31, 0, 44, '', 'Ook', 'TBB', 0.00, 'MH 12CH 9499', 42.00, 42.00, 0.00, 88.00, 8.00, 8.00, 0.00, '90', 8.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 180.00, 244.00, 221, '2009-09-25', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(78, 78, '2009-09-18', NULL, NULL, 1, 1, 6, 10, 120, 10, 120, 0, 6, '', '', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 0.00, 0.00, 0.00, 0.00, 0.00, '90', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 215, '2009-09-25', '', 0, 0, 83, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(79, 79, '2009-09-18', NULL, NULL, 1, 1, 6, 10, 120, 10, 120, 0, 6, '', '', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 0.00, 0.00, 0.00, 0.00, 0.00, '90', 0.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 216, '2009-09-25', '', 0, 0, 0, 0, 0, 0.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(80, 80, '2009-09-18', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 13, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, '87', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 51.00, 132.00, 217, '2009-09-25', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(81, 81, '2009-09-18', NULL, NULL, 1, 1, 19, 10, 160, 10, 120, 0, 11, '', '9', 'TBB', 0.00, 'MH 12 DG 162', 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, 9.00, '8908', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 52.00, 133.00, 223, '2009-09-25', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(82, 82, '2009-09-18', NULL, NULL, 1, 1, 19, 10, 160, 10, 120, 0, 11, '', '9', 'TBB', 0.00, 'MH 12 DG 162', 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, 9.00, '8908', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 52.00, 133.00, 224, '2009-09-25', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(83, 83, '2009-09-18', NULL, NULL, 1, 1, 6, 2, 120, 6, 207, 0, 13, '', '9', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 9.00, 9.00, 9.00, 9.00, 9.00, '89', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 50.00, 131.00, 227, '2009-09-25', '', 0, 0, 44, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(84, 84, '2009-09-18', NULL, NULL, 1, 1, 6, 2, 120, 6, 207, 0, 13, '', '9', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 9.00, 9.00, 9.00, 9.00, 9.00, '89', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 50.00, 131.00, 228, '2009-09-25', '', 0, 0, 45, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(85, 85, '2009-09-18', NULL, NULL, 1, 1, 6, 2, 120, 6, 207, 0, 13, '', '9', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 9.00, 9.00, 9.00, 9.00, 9.00, '89', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 50.00, 131.00, 229, '2009-09-25', '', 0, 0, 48, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(86, 86, '2009-09-18', NULL, NULL, 1, 1, 6, 3, 120, 1, 8, 0, 81, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 12.00, 12.00, 77.00, 7.00, 7.00, 7.00, 7.00, '90', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 122.00, 171.00, 230, '2009-09-26', '', 0, 0, 49, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(87, 87, '2009-09-18', NULL, NULL, 1, 1, 19, 10, 160, 10, 120, 0, 11, '', '9', 'TBB', 0.00, 'MH 12 DG 162', 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, 9.00, '8908', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 52.00, 133.00, 231, '2009-10-01', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(88, 88, '2009-09-18', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 13, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, '87', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 51.00, 132.00, 232, '2009-10-06', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(89, 89, '2009-09-18', NULL, NULL, 1, 1, 6, 3, 120, 1, 8, 0, 81, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 0.00, 5.00, 6.00, 7.00, 8.00, '90', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 33.00, 82.00, 233, '2009-10-12', '', 0, 0, 50, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(90, 90, '2009-09-18', NULL, NULL, 1, 1, 6, 3, 120, 1, 8, 0, 81, '', 'Ok', 'TBB', 0.00, 'MH 12CH 9499', 16.00, 16.00, 9.00, 9.00, 9.00, 9.00, 9.00, '890', 9.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 68.00, 149.00, 234, '2009-10-12', '', 0, 0, 51, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(91, 91, '2009-09-18', NULL, NULL, 1, 1, 19, 10, 160, 10, 120, 0, 11, '', '9', 'TBB', 0.00, 'MH 12 DG 162', 8.00, 8.00, 9.00, 9.00, 9.00, 9.00, 9.00, '8908', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 52.00, 133.00, 236, '2009-10-12', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(92, 92, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 1, 0, 6, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 5.00, 10.00, 2.00, 13.00, 6.00, 11.00, '677,788,87798,998,8', 800.00, '6.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 48.00, 60.00, 237, '2009-10-13', '', 0, 0, 54, 0, 0, 2.00, 6.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(93, 93, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 1, 0, 6, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 5.00, 10.00, 2.00, 13.00, 6.00, 11.00, '677,788,87798,998,8', 800.00, '6.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 48.00, 60.00, 0, '2009-09-25', '', 0, 0, 80, 0, 0, 2.00, 6.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(94, 94, '2009-09-16', NULL, NULL, 1, 1, 6, 791, 120, 1, 1, 0, 6, '', 'Created By Rajendra', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 5.00, 10.00, 2.00, 13.00, 6.00, 11.00, '677,788,87798,998,8', 800.00, '6.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 48.00, 60.00, 228, '2009-09-25', '', 0, 0, 0, 0, 0, 2.00, 6.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(95, 95, '2009-09-18', NULL, NULL, 1, 1, 6, 58, 120, 12, 6, 0, 2, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 8.00, 8.00, 8.00, 7.00, 8.00, '89', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 32.00, 81.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(96, 96, '2009-10-06', NULL, NULL, 1, 1, 6, 17, 120, 1, 1, 0, 14, '', 'Ok', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '868u8', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(97, 97, '2009-10-06', NULL, NULL, 1, 1, 791, 6, 1, 120, 207, 0, 34, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 14.00, 14.00, 7.00, 7.00, 7.00, 7.00, 7.00, '4543', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 56.00, 105.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(98, 98, '2009-10-06', NULL, NULL, 1, 1, 791, 6, 1, 120, 207, 0, 34, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 14.00, 14.00, 7.00, 7.00, 7.00, 7.00, 7.00, '4543', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 56.00, 105.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(99, 99, '2009-10-06', NULL, NULL, 1, 1, 6, 791, 120, 1, 120, 0, 11, '', '', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '980', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 42.00, 91.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(100, 100, '2009-10-06', NULL, NULL, 1, 1, 6, 791, 120, 1, 120, 0, 11, '', '', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '980', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 42.00, 91.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(101, 101, '2009-10-06', NULL, NULL, 1, 1, 6, 791, 120, 1, 208, 0, 983, '', '9', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 7.00, 79.00, 9.00, 9.00, 7.00, 'oj', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 116.00, 197.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(102, 102, '2009-10-06', NULL, NULL, 1, 1, 6, 6, 120, 120, 208, 0, 1000, '', 'hi ', 'TBB', 0.00, 'MH 12CH 9499', 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, '8', 9.00, '9.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 9.00, 54.00, 135.00, 0, '0000-00-00', '', 0, 0, 81, 0, 0, 9.00, 9.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(103, 103, '2009-10-06', NULL, NULL, 1, 1, 6, 791, 120, 1, 33, 0, 8, '', '3', 'TBB', 0.00, 'MH 12CH 9499', 6.00, 6.00, 3.00, 3.00, 3.00, 3.00, 3.00, '9890', 3.00, '3.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 3.00, 24.00, 33.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 3.00, 3.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(104, 104, '2009-10-06', NULL, NULL, 1, 1, 6, 230, 120, 33, 208, 0, 983, '', '7', 'TBB', 0.00, 'MH 12CH 9499', 6.00, 6.00, 0.00, 7.00, 7.00, 7.00, 7.00, '757', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 33.00, 82.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(105, 105, '2009-10-06', NULL, NULL, 1, 1, 6, 849, 120, 97, 31, 0, 44, '', '', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 0.00, 7.00, 7.00, 7.00, 7.00, '546', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 35.00, 84.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(106, 106, '2009-10-06', NULL, NULL, 1, 1, 6, 791, 120, 1, 207, 0, 13, '', '8', 'TBB', 0.00, 'MH 12CH 9499', 7.00, 7.00, 0.00, 8.00, 8.00, 8.00, 7.00, '98', 8.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 37.00, 101.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(107, 107, '2009-10-07', NULL, NULL, 1, 1, 6, 791, 120, 1, 24, 0, 105, '', 'Ok', 'TBB', 0.00, 'MH 12CH 9499', 8.00, 8.00, 8.00, 7.00, 0.00, 0.00, 0.00, '798', 6.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 31.00, 31.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 0.00, 6.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(108, 108, '2009-10-08', NULL, NULL, 1, 1, 6, 791, 120, 1, 33, 0, 8, '', '7', 'TBB', 0.00, 'MH 12 CH 9498', 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, '87', 7.00, '7.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 7.00, 42.00, 91.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 7.00, 7.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(109, 109, '2009-10-08', NULL, NULL, 1, 1, 6, 12, 120, 12, 120, 0, 11, '', '', 'TBB', 0.00, 'MH 12 DG 162', 7.00, 77.00, 0.00, 7.00, 6.00, 6.00, 7.00, '879', 6.00, '0.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 6.00, 104.00, 104.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 6.00, 0.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(110, 110, '2009-10-08', NULL, NULL, 1, 1, 6, 8, 120, 33, 33, 0, 8, '', '8', 'TBB', 0.00, 'MH 12 CH 9498', 64.00, 8.00, 8.00, 8.00, 8.00, 8.00, 8.00, '890', 8.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 104.00, 104.00, 0, '0000-00-00', '', 0, 0, 82, 0, 0, 0.00, 8.00, 0, 0, 0, NULL, '');
INSERT INTO `lrs` VALUES(111, 111, '2009-10-28', NULL, NULL, 1, 1, 6, 2, 120, 6, 21, 0, 35, '', '8', 'Paid', 0.00, 'MH 12CH 9499', 8.00, 8.00, 9.00, 8.00, 5.00, 8.00, 9.00, '9898', 89.00, '8.00', 0, 'Door', '', 0, 0.00, 0.00, 0.00, 0.00, 8.00, 47.00, 111.00, 0, '0000-00-00', '', 0, 0, 0, 0, 0, 8.00, 8.00, 0, 0, 0, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `lrwisedispatch`
--

CREATE TABLE `lrwisedispatch` (
  `MemoID` int(10) NOT NULL AUTO_INCREMENT,
  `MemoNo` int(10) NOT NULL,
  `MemoDate` date NOT NULL,
  `OwnerHire` text COLLATE latin1_general_ci NOT NULL,
  `VehicleID` int(10) NOT NULL,
  `OwnerID` int(10) NOT NULL,
  `SupplierID` int(10) NOT NULL,
  `StaffMasterID` int(10) NOT NULL,
  `BookingOfficeID` int(10) NOT NULL,
  `HamalMasterId1` int(10) NOT NULL,
  `HamalMasterId2` int(10) NOT NULL,
  `DriverID` int(10) NOT NULL,
  `FreightSettled` decimal(10,2) NOT NULL,
  `ExtraWidth` int(10) NOT NULL,
  `ExtraHeight` int(10) NOT NULL,
  `ExtraLengthCh` int(10) NOT NULL,
  `ExtraWeight` int(10) NOT NULL,
  `ExtraWeightAmt` int(10) NOT NULL,
  `CleanerID` int(10) NOT NULL,
  `AmountToGive` decimal(10,2) NOT NULL,
  `FreightAdvance` decimal(10,2) NOT NULL,
  `AdvPaidDate` date NOT NULL,
  `AccountGroupID` int(10) NOT NULL,
  `AccountID` int(10) NOT NULL,
  `BalanceAmount` int(10) NOT NULL,
  `TaxID` int(10) NOT NULL,
  `TaxAmount1` decimal(10,2) NOT NULL,
  `TaxAmount2` decimal(10,2) NOT NULL,
  `TaxAmount3` decimal(10,2) NOT NULL,
  `TDS` int(10) NOT NULL,
  `OctroiAdvance` int(10) NOT NULL,
  `CreditDays` int(10) NOT NULL,
  `DestinationFreight` decimal(10,2) NOT NULL,
  `HVCommission` decimal(10,2) NOT NULL,
  `HVHamali` decimal(10,2) NOT NULL,
  `HVWarai` decimal(10,2) NOT NULL,
  `HVOtherCharges` decimal(10,2) NOT NULL,
  `DetentionAmount` decimal(10,2) NOT NULL,
  `Rounding` decimal(10,2) NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `ExpenseID` int(10) NOT NULL,
  `PayOrderID` int(10) NOT NULL,
  `PaymentID` int(10) NOT NULL,
  `PaymentDate` date NOT NULL,
  `IncrededFreight` int(10) NOT NULL,
  `TDSCut` int(10) NOT NULL,
  `ChallanNoDate` text COLLATE latin1_general_ci NOT NULL,
  `Bank` text COLLATE latin1_general_ci NOT NULL,
  `Area` text COLLATE latin1_general_ci NOT NULL,
  `TotalFreight` decimal(10,2) NOT NULL,
  `TDSCertificateID` int(10) NOT NULL,
  `MemoAdvAfterwards` int(10) NOT NULL,
  `BillTrackID` int(10) NOT NULL,
  `AddedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `EditedBy` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`MemoID`),
  UNIQUE KEY `MemoNo` (`MemoNo`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=289 ;

--
-- Dumping data for table `lrwisedispatch`
--

INSERT INTO `lrwisedispatch` VALUES(195, 214, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 6.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(194, 213, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 6.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(193, 212, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 6.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(192, 211, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 6.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(57, 75, '2009-09-04', 'Hire', 1, 0, 3, 0, 0, 0, 0, 1, 0.00, 0, 0, 0, 0, 0, 0, -35.00, 7.00, '2009-09-04', 0, 0, -35, 0, 0.00, 0.00, 0.00, 0, 0, 0, 7.00, 7.00, 7.00, 7.00, 7.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(58, 76, '2009-09-04', 'Hire', 1, 0, 3, 0, 0, 0, 0, 1, 0.00, 0, 0, 0, 0, 0, 0, 16.00, 8.00, '2009-09-04', 0, 0, 16, 0, 0.00, 0.00, 0.00, 0, 0, 0, 8.00, 8.00, 8.00, 8.00, 8.00, 8.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 792.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(60, 80, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 70.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(61, 81, '2009-07-18', 'Hire', 17, 0, 3, 0, 2, 0, 0, 1, 6000.89, 0, 0, 0, 0, 0, 0, 5909.89, 90.00, '2009-07-18', 0, 0, 5010, 1, 0.00, 0.00, 0.00, 0, 89, 3, 78.00, 9.00, 2.00, 2.00, 2.00, 2.00, 0.11, 'ok', 0, 0, 1, '2009-08-01', 0, 0, '', '', '', 1600.00, 0, 0, 0, 'rajendra', 'rajendra+infosoft-2009-08-01 12:51:22+admin-2009-08-05 13:26:31+admin-2009-08-06 14:57:22+admin-2009-08-08 14:57:08+admin-2009-08-08 14:58:03+admin-2009-08-08 14:58:22+admin-2009-08-08 17:10:25+admin-2009-08-08 17:12:34+admin-2009-08-08 17:12:53+admin-200');
INSERT INTO `lrwisedispatch` VALUES(63, 83, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(64, 84, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 104.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(65, 85, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 70.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(66, 86, '2009-08-28', 'select', 2, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 56.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(67, 87, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, -72.00, 0.00, '2009-08-28', 0, 0, -72, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 46, '2009-09-11', 0, 0, '', '', '', 72.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(68, 88, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 46, '2009-09-11', 0, 0, '', '', '', 80.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(71, 91, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(72, 92, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 104.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(73, 93, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 70.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(74, 94, '2009-08-28', 'select', 2, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 56.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(75, 95, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, -72.00, 0.00, '2009-08-28', 0, 0, -72, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 72.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(76, 96, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 80.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(77, 97, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, -776.00, 0.00, '2009-08-28', 0, 0, -776, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 776.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(78, 98, '2009-08-28', 'select', 1, 0, 3, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 776.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(79, 89, '2009-08-28', 'select', 2, 0, 5, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-08-28', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 792.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(80, 99, '2009-09-11', 'Hire', 1, 0, 3, 0, 1, 0, 0, 1, 0.00, 0, 0, 0, 0, 0, 0, -4.00, 4.00, '2009-09-11', 0, 0, -4, 0, 0.00, 0.00, 0.00, 0, 0, 0, 4.00, 4.00, 4.00, 0.00, 0.00, 0.00, 0.00, 'ok', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, 'admin', '+admin-2009-09-11 17:29:37+admin-2009-09-11 17:35:05');
INSERT INTO `lrwisedispatch` VALUES(81, 100, '2009-09-11', 'Hire', 1, 0, 3, 0, 0, 0, 0, 3, 343434.00, 0, 0, 0, 0, 0, 0, 343452.00, 6.00, '2009-09-11', 0, 0, 343452, 0, 0.00, 0.00, 0.00, 0, 0, 0, 6.00, 0.00, 6.00, 6.00, 6.00, 6.00, 0.00, 'ok', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(82, 101, '2009-09-15', 'Hire', 1, 0, 3, 0, 2, 0, 0, 1, 70009.00, 0, 0, 0, 0, 0, 0, 69941.00, 89.00, '2009-09-15', 0, 0, 69941, 0, 0.00, 0.00, 0.00, 0, 0, 0, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 0.00, 'hi', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 80.00, 0, 0, 0, 'admin', '');
INSERT INTO `lrwisedispatch` VALUES(83, 102, '2009-09-25', 'Hire', 1, 0, 5, 0, 0, 0, 0, 1, 87997987.00, 0, 0, 0, 0, 0, 0, 87998005.00, 9.00, '0000-00-00', 0, 0, 87998005, 0, 0.00, 0.00, 0.00, 0, 9, 9, 9.00, 9.00, 9.00, 9.00, 9.00, 9.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 792.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(84, 103, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(85, 104, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(86, 105, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(87, 106, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 792.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(88, 107, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(89, 108, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(90, 109, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(91, 110, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(92, 111, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(93, 112, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(94, 113, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(95, 114, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(96, 115, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(97, 116, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(98, 117, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(99, 118, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(100, 119, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(101, 120, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(102, 121, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(103, 122, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(104, 123, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(105, 124, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(106, 125, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(107, 126, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(108, 127, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(109, 128, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(110, 129, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(111, 130, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(112, 131, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(113, 132, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(114, 133, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(115, 134, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(116, 135, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(117, 136, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 80.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(118, 137, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 804.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(119, 138, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(120, 139, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, '', '');
INSERT INTO `lrwisedispatch` VALUES(121, 140, '2009-09-25', 'select', 28, 0, 0, 0, 1, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '+Admin-2009-10-12 18:39:46');
INSERT INTO `lrwisedispatch` VALUES(122, 141, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 720.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(123, 142, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(124, 143, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(125, 144, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(126, 145, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(127, 146, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(128, 147, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(129, 148, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 940.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(130, 149, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(131, 150, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(132, 151, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(133, 152, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 35.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(134, 153, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(135, 154, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(136, 155, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(137, 156, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(138, 157, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(139, 158, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(140, 159, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(141, 160, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(142, 161, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(143, 162, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(144, 163, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(145, 164, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(146, 165, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 42.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(288, 237, '2009-10-13', 'Hire', 3, 0, 3, 0, 2, 0, 0, 8, 980.00, 0, 0, 0, 0, 0, 0, 996.00, 8.00, '2009-10-13', 0, 0, 996, 0, 0.00, 0.00, 0.00, 0, 8, 0, 8.00, 8.00, 8.00, 8.00, 8.00, 8.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(287, 236, '2009-10-12', 'Hire', 1, 0, 8, 0, 2, 0, 0, 7, 8989.00, 0, 0, 0, 0, 0, 0, 9005.00, 8.00, '2009-10-12', 0, 0, 9005, 0, 0.00, 0.00, 0.00, 0, 0, 0, 8.00, 8.00, 8.00, 8.00, 8.00, 8.00, 0.00, 'ok', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '+Admin-2009-10-12 18:38:51');
INSERT INTO `lrwisedispatch` VALUES(286, 235, '2009-10-12', 'select', 2, 0, 7, 0, 0, 0, 0, 8, 565757.00, 0, 0, 0, 0, 0, 0, 565771.00, 7.00, '2009-10-12', 0, 0, 565771, 0, 0.00, 0.00, 0.00, 0, 0, 0, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 0.00, 'ok', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(285, 234, '2009-10-12', 'Hire', 1, 0, 3, 0, 0, 0, 0, 7, 8999.00, 0, 0, 0, 0, 0, 0, 9013.00, 7.00, '2009-10-12', 0, 0, 9013, 0, 0.00, 0.00, 0.00, 0, 0, 0, 7.00, 7.00, 7.00, 7.00, 7.00, 7.00, 0.00, 'll', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 68.00, 0, 0, 0, 'Admin', '+Admin-2009-10-12 17:39:08');
INSERT INTO `lrwisedispatch` VALUES(284, 233, '2009-10-12', 'Hire', 1, 0, 7, 0, 0, 0, 0, 6, 3000.00, 0, 0, 0, 0, 0, 0, 3016.00, 8.00, '0000-00-00', 0, 0, 3016, 0, 0.00, 0.00, 0.00, 0, 8, 8, 8.00, 8.00, 8.00, 8.00, 8.00, 8.00, 0.00, 'ok', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 33.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(283, 232, '2009-10-06', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-10-06', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 51.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(282, 231, '2009-10-01', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-10-01', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(281, 230, '2009-09-26', 'select', 2, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-26', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '+Admin-2009-10-06 12:50:19');
INSERT INTO `lrwisedispatch` VALUES(280, 229, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 50.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(279, 228, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 50.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(278, 227, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 50.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(277, 226, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 50.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(276, 225, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 50.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(275, 224, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(274, 223, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(273, 222, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(272, 221, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(271, 220, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(270, 219, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(269, 218, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 52.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(268, 217, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 51.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(266, 215, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');
INSERT INTO `lrwisedispatch` VALUES(267, 216, '2009-09-25', 'select', 28, 0, 0, 0, 0, 0, 0, 2, 0.00, 0, 0, 0, 0, 0, 0, 0.00, 0.00, '2009-09-25', 0, 0, 0, 0, 0.00, 0.00, 0.00, 0, 0, 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', 0, 0, 0, '0000-00-00', 0, 0, '', '', '', 0.00, 0, 0, 0, 'Admin', '');

-- --------------------------------------------------------

--
-- Table structure for table `lrwisedispatchdetails`
--

CREATE TABLE `lrwisedispatchdetails` (
  `MemoNo` int(10) NOT NULL,
  `ConsignmentNo` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `lrwisedispatchdetails`
--

INSERT INTO `lrwisedispatchdetails` VALUES(46, 10);
INSERT INTO `lrwisedispatchdetails` VALUES(46, 8);
INSERT INTO `lrwisedispatchdetails` VALUES(49, 16);
INSERT INTO `lrwisedispatchdetails` VALUES(48, 9);
INSERT INTO `lrwisedispatchdetails` VALUES(46, 5);
INSERT INTO `lrwisedispatchdetails` VALUES(47, 7);
INSERT INTO `lrwisedispatchdetails` VALUES(116, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(46, 11);
INSERT INTO `lrwisedispatchdetails` VALUES(50, 3);
INSERT INTO `lrwisedispatchdetails` VALUES(51, 6);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 11);
INSERT INTO `lrwisedispatchdetails` VALUES(52, 2);
INSERT INTO `lrwisedispatchdetails` VALUES(54, 15);
INSERT INTO `lrwisedispatchdetails` VALUES(55, 14);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 10);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 9);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 7);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 5);
INSERT INTO `lrwisedispatchdetails` VALUES(53, 4);
INSERT INTO `lrwisedispatchdetails` VALUES(56, 12);
INSERT INTO `lrwisedispatchdetails` VALUES(115, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(57, 13);
INSERT INTO `lrwisedispatchdetails` VALUES(58, 12);
INSERT INTO `lrwisedispatchdetails` VALUES(59, 13);
INSERT INTO `lrwisedispatchdetails` VALUES(60, 16);
INSERT INTO `lrwisedispatchdetails` VALUES(61, 17);
INSERT INTO `lrwisedispatchdetails` VALUES(62, 18);
INSERT INTO `lrwisedispatchdetails` VALUES(63, 19);
INSERT INTO `lrwisedispatchdetails` VALUES(64, 20);
INSERT INTO `lrwisedispatchdetails` VALUES(65, 22);
INSERT INTO `lrwisedispatchdetails` VALUES(66, 23);
INSERT INTO `lrwisedispatchdetails` VALUES(67, 24);
INSERT INTO `lrwisedispatchdetails` VALUES(68, 25);
INSERT INTO `lrwisedispatchdetails` VALUES(69, 26);
INSERT INTO `lrwisedispatchdetails` VALUES(70, 27);
INSERT INTO `lrwisedispatchdetails` VALUES(71, 28);
INSERT INTO `lrwisedispatchdetails` VALUES(72, 29);
INSERT INTO `lrwisedispatchdetails` VALUES(73, 30);
INSERT INTO `lrwisedispatchdetails` VALUES(74, 31);
INSERT INTO `lrwisedispatchdetails` VALUES(75, 32);
INSERT INTO `lrwisedispatchdetails` VALUES(76, 33);
INSERT INTO `lrwisedispatchdetails` VALUES(114, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(113, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(112, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(111, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(110, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(109, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(108, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(107, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(106, 45);
INSERT INTO `lrwisedispatchdetails` VALUES(105, 43);
INSERT INTO `lrwisedispatchdetails` VALUES(104, 42);
INSERT INTO `lrwisedispatchdetails` VALUES(103, 41);
INSERT INTO `lrwisedispatchdetails` VALUES(102, 39);
INSERT INTO `lrwisedispatchdetails` VALUES(101, 38);
INSERT INTO `lrwisedispatchdetails` VALUES(100, 37);
INSERT INTO `lrwisedispatchdetails` VALUES(99, 36);
INSERT INTO `lrwisedispatchdetails` VALUES(45, 35);
INSERT INTO `lrwisedispatchdetails` VALUES(45, 34);
INSERT INTO `lrwisedispatchdetails` VALUES(45, 8);
INSERT INTO `lrwisedispatchdetails` VALUES(45, 1);
INSERT INTO `lrwisedispatchdetails` VALUES(117, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(118, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(119, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(120, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(121, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(122, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(123, 46);
INSERT INTO `lrwisedispatchdetails` VALUES(124, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(125, 47);
INSERT INTO `lrwisedispatchdetails` VALUES(126, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(127, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(128, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(129, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(130, 49);
INSERT INTO `lrwisedispatchdetails` VALUES(131, 49);
INSERT INTO `lrwisedispatchdetails` VALUES(132, 49);
INSERT INTO `lrwisedispatchdetails` VALUES(133, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(134, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(135, 48);
INSERT INTO `lrwisedispatchdetails` VALUES(136, 50);
INSERT INTO `lrwisedispatchdetails` VALUES(137, 51);
INSERT INTO `lrwisedispatchdetails` VALUES(138, 52);
INSERT INTO `lrwisedispatchdetails` VALUES(139, 49);
INSERT INTO `lrwisedispatchdetails` VALUES(140, 53);
INSERT INTO `lrwisedispatchdetails` VALUES(141, 54);
INSERT INTO `lrwisedispatchdetails` VALUES(142, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(143, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(144, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(145, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(146, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(147, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(148, 55);
INSERT INTO `lrwisedispatchdetails` VALUES(149, 56);
INSERT INTO `lrwisedispatchdetails` VALUES(150, 56);
INSERT INTO `lrwisedispatchdetails` VALUES(151, 56);
INSERT INTO `lrwisedispatchdetails` VALUES(152, 57);
INSERT INTO `lrwisedispatchdetails` VALUES(153, 58);
INSERT INTO `lrwisedispatchdetails` VALUES(154, 58);
INSERT INTO `lrwisedispatchdetails` VALUES(155, 58);
INSERT INTO `lrwisedispatchdetails` VALUES(156, 59);
INSERT INTO `lrwisedispatchdetails` VALUES(157, 59);
INSERT INTO `lrwisedispatchdetails` VALUES(158, 59);
INSERT INTO `lrwisedispatchdetails` VALUES(159, 60);
INSERT INTO `lrwisedispatchdetails` VALUES(160, 61);
INSERT INTO `lrwisedispatchdetails` VALUES(161, 61);
INSERT INTO `lrwisedispatchdetails` VALUES(162, 61);
INSERT INTO `lrwisedispatchdetails` VALUES(163, 61);
INSERT INTO `lrwisedispatchdetails` VALUES(164, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(165, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(166, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(167, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(168, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(169, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(170, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(171, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(172, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(173, 63);
INSERT INTO `lrwisedispatchdetails` VALUES(174, 63);
INSERT INTO `lrwisedispatchdetails` VALUES(175, 64);
INSERT INTO `lrwisedispatchdetails` VALUES(176, 65);
INSERT INTO `lrwisedispatchdetails` VALUES(177, 65);
INSERT INTO `lrwisedispatchdetails` VALUES(178, 65);
INSERT INTO `lrwisedispatchdetails` VALUES(179, 66);
INSERT INTO `lrwisedispatchdetails` VALUES(180, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(181, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(182, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(183, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(184, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(185, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(186, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(187, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(188, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(189, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(190, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(191, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(192, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(193, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(194, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(195, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(196, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(197, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(198, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(199, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(200, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(201, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(202, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(203, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(204, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(205, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(206, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(207, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(208, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(209, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(210, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(211, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(212, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(213, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(214, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(215, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(216, 69);
INSERT INTO `lrwisedispatchdetails` VALUES(217, 70);
INSERT INTO `lrwisedispatchdetails` VALUES(218, 70);
INSERT INTO `lrwisedispatchdetails` VALUES(219, 70);
INSERT INTO `lrwisedispatchdetails` VALUES(220, 70);
INSERT INTO `lrwisedispatchdetails` VALUES(221, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(222, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(223, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(224, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(225, 72);
INSERT INTO `lrwisedispatchdetails` VALUES(226, 72);
INSERT INTO `lrwisedispatchdetails` VALUES(227, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 74);
INSERT INTO `lrwisedispatchdetails` VALUES(229, 74);
INSERT INTO `lrwisedispatchdetails` VALUES(237, 92);
INSERT INTO `lrwisedispatchdetails` VALUES(231, 76);
INSERT INTO `lrwisedispatchdetails` VALUES(232, 77);
INSERT INTO `lrwisedispatchdetails` VALUES(233, 77);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 63);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 77);
INSERT INTO `lrwisedispatchdetails` VALUES(222, 82);
INSERT INTO `lrwisedispatchdetails` VALUES(221, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(220, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(219, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(218, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(217, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(223, 83);
INSERT INTO `lrwisedispatchdetails` VALUES(224, 84);
INSERT INTO `lrwisedispatchdetails` VALUES(225, 85);
INSERT INTO `lrwisedispatchdetails` VALUES(226, 86);
INSERT INTO `lrwisedispatchdetails` VALUES(227, 87);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 88);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 89);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 89);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 89);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 89);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 90);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 91);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 92);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 93);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 94);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 59);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 59);
INSERT INTO `lrwisedispatchdetails` VALUES(229, 60);
INSERT INTO `lrwisedispatchdetails` VALUES(233, 89);
INSERT INTO `lrwisedispatchdetails` VALUES(231, 60);
INSERT INTO `lrwisedispatchdetails` VALUES(232, 61);
INSERT INTO `lrwisedispatchdetails` VALUES(233, 62);
INSERT INTO `lrwisedispatchdetails` VALUES(234, 90);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 64);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 65);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 66);
INSERT INTO `lrwisedispatchdetails` VALUES(235, 67);
INSERT INTO `lrwisedispatchdetails` VALUES(236, 91);
INSERT INTO `lrwisedispatchdetails` VALUES(237, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(238, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(239, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(240, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(241, 68);
INSERT INTO `lrwisedispatchdetails` VALUES(242, 69);
INSERT INTO `lrwisedispatchdetails` VALUES(243, 69);
INSERT INTO `lrwisedispatchdetails` VALUES(244, 70);
INSERT INTO `lrwisedispatchdetails` VALUES(245, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(246, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(247, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(248, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(249, 71);
INSERT INTO `lrwisedispatchdetails` VALUES(250, 72);
INSERT INTO `lrwisedispatchdetails` VALUES(251, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(252, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(215, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(216, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(217, 73);
INSERT INTO `lrwisedispatchdetails` VALUES(218, 74);
INSERT INTO `lrwisedispatchdetails` VALUES(219, 75);
INSERT INTO `lrwisedispatchdetails` VALUES(220, 76);
INSERT INTO `lrwisedispatchdetails` VALUES(221, 77);
INSERT INTO `lrwisedispatchdetails` VALUES(215, 78);
INSERT INTO `lrwisedispatchdetails` VALUES(216, 79);
INSERT INTO `lrwisedispatchdetails` VALUES(217, 80);
INSERT INTO `lrwisedispatchdetails` VALUES(218, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(219, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(220, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(221, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(222, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(223, 81);
INSERT INTO `lrwisedispatchdetails` VALUES(224, 82);
INSERT INTO `lrwisedispatchdetails` VALUES(225, 83);
INSERT INTO `lrwisedispatchdetails` VALUES(226, 83);
INSERT INTO `lrwisedispatchdetails` VALUES(227, 83);
INSERT INTO `lrwisedispatchdetails` VALUES(228, 84);
INSERT INTO `lrwisedispatchdetails` VALUES(229, 85);
INSERT INTO `lrwisedispatchdetails` VALUES(230, 86);
INSERT INTO `lrwisedispatchdetails` VALUES(231, 87);
INSERT INTO `lrwisedispatchdetails` VALUES(232, 88);

-- --------------------------------------------------------

--
-- Table structure for table `perimains`
--

CREATE TABLE `perimains` (
  `PeriId` int(11) NOT NULL AUTO_INCREMENT,
  `PeriMainName` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`PeriId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `perimains`
--

INSERT INTO `perimains` VALUES(1, 'PUC', '0');
INSERT INTO `perimains` VALUES(2, 'Permit', '0');
INSERT INTO `perimains` VALUES(3, 'Fitness Certificate', '0');
INSERT INTO `perimains` VALUES(4, 'Insurance', '0');
INSERT INTO `perimains` VALUES(5, 'Tax', '0');

-- --------------------------------------------------------

--
-- Table structure for table `peri_mains`
--

CREATE TABLE `peri_mains` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `VehicleNo` varchar(255) NOT NULL,
  `PeriMainType` varchar(100) NOT NULL,
  `Date` date NOT NULL,
  `PermitLevel` varchar(100) NOT NULL,
  `No` varchar(100) NOT NULL,
  `Amount` double(6,2) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `Remark` text NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `peri_mains`
--

INSERT INTO `peri_mains` VALUES(1, 'KA 05 3421', 'Permit', '2009-05-22', 'National', 'DD324567', 3100.00, '2009-05-22', '2015-05-22', 'This is permit testing');
INSERT INTO `peri_mains` VALUES(2, 'Kk 05 3421', 'PUC', '2009-05-22', '', '', 0.00, '2009-05-22', '2009-05-22', '');
INSERT INTO `peri_mains` VALUES(3, 'DL 05 3421', 'Fitness Certificate', '2009-05-22', '', '1723983', 0.00, '2009-05-22', '2009-05-22', 'This is Fitness testing');
INSERT INTO `peri_mains` VALUES(4, 'KA 05 3421', 'Insurance', '2009-05-22', '', '56784333', 1234.00, '2009-05-22', '2009-05-22', 'This is insurance testing');
INSERT INTO `peri_mains` VALUES(5, 'DL 05 3421', 'Tax', '2009-05-22', '', '56784333', 123.90, '2009-05-22', '2009-05-22', 'This is tax testing');
INSERT INTO `peri_mains` VALUES(6, 'TA GG 3457', 'Permit', '2009-05-22', 'State', '1234355', 3335.00, '2009-05-22', '2010-07-22', 'seghh54jerjerj');
INSERT INTO `peri_mains` VALUES(7, 'TA GG 3457', 'Fitness Certificate', '2009-05-22', '', '', 100.00, '2009-05-22', '2009-05-22', 'jhdfjf');
INSERT INTO `peri_mains` VALUES(8, 'MH 05 3421', 'Permit', '2009-05-22', 'State', '', 0.00, '2009-05-22', '2009-05-22', '');
INSERT INTO `peri_mains` VALUES(9, 'MH 12 DG 162', 'PUC', '2009-09-16', '', '', 0.00, '2009-09-16', '2009-09-16', 'MH 05 3421');

-- --------------------------------------------------------

--
-- Table structure for table `receiptdetails`
--

CREATE TABLE `receiptdetails` (
  `BillNo` int(10) NOT NULL,
  `ReceiptNo` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `receiptdetails`
--

INSERT INTO `receiptdetails` VALUES(26, 60);
INSERT INTO `receiptdetails` VALUES(26, 60);
INSERT INTO `receiptdetails` VALUES(22, 61);
INSERT INTO `receiptdetails` VALUES(30, 62);
INSERT INTO `receiptdetails` VALUES(25, 63);
INSERT INTO `receiptdetails` VALUES(28, 64);
INSERT INTO `receiptdetails` VALUES(24, 65);

-- --------------------------------------------------------

--
-- Table structure for table `selfbanks`
--

CREATE TABLE `selfbanks` (
  `selfBankId` int(11) NOT NULL AUTO_INCREMENT,
  `selfBankName` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`selfBankId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `selfbanks`
--

INSERT INTO `selfbanks` VALUES(1, 'ICICI', '', '', '0');
INSERT INTO `selfbanks` VALUES(2, 'Maharashatra', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `setups`
--

CREATE TABLE `setups` (
  `fieldname` varchar(100) DEFAULT '',
  `fieldvalue` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setups`
--

INSERT INTO `setups` VALUES('smsValidity', '2010-01-08');
INSERT INTO `setups` VALUES('sendSms', 'true');
INSERT INTO `setups` VALUES('smsCount', '500');

-- --------------------------------------------------------

--
-- Table structure for table `smsdetails`
--

CREATE TABLE `smsdetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `Custmer_Name` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `message` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `sender_address` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `flag` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `count` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=23 ;

--
-- Dumping data for table `smsdetails`
--

INSERT INTO `smsdetails` VALUES(1, '9822348734', 'Acme Foundry Flux Co.', 'Your bill number 83 & bill Amount 0.00 is created', '2009-10-08 16:16:00', 'infosoft', 'Bill', 1);
INSERT INTO `smsdetails` VALUES(2, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:31:01', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(3, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:31:52', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(4, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:32:27', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(5, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:32:53', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(6, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:33:11', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(7, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:33:49', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(8, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:34:03', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(9, 'WRONG', '', 'sdf%0AInfosoft-9373423799', '2009-10-10 18:34:26', 'sd', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(10, '919777777777', '', 'wer%0AInfosoft-9373423799', '2009-10-10 18:42:17', 'wwe', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(11, '919226125283', '', 'wer%0AInfosoft-9373423799', '2009-10-10 18:43:06', 'er', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(12, '919822370395', '', 'wer%0AInfosoft-9373423799', '2009-10-10 18:43:06', 'er', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(13, '919763449614', '', 'wer%0AInfosoft-9373423799', '2009-10-10 18:43:06', 'er', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(14, '914444444444', '', 'wer%0AInfosoft-9373423799', '2009-10-15 15:18:35', 'werwer', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(15, '911234567890', '', 'ryt%0AInfosoft-9373423799', '2009-10-15 15:19:03', 'rty', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(16, 'WRONG', '', 'er%0AInfosoft-9373423799', '2009-10-21 12:30:08', 'er', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(17, '919226125283', '', 'fgh%0AInfosoft-9373423799', '2009-10-21 12:32:13', 'fghfg', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(18, '919822370395', '', 'fgh%0AInfosoft-9373423799', '2009-10-21 12:32:13', 'fghfg', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(19, '919763449614', '', 'fgh%0AInfosoft-9373423799', '2009-10-21 12:32:13', 'fghfg', 'GSMS', 1);
INSERT INTO `smsdetails` VALUES(20, 'Empty', 'Teltech Instrumentation Pvt Ltd ..Deleted', 'Lr is no. 111 created', '2009-10-28 10:44:53', 'infosoft', 'Lr', 1);
INSERT INTO `smsdetails` VALUES(21, '9822348734', 'Acme Foundry Flux Co.', 'Lr is no. 111 created', '2009-10-28 10:44:53', 'infosoft', 'Lr', 1);
INSERT INTO `smsdetails` VALUES(22, 'Empty', 'Tulip Casting P.ltd ', 'Lr is no. 111 created', '2009-10-28 10:44:53', 'infosoft', 'Lr', 1);

-- --------------------------------------------------------

--
-- Table structure for table `staffs`
--

CREATE TABLE `staffs` (
  `StaffId` int(11) NOT NULL AUTO_INCREMENT,
  `bookingoffice` varchar(50) NOT NULL,
  `StaffName` varchar(255) NOT NULL,
  `PerAddress` varchar(255) NOT NULL,
  `TempAddress` varchar(255) NOT NULL,
  `Phone` text NOT NULL,
  `Mobile` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `BloodGroup` varchar(255) NOT NULL,
  `Salary` decimal(10,2) NOT NULL,
  `UserType` varchar(20) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`StaffId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `staffs`
--


-- --------------------------------------------------------

--
-- Table structure for table `suppadvagainstmemos`
--

CREATE TABLE `suppadvagainstmemos` (
  `SuppAdvAgainstMemoID` int(10) NOT NULL AUTO_INCREMENT,
  `SupplierID` int(10) NOT NULL,
  `DispatchID` int(10) NOT NULL,
  `DispatchDate` date NOT NULL,
  `MemoNo` int(10) NOT NULL,
  `Date` date NOT NULL,
  `Amount` float NOT NULL,
  `AccountGroupID` int(10) NOT NULL,
  `CashCheque` text COLLATE latin1_general_ci NOT NULL,
  `BankID` int(10) NOT NULL,
  `ChequeNo` int(10) NOT NULL,
  `ChequeDate` date NOT NULL,
  `BankTransactionID` int(10) NOT NULL,
  `AccountID` int(10) NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `BillTrackID` int(10) NOT NULL,
  PRIMARY KEY (`SuppAdvAgainstMemoID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

--
-- Dumping data for table `suppadvagainstmemos`
--


-- --------------------------------------------------------

--
-- Table structure for table `supplierpaymentdetails`
--

CREATE TABLE `supplierpaymentdetails` (
  `PaymentID` int(10) NOT NULL,
  `MemoNumber` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `supplierpaymentdetails`
--

INSERT INTO `supplierpaymentdetails` VALUES(1, 45);
INSERT INTO `supplierpaymentdetails` VALUES(46, 61);
INSERT INTO `supplierpaymentdetails` VALUES(46, 87);
INSERT INTO `supplierpaymentdetails` VALUES(46, 88);

-- --------------------------------------------------------

--
-- Table structure for table `supplierpayments`
--

CREATE TABLE `supplierpayments` (
  `PaymentID` int(10) NOT NULL AUTO_INCREMENT,
  `PaymentNo` int(10) NOT NULL,
  `SupplierID` int(10) NOT NULL,
  `PaymentDate` date NOT NULL,
  `OfficeID` int(10) NOT NULL,
  `PaidOpningBalance` decimal(10,2) NOT NULL,
  `TotalAmount` decimal(10,2) NOT NULL,
  `Deduction` decimal(10,2) NOT NULL,
  `TDS` decimal(10,2) NOT NULL,
  `OnAccount` decimal(10,2) NOT NULL,
  `OnAccountBalance` decimal(10,2) NOT NULL,
  `NetAmount` decimal(10,2) NOT NULL,
  `PaymentMode` text COLLATE latin1_general_ci NOT NULL,
  `CheqDDNo` text COLLATE latin1_general_ci NOT NULL,
  `CheqDDDate` date NOT NULL,
  `PartyBankID` int(10) NOT NULL,
  `BankNameID` int(10) NOT NULL,
  `AccountGroupID` int(10) NOT NULL,
  `Remarks` text COLLATE latin1_general_ci NOT NULL,
  `MemoID` int(10) NOT NULL,
  `MemoNo` int(10) NOT NULL,
  `FreSettled` decimal(10,2) NOT NULL,
  `BalAmt` decimal(10,2) NOT NULL,
  `AddedBy` text COLLATE latin1_general_ci NOT NULL,
  `EditedBy` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`PaymentID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=54 ;

--
-- Dumping data for table `supplierpayments`
--

INSERT INTO `supplierpayments` VALUES(1, 34, 3, '2009-08-01', 1, 8.00, 5263.00, 8.00, 8.00, 8.00, 8.00, 5247.00, 'Cash', '', '2009-08-01', 0, 0, 0, 'ok', 0, 0, 0.00, 0.00, 'infosoft', '');
INSERT INTO `supplierpayments` VALUES(41, 0, 3, '2009-07-18', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 45, 6000.89, 5010.00, '', '');
INSERT INTO `supplierpayments` VALUES(36, 0, 1, '2009-08-12', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 50, 10000.78, 8432.00, '', '');
INSERT INTO `supplierpayments` VALUES(19, 0, 1, '2009-08-17', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 51, 90.00, 90.00, '', '');
INSERT INTO `supplierpayments` VALUES(27, 0, 5, '2009-08-17', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 52, 9000.90, 8930.00, '', '');
INSERT INTO `supplierpayments` VALUES(37, 0, 6, '2009-08-17', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 53, 8900.88, 7979.00, '', '');
INSERT INTO `supplierpayments` VALUES(32, 0, 1, '2009-08-21', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 57, 9000.00, 9018.00, '', '');
INSERT INTO `supplierpayments` VALUES(34, 0, 1, '2009-08-21', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 56, 5000.00, 5108.00, '', '');
INSERT INTO `supplierpayments` VALUES(35, 0, 5, '2009-08-17', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 55, 0.00, 0.00, '', '');
INSERT INTO `supplierpayments` VALUES(44, 0, 3, '2009-09-11', 1, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 99, 0.00, -4.00, '', '');
INSERT INTO `supplierpayments` VALUES(45, 0, 3, '2009-09-11', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 100, 343434.00, 343452.00, '', '');
INSERT INTO `supplierpayments` VALUES(46, 46, 3, '2009-09-11', 0, 0.00, -72.00, 0.00, 0.00, 0.00, 0.00, -72.00, 'select', '', '2009-09-11', 0, 0, 0, '', 0, 0, 0.00, 0.00, 'admin', '');
INSERT INTO `supplierpayments` VALUES(47, 0, 5, '2009-09-25', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 102, 87997987.00, 87998005.00, '', '');
INSERT INTO `supplierpayments` VALUES(48, 0, 7, '2009-10-12', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 233, 3000.00, 3016.00, '', '');
INSERT INTO `supplierpayments` VALUES(50, 0, 3, '2009-10-12', 0, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 234, 8999.00, 9013.00, '', '');
INSERT INTO `supplierpayments` VALUES(52, 0, 8, '2009-10-12', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 236, 8989.00, 9005.00, '', '');
INSERT INTO `supplierpayments` VALUES(53, 0, 3, '2009-10-13', 2, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, '', '', '0000-00-00', 0, 0, 0, '', 0, 237, 980.00, 996.00, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(255) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Address1` varchar(255) NOT NULL,
  `Address2` varchar(255) NOT NULL,
  `Address3` varchar(255) NOT NULL,
  `CityId` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Phone` varchar(255) NOT NULL,
  `Mobile` varchar(255) NOT NULL,
  `Fax` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `DOJ` varchar(75) NOT NULL,
  `ConcernName1` varchar(255) NOT NULL,
  `ConcernMobile1` varchar(255) NOT NULL,
  `ConcernEmail1` varchar(255) NOT NULL,
  `ConcernName2` varchar(255) NOT NULL,
  `ConcernMobile2` varchar(255) NOT NULL,
  `ConcernEmail2` varchar(255) NOT NULL,
  `ConcernName3` varchar(255) NOT NULL,
  `ConcernMobile3` varchar(255) NOT NULL,
  `ConcernEmail3` varchar(255) NOT NULL,
  `VenderCode` varchar(255) NOT NULL,
  `OpeningBalance` varchar(255) NOT NULL DEFAULT '0',
  `CreditDays` varchar(255) NOT NULL,
  `CreditLimit` varchar(255) NOT NULL,
  `LocalBillBalance` float NOT NULL DEFAULT '0',
  `OutStanding` float NOT NULL DEFAULT '0',
  `OnAccount` float NOT NULL DEFAULT '0',
  `RecOpeningBalance` float NOT NULL DEFAULT '0',
  `Remark` text NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` VALUES(1, 'A .r Founders', 'Raj', 'f81c2414e3f4685567201371a38aee4a', '', '', '', '2', '', ' Admin 10-08-09 Admin 10-08-09 Admin 10-08-09 Admin 10-08-09', '', '', '', '', '2009-08-10', 'A', 'a', '', '', '', '', '', '', '', '', '0.00', '3', '', 0, 45, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(4, 'vijay', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', 0, 0, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(3, 'Rajendra jadhav', 'Rajendra', 'f81c2414e3f4685567201371a38aee4a', '', '', '', '2', '', ' Admin 10-08-09 Admin 10-08-09 Admin 10-08-09 Admin 10-08-09', '', '', '', '', '2009-08-10', 'A', 'a', '', '', '', '', '', '', '', '', '0.00', '3', '', 0, 117, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(5, 'sujay ', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', 0, 80, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(6, 'pramode', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', 0, 7, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(7, 'raja', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', 0, 77, 0, 0, '', '0');
INSERT INTO `suppliers` VALUES(8, 'y', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '0', '', '', 0, 980, 0, 0, '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `taxes`
--

CREATE TABLE `taxes` (
  `TaxId` int(11) NOT NULL AUTO_INCREMENT,
  `TaxName` varchar(255) NOT NULL,
  `Tax1Percentage` float NOT NULL,
  `Tax1Desc` varchar(255) NOT NULL,
  `Tax2Percentage` float NOT NULL,
  `Tax2Desc` varchar(255) NOT NULL,
  `Tax3Percentage` float NOT NULL,
  `Tax3Desc` varchar(255) NOT NULL,
  `AddedBy` varchar(255) NOT NULL,
  `EditedBy` varchar(255) NOT NULL,
  `Remark` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`TaxId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taxes`
--

INSERT INTO `taxes` VALUES(1, 'Vat', 5, 'A', 5, 'B', 5, 'C', 'Admin 01-08-09', '', 'T', '0');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `UserId` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(30) NOT NULL,
  `LoginName` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `UserType` varchar(25) NOT NULL,
  `BookingOfficeId` int(5) NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`UserId`),
  UNIQUE KEY `UserName` (`UserName`),
  UNIQUE KEY `UserName_2` (`UserName`),
  UNIQUE KEY `Login` (`LoginName`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES(13, 'Infosoft', 'Infosoft', '5f1c5342818bf8c161d8ff4e18ff1720', 'Operator', 1, '0');
INSERT INTO `users` VALUES(12, 'Admin', 'Admin', '60671c896665c3fa', 'Operator', 0, '0');
INSERT INTO `users` VALUES(14, 'A', 'A', '0cc175b9c0f1b6a831c399e269772661', 'Operator', 1, '0');
INSERT INTO `users` VALUES(15, 'Raj', 'Raj', '65a1223dae83b8092c4edba0823a793c', 'Operator', 1, '0');
INSERT INTO `users` VALUES(16, 'Rajendra', 'Rajendra', 'f81c2414e3f4685567201371a38aee4a', 'Operator', 2, '0');

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `VehicleId` int(11) NOT NULL AUTO_INCREMENT,
  `VehicleNo` varchar(255) NOT NULL,
  `OwnerHire` enum('Owner','Hire') NOT NULL,
  `Supplier` varchar(255) NOT NULL,
  `SupplierID` int(11) NOT NULL,
  `RegDate` date NOT NULL,
  `PurchaseDate` date NOT NULL,
  `VehicleName` varchar(255) NOT NULL,
  `VehicleMake` varchar(255) NOT NULL,
  `SteeringGrNum` varchar(255) NOT NULL,
  `EngineNum` varchar(255) NOT NULL,
  `ChasisNumber` varchar(255) NOT NULL,
  `GearBoxNum` varchar(255) NOT NULL,
  `FrontAxleNo` varchar(255) NOT NULL,
  `ChasisPrice` decimal(10,2) NOT NULL,
  `OnRoadPrice` decimal(10,2) NOT NULL,
  `InitialOdometer` int(11) NOT NULL,
  `RecommendedSer` int(11) NOT NULL,
  `Capacity` varchar(10) NOT NULL,
  `GVW` varchar(10) NOT NULL,
  `RLW` varchar(10) NOT NULL,
  `ULW` varchar(10) NOT NULL,
  `Remark` text NOT NULL,
  `DealerName` varchar(255) NOT NULL,
  `BodyMaker` varchar(255) NOT NULL,
  `DealerAdd` text NOT NULL,
  `DealerContact` varchar(255) NOT NULL,
  `BodyMakerAdd` text NOT NULL,
  `BodyMakerContact` varchar(255) NOT NULL,
  `Status` enum('0','1') NOT NULL,
  PRIMARY KEY (`VehicleId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` VALUES(1, 'MH 12CH 9499', 'Hire', '', 3, '2008-04-18', '2008-04-18', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(2, 'MH 12 CH 9498', 'Hire', '', 4, '2008-04-19', '2008-04-19', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(3, 'MH 12 DG 162', 'Hire', '', 3, '2008-04-19', '2008-04-19', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(4, 'MH 12 CH 9597', 'Hire', '', 2, '2008-04-19', '2008-04-19', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(5, 'MH 42 B 3116', 'Hire', '', 3, '2008-04-23', '2008-04-23', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(6, 'MH 12 DG 5362', 'Hire', '', 4, '2008-04-02', '2008-04-23', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(7, 'MH 12 DG 5364', 'Hire', '', 3, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(8, 'MH 12 DG 169', 'Hire', '', 2, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(9, 'MH 12 DT 1654', 'Hire', '', 3, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(10, 'MH 12 EQ 2100', 'Hire', '', 3, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(11, 'MH 12 DT 1672', 'Hire', '', 2, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(12, 'MH 12 DG 5379', 'Hire', '', 1, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(13, 'MH 12 DG 156', 'Hire', '', 3, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(14, 'MH 12 DG 5497', 'Hire', '', 2, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(15, 'MH 12 DG 1951', 'Hire', '', 3, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(16, 'MH 12 DG 174', 'Hire', '', 2, '2008-04-26', '2008-04-26', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(17, 'MH 12 EQ 2223', 'Hire', '', 4, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(18, 'MH 12 DG 165', 'Hire', '', 4, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(19, 'MH 12 DG 160', 'Hire', '', 4, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(20, 'MH 12 DT 1663', 'Hire', '', 4, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(21, 'MH 12 CH 9499', 'Hire', '', 3, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(22, 'MH 12 EQ 2122', 'Hire', '', 2, '2008-04-27', '2008-04-27', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(23, 'MH 12 EQ 2113', 'Hire', '', 1, '2008-04-28', '2008-04-28', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(24, 'MH 42 B 3116', 'Owner', '', 0, '2008-06-09', '2008-06-09', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(25, '.', 'Owner', '', 0, '2009-03-07', '2009-03-07', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(26, 'MH 12 DG 156', 'Owner', '', 0, '2009-04-03', '2009-04-03', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(27, 'MH 12 FD 2122', 'Owner', '', 0, '2009-04-04', '2009-04-04', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(28, '', 'Owner', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(29, 'MH 12 9898', 'Owner', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(30, 'mh 12 9090', 'Owner', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');
INSERT INTO `vehicles` VALUES(31, 'mh 42 v 1212', 'Owner', '', 0, '0000-00-00', '0000-00-00', '', '', '', '', '', '', '', 0.00, 0.00, 0, 0, '', '', '', '', '', '', '', '', '', '', '', '0');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_pucs`
--

CREATE TABLE `vehicle_pucs` (
  `PucId` int(11) NOT NULL AUTO_INCREMENT,
  `puc` varchar(20) NOT NULL,
  `permit` varchar(20) NOT NULL,
  `fitness` varchar(20) NOT NULL,
  `tax` varchar(20) NOT NULL,
  `Date` date NOT NULL,
  `VehicleNo` varchar(255) NOT NULL,
  `Amount` double(8,2) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `Remark` text NOT NULL,
  `Status` enum('0','1') NOT NULL DEFAULT '0',
  `PermitDate` date NOT NULL,
  `PermitVehicle` varchar(255) NOT NULL,
  `PermitAmount` varchar(255) NOT NULL,
  `PermitLevel` enum('National','State') NOT NULL,
  `PermitNo` varchar(255) NOT NULL,
  `PermitFrom` date NOT NULL,
  `PermitTo` date NOT NULL,
  `PermitRemark` text NOT NULL,
  PRIMARY KEY (`PucId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `vehicle_pucs`
--

INSERT INTO `vehicle_pucs` VALUES(1, 'puc', '', '', '', '2009-05-19', 'df...Del', 99.84, '2009-05-19', '2009-05-19', 'rururturftuhydf', '1', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(2, 'puc', '', '', '', '2009-05-22', 'DL 05 3421', 99.99, '2009-01-22', '2009-05-19', 'rururturftuhydf', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(3, 'puc', '', '', '', '2009-05-19', '0...Del', 30.90, '2009-05-19', '2009-05-19', 'rururturftuhydf', '1', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(4, 'puc', '', '', '', '2009-05-19', 'df...Del', 78.00, '2009-05-19', '2009-05-19', 'rururturftuhydf', '1', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(5, 'puc', '', '', '', '2009-05-22', 'MH 05 3421', 52000.00, '2008-05-19', '2009-08-05', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(6, 'puc', '', '', '', '2009-05-20', '0...Del', 0.00, '2009-05-20', '2009-05-20', '', '1', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(7, '', 'permit', '', '', '2009-05-22', 'df', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', 'DL 05 3421', '', 'National', '', '2006-05-21', '2012-05-21', 'Remark testing');
INSERT INTO `vehicle_pucs` VALUES(8, '', 'permit', '', '', '0000-00-00', '...Del', 0.00, '2009-05-20', '2009-05-20', '', '1', '0000-00-00', 'RaviRaj', '', 'State', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(9, '', 'permit', '', '', '2009-05-22', 'df', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', 'MH 05 3421', '', 'State', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(10, '', 'permit', '', '', '2009-05-22', 'RaviRaj', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', 'KK 05 3421', '', 'National', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(11, '', 'permit', '', '', '2009-05-22', 'RaviRaj', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', 'KA 05 3421', '', 'State', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(12, '', 'permit', '', '', '2009-05-22', 'df', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', 'MH 05 3421', '', 'National', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(13, '', '', 'fitness', '', '0000-00-00', 'RaviRaj', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(14, '', '', 'fitness', '', '0000-00-00', 'RaviRaj', 0.00, '2009-05-20', '2009-05-20', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(15, '', '', 'fitness', '', '2009-05-20', 'df', 0.00, '0000-00-00', '2009-05-20', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(16, '', '', 'fitness', '', '0000-00-00', 'RaviRaj', 0.00, '2009-05-21', '2009-05-21', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(17, '', '', 'fitness', '', '0000-00-00', '0', 0.00, '2009-05-21', '2009-05-21', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(18, '', '', 'fitness', '', '0000-00-00', '0', 0.00, '2009-05-21', '2009-05-21', '', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(19, 'puc', '', '', '', '2009-05-22', 'KK 05 3421', 40044.73, '2007-05-21', '2008-05-20', 'This is for one year puc', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(20, 'puc', '', '', '', '2009-05-22', 'KA 05 3421', 99.99, '2007-05-21', '2008-05-20', 'This is for one year puc', '0', '0000-00-00', '', '', '', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(23, 'puc', '', '', '', '2009-05-22', 'TA GG 3457', 0.00, '2009-05-22', '2009-05-22', '', '0', '0000-00-00', '', '', 'National', '', '0000-00-00', '0000-00-00', '');
INSERT INTO `vehicle_pucs` VALUES(24, 'puc', '', '', '', '2009-05-22', 'MH 05 3421', 30.90, '2009-05-22', '2009-11-22', '', '0', '0000-00-00', '', '', 'National', '', '0000-00-00', '0000-00-00', '');
